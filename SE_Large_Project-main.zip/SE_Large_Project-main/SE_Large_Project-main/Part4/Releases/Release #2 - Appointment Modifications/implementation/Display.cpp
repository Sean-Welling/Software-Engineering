#include "../headers/Display.h"

int menu()
{
    print_padded("KSU Covid19 Vaccination Program");
    add_divider(WIDTH);
    print_padded("Menu");
    add_divider(WIDTH);
    print_padded("1. Patient Registration");
    add_v_space(2);
    print_padded("2. Modify Appointment");
    add_v_space(2);

    int choice;
    print_padded("What would you like to do? : ");
    std::cin >> choice;
    add_v_space(2);

    return choice;
}

int calc_padding(std::string phrase)
{
    int padding;
    int len = phrase.length();

    padding = (WIDTH - len) / 2;

    return padding;
}

void add_divider(int width)
{
    std::cout << "\n\n";
    for (int i = 0; i < width; i++)
    {
        std::cout << "=";
    }
    std::cout << "\n\n";
}

void print_padded(std::string phrase)
{
    //get padding
    int padding = calc_padding(phrase);

    for (int i = 0; i < padding; i++)
    {
        std::cout << " ";
    }

    std::cout << phrase;
}

void add_v_space(int lines)
{
    for (int i = 0; i < lines; i++)
    {
        std::cout << "\n";
    }
}