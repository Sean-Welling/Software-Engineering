#include <iostream>

#include "../headers/campus.h"

int main()
{
    //Create campus
    campus *c = new campus();
    c->set_location(0);

    //get past orders : Clay
    std::vector<Order *> past_orders = c->get_past_orders("04/14/2021", "05/17/2021", false); //might need to remove all flag
    std::cout << "Past orders : " << past_orders.size() << " orders\n";

    for(Order* order : past_orders){
        std::cout << "Order ID : " << order->get_id() << " - Placed on " << order->get_date_requested() << "\n";
    }

    // //get_past_shipments - Can't find : Arthur

    // //get_avg_days_to_receive_shipment : Arthur
    // std::cout << "Avg days to receive shipment : " << c->get_avg_days_to_receive_shipment() << " days\n";

    // //need_to_order : Dan
    // std::cout << "Need to order? : " << c->need_to_order(50, 50);

    // // submit_order : Sean - Can't remember what this is for
    // c->submit_order();

    // // set_supply : Dan
    // Supply *s = c->init_supply();
    // s->set_id(0);

    // c->set_supply(s);
    // // std::cout << "supply id : " << c->get_supply()->get_id() << "\n";// get_supply : Sean

    // // get_days_to_run_out : Dan
    // std::cout << "Days to run out : " << c->get_days_to_run_out(75, 40) << "\n";

    return 0;
}