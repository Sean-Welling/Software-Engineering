#include "../headers/shipment.h"

/**************************************************************************
 * Implementation of shipment.h
 *************************************************************************/

//Setters

bool Shipment::set_id(int id){
    this->id = id;
    if(this->id == id){
        return true;
    }
    else{
        return false;
    }
}
bool Shipment::set_total_doses(int total_doses){
    this->total_doses = total_doses;
    if(this->total_doses == total_doses){
        return true;
    }
    else{
        return false;
    }
}
bool Shipment::set_send_date(std::string send_date){
    this->send_date = send_date;
    if(this->send_date == send_date){
        return true;
    }
    else{
        return false;
    }
}

bool Shipment::set_estimated_arrival_date(std::string estimated_arrival_date){
    this->estimated_arrival_date = estimated_arrival_date;
    if(this->estimated_arrival_date == estimated_arrival_date){
        return true;
    }
    else{
        return false;
    }
}

bool Shipment::set_received(bool received){
    this->received = received;
    if(this->received == received){
        return true;
    }
    else{
        return false;
    }
}

bool Shipment::set_receiver_id(int receiver_id){
    this->receiver_id = receiver_id;
    if(this->receiver_id == receiver_id){
        return true;
    }
    else{
        return false;
    }
}
bool Shipment::set_order_id(int order_id){
    this->order_id = order_id;
    if(this->order_id == order_id){
        return true;
    }
    else{
        return false;
    }
}

//Getters
int Shipment::get_id(){
    return this->id;
}
int Shipment::get_total_doses(){
    return this->total_doses;
}
std::string Shipment::get_send_date(){
    return this->send_date;
}
std::string Shipment::get_estimated_arrival_date(){
    return this->estimated_arrival_date;
}
bool Shipment::get_received(){
    return this->received;
}
int Shipment::get_receiver_id(){
    return this->receiver_id;
}
int Shipment::get_order_id(){
    return this->order_id;
}



//Other

int Shipment::find_available_id(){
    //create db
    Database db = Database("shipments.csv");
    return db.find_available_id("shipment_id");
    return -1;
}

bool Shipment::log(){
    Database db = Database("shipments.csv");

    //check if id is in db already
    std::vector<std::vector<std::string>> db_rows = db.get_rows();
    
    //delete this shipment row in db if there already
    for(int i = 0; i < db_rows.size(); i++){
        if(stoi(db_rows.at(i).at(0)) == this->id){
            //delete row
            db.delete_row(i);
            break;
        }
    }

    //create row element for this shipment
    std::vector<std::string> row = {to_string(this->id), this->send_date, to_string(this->receiver_id), to_string(this->total_doses), this->estimated_arrival_date, to_string(this->received), to_string(this->order_id)};

    //log this shipment
    db.add_row(row);
    return true;
}

int Shipment::determine_doses(Supply s)
{

    return 0;
}

int **Shipment::split_between_campuses()
{

    return 0;
}

void Shipment::send_shipment()
{

    return;
}

shipment_details(){
    
    int line = 2;
    
    std::ifstream f("shipment.csv");
    std::string s;

    cout << "what order whould you like to see: " << endl;
    cin >> line;
    
    for (int i = 0; i <= line; i++)
            std::getline(f, s);

    std::cout << s;
    return 0;
    };


bool Shipment::init_from_existing(){
    //check that id is set
    if(this->id == -1){
        return false;
    }
    else{
        Database db = Database("shipments.csv");
        std::vector<std::vector<std::string>> db_rows = db.get_rows();

        for(std::vector<std::string> row : db_rows){
            if(stoi(row.at(0)) == this->id){
                //set member values
                this->set_send_date(row.at(1));
                this->set_receiver_id(stoi(row.at(2)));
                this->set_total_doses(stoi(row.at(3)));
                this->set_estimated_arrival_date(row.at(4));
                this->set_received(stoi(row.at(5)));
                this->set_order_id(stoi(row.at(6)));
                return true;
            }
        }
        return false;
    }
}
