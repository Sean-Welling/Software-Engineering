//
//  schedule.cpp
//  schedule
//
//  Created by Arthur Wolff on 4/11/21.
//

#include <iostream>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <utility> 
#include <stdexcept>
#include <sstream>
using namespace std;

void read_schedule(){
  
    fstream fin;
  
// Open an existing file
    fin.open("appointments.csv", ios::in);
  
    int appt_date, appt2, count = 0;
    cout << "Enter the date you wish to see appointments of: mm/dd/yyyy ";
    cin >> appt_date;

    vector<string> row;
    string line, word, temp;

    while (fin >> temp) {
        row.clear();

// stores row as a string
        getline(fin, line);
        stringstream s(line);

// reads every column data of a row and
        while (getline(s, word, ', ')) {
            row.push_back(word);
        }

// converts string to integer
        appt2 = stoi(row[0]);

        if (appt2 == appt_date) {

// data output
            count = 1;
            cout << " Appointment Details for  " << row[2] << endl;
            cout << "Appointment ID: " << row[0] << endl;
            cout << "Patient ID: " << row[1] << endl;
            cout << "Time: " << row[3] << endl;
            cout << "Campus ID: " << row[4] << endl;
            cout << "Iteration: " << row[5] << endl;
            break;
        }
    }
    if (count == 0)
        cout << "Record not found\n";
}
