#include "../headers/System.h"

const int Administrator_ID = 1234;
const std::string Administrator_Password = "password";

//all campus objects
const int num_campuses = 8;
std::vector<campus*> all_campuses;//initialized in system->init
std::vector<schedule*> all_schedules;//initialized in system->init

bool register_patient()
{
    int error_code = 0;

    //create patient
    patient *pt = new patient();
    studentStaff *ss = new studentStaff();
    pt->register_patient(pt,ss);

    //find available appointment times and locations (Schedule)

    //choose appointment time/date and location
    std::string date = "04/14/2021";
    std::string time = "15:00";

    //Creates a campus object for each location. Just sets campus location name
    std::cout << "What campus would you like to get your vaccine at?\n";
    vector<campus *> all_campuses;
    for (int i = 0; i < 8; i++)
    {
        all_campuses.push_back(new campus);
        all_campuses.at(i)->set_location(i);
        std::cout << i << ". " << all_campuses.at(i)->get_location() << "\n";
    }

    int campus_index;

    std::cout << "Choice : ";
    std::cin >> campus_index;

    //create appointment
    Appointment *apmt = new Appointment();

    //set id
    apmt->set_id(apmt->find_available_id());

    //set appointment patient
    if (apmt->set_patient(pt))
    {
        //set date
        if (apmt->set_date(date))
        {
            //set time
            if (apmt->set_time(time))
            {
                //set appointment campus
                if (apmt->set_campus(all_campuses[campus_index]))
                {
                    //check if first appointment
                    std::cout << "Is this your first appointment? (y/n) : ";
                    char ans;
                    int iteration;
                    cin >> ans;
                    while (ans != 'y' && ans != 'n')
                    {
                        std::cout << "Sorry, I don't understand - Is this your first appointment? (y/n) : ";
                        cin >> ans;
                    }

                    if (ans == 'y')
                    {
                        iteration = 1;
                    }
                    else
                    {
                        iteration = 2;
                    }

                    //set the iteration
                    if (apmt->set_iteration(iteration))
                    {
                        if (!apmt->log_appointment("appointments.csv"))
                        {
                            error_code = 5;
                        }
                    }
                    else
                    {
                        error_code = 4;
                    }
                }
            }
            else
            {
                error_code = 3;
            }
        }
        else
        {
            error_code = 2;
        }
    }
    else
    {
        error_code = 1;
    }

    if (error_code == 0)
    {
        print_padded("Patient successfully registered for" + apmt->get_date() + " at " + apmt->get_time() + " at the Campus " + "temp" + "\n");
        return true;
    }
    else
    {
        print_padded("ERROR: Couldn't register patient.\n");
        return false;
    }
}

bool modify_appointment()
{
    int apmt_id;
    std::cout << "enter your appointment id: ";
    std::cin >> apmt_id;

    Appointment *apmt = new Appointment();
    patient *p = new patient();

    apmt->set_id(apmt_id);
    apmt->init_from_existing();

    apmt->modify();

    return true;
}

int system_init()
{
    print_padded("Initializing system...");
    int error_code = 0;

    //for each campus -> create obj and schedule
    for(int i = 0; i < num_campuses; i++){
        campus* temp_campus = new campus();
        temp_campus->set_location(i);
        all_campuses.push_back(temp_campus);
    }

    //create all the campus schedules
    //all_schedules = init_campus_schedules(all_campuses);//Sean, uncomment this line when finished with the function


    schedule *curr_schedule = new schedule();

    //get current date

    std::vector<Appointment *> past_apmts;

    //get all past appointments using current date
    //past_apmts = past_apmts->get_past_apmts();

    //for all past apmts -> run complete

    for (int i = 0; i < past_apmts.size(); i++)
    {
        Appointment *temp_apmt = past_apmts.at(i);

        //get all appointments from last week using this campus' schedule
        schedule campus_schedule = *(all_schedules[temp_apmt->get_campus()->get_location_id()]);

        std::string curr_date = get_curr_date();
        Date last_week = Date(curr_date);
        last_week = last_week - 7;
        Date next_week = Date(curr_date);
        next_week = next_week + 7;

        //get last week's appointments
        std::vector<Appointment*> last_week_apmts = campus_schedule.get_appointments_in_range(last_week.get_formatted("mm/dd/yyyy"), curr_date);

        //get next weeks appointments
        std::vector<Appointment*> next_week_apmts = campus_schedule.get_appointments_in_range(curr_date, next_week.get_formatted("mm/dd/yyyy"));

        //get avg doses administered per day within choice date range (avg days to receive shipment + 3)
        //calc start date for finding avg doses per day
        Date avg_doses_start = Date(curr_date);
        avg_doses_start = avg_doses_start - temp_apmt->get_campus()->get_avg_days_to_receive_shipment();
        
        int avg_doses_per_day = campus_schedule.find_avg_appointments_completed_per_day(avg_doses_start.get_formatted("mm/dd/yyyy"), curr_date);

        if (!temp_apmt->complete(true, last_week_apmts.size(), next_week_apmts.size(), avg_doses_per_day))
        {
            error_code = 1;
        }
    }

    add_divider(WIDTH);

    //process shipments

    //process orders
    if (!process_orders())
    {
        error_code = 3;
    }

    return error_code;
}

bool process_orders()
{
    //find all orders that were placed yesterday
    Date curr_date = Date(get_curr_date());

    //check the shipment log to make sure we haven't created a shipment for this order already
    Database shipment_db = Database("shipments.csv");
    std::vector<std::vector<std::string>> shipment_db_rows = shipment_db.get_rows();
    std::vector<int> existing_shipment_order_ids;

    for (std::vector<std::string> row : shipment_db_rows)
    {
        existing_shipment_order_ids.push_back(stoi(row.at(6)));
    }

    //open orders db and get rows
    Database db = Database("orders.csv");
    std::vector<std::vector<std::string>> db_rows = db.get_rows();

    std::vector<Order *> orders_to_be_processed;

    Date *order_request_date = new Date();
    Order *temp_order = new Order();

    //get all orders that were submitted yesterday
    for (std::vector<std::string> row : db_rows)
    {
        //set request date obj
        order_request_date->init_from_date_string(row.at(3));

        Date diff = curr_date - *order_request_date;

        //compare dates
        if (diff.get_day() == 1 && diff.get_month() == 0 && diff.get_year() == 0)
        {
            //check to make sure we don't already have a shipment for this order
            bool shipment_found = false;
            for (int shipment_order_id : existing_shipment_order_ids)
            {
                //compare shipment order id to current order id
                if (shipment_order_id == stoi(row.at(0)))
                {
                    shipment_found = true;
                    break;
                }
            }
            if (!shipment_found)
            {
                //set order members
                temp_order->set_date_requested(row.at(3));
                temp_order->set_doses_needed(stoi(row.at(2)));
                temp_order->set_id(stoi(row.at(0)));
                temp_order->set_requester_id(stoi(row.at(1)));
                temp_order->set_fulfilled(stoi(row.at(4)));

                //add to list of orders to be processed
                orders_to_be_processed.push_back(temp_order);
            }
        }
    }

    //process each order
    for (Order *order : orders_to_be_processed)
    {
        //create shipment
        Shipment shipment = Shipment();

        //get an ID for the new shipment
        shipment.set_id(shipment.find_available_id());

        //set the send date
        shipment.set_send_date(get_curr_date());

        //calculate the number of doses to add to shipment
        /*
            Algorithm for calculating num doses
            1. Calculate a random % of the requested number of vaccines
            2. Add that calculated % of requested doses to shipment
        */

        //  https://www.cplusplus.com/reference/cstdlib/srand/

        //Initialize the randomness
        srand(time(NULL));

        //get random % to send from requested
        double to_remove = rand() % 101;

        shipment.set_total_doses(order->get_doses_needed() * (to_remove / 100));

        //get random num days between 4-10 for estimated arrival date
        int estimated_travel_days = (rand() % 7) + 4;

        //calculate estimated arrival date
        Date estimated_arrival_date = curr_date + estimated_travel_days;
        shipment.set_estimated_arrival_date(estimated_arrival_date.get_formatted("mm/dd/yyyy"));

        //set shipment receiver
        shipment.set_receiver_id(order->get_requester_id());

        shipment.set_order_id(order->get_id());

        //"Send" (send) log shipment
        shipment.log();
    }

    return false;
}

bool init_campus_schedules()
{
    bool not_completed;
    // Create schedule for each campus
    for (int i = 0; i < num_campuses; i++) 
    {
        schedule *temp_sched = new schedule();
        temp_sched->set_appointments(find_appointments_by_campus(all_campuses[i], not_completed));
        all_schedules.push_back(temp_sched);
    }

    if (all_schedules.size() == 8)
    {
        return true;
    } else {
        return false;
    }
}

void view_information(){
    std::cout << "Are you an admin? (y/n) : ";
    std::string admin_ans;
    std::cin >> admin_ans;

    while(admin_ans != "y" && admin_ans != "n"){
        std::cout << "Sorry, I don't understand. Please answer y or n. Are you and admin? : ";
        std::cin >> admin_ans;
    }

    if(admin_ans == "y"){
        //admin
        //validate
        std::cout << "Admin ID : ";
        int admin_id;
        std::string admin_pass;
        int id_count = 0;
        int pass_count = 0;
        std::cin >> admin_id;
        id_count++;
        while(admin_id != Administrator_ID){
            std::cout << "Sorry, that is incorrect. You have " << 4-id_count << " tries left.\nAdmin ID : ";
            std::cin >> admin_id;
            id_count++;
            if(id_count == 4){
                //send to main menu
                std::cout << "Sorry, but I'm going to have to send you back to the main menu...\n\n";
                return;
            }
        }

        //good id -> get pass
        std::cout << "Admin Password : ";
        std::cin >> admin_pass;
        pass_count++;
        while(admin_pass != Administrator_Password){
            std::cout << "Sorry, that is incorrect. You have " << 4-pass_count << " tries left. Admin Password : ";
            std::cin >> admin_pass;
            pass_count++;
            if(pass_count == 4){
                //send to main menu
                std::cout << "Sorry, but I'm going to have to send you back to the main menu...\n\n";
                return;
            }
        }

        //good pass -> enter info loop
        system("cls");

        std::cout << "Welcome administrator! ";

        //get all orders
        std::vector<Order> all_orders;
        Database db = Database("orders.csv");
        std::vector<std::vector<std::string>> db_rows = db.get_rows();
        for(std::vector<std::string> row : db_rows){
            //create order obj
            Order o = Order();
            o.set_id(stoi(row.at(0)));
            o.set_requester_id(stoi(row.at(1)));
            o.set_doses_needed(stoi(row.at(2)));
            o.set_date_requested(row.at(3));
            o.set_fulfilled(stoi(row.at(4)));

            all_orders.push_back(o);
        }

        //get all shipments
        std::vector<Shipment> all_shipments;
        db.set_filename("shipments.csv");
        db_rows = db.get_rows();
        for(std::vector<std::string> row : db_rows){
            //create order obj
            Shipment s = Shipment();
            s.set_id(stoi(row.at(0)));
            s.set_send_date(row.at(1));
            s.set_receiver_id(stoi(row.at(2)));
            s.set_total_doses(stoi(row.at(3)));
            s.set_estimated_arrival_date(row.at(4));
            s.set_received(stoi(row.at(5)));
            s.set_order_id(stoi(row.at(6)));

            all_shipments.push_back(s);
        }

        while(1){
            int choice;
            bool info_root_0_error;
            do{
                info_root_0_error = false;
                system("cls");
                std::cout << "What information would you like to view?\n\n";
                std::cout << "0. Go back to main menu\n\n";
                std::cout << "1. Appointments\n";
                std::cout << "2. Orders\n";
                std::cout << "3. Shipments\n";
                std::cout << "4. Schedules\n";

                std::cout << "Choice : ";

                //  https://stackoverflow.com/questions/44326414/exceptional-handling-in-c-when-user-inputs-string-instead-of-int/44329159
                //  https://stackoverflow.com/questions/5131647/why-would-we-call-cin-clear-and-cin-ignore-after-reading-input

                if(!(std::cin >> choice)){
                    std::cout << "\nInvalid input - Make sure to only use numbers...\n";
                    //clear the cin buffer
                    std::cin.clear();//clears the error flag on the stdin
                    std::cin.ignore(1000, '\n');//skips to the next line of input
                    info_root_0_error = true;
                    system("pause");
                }
                else{
                    //number input
                    if(choice < 0 || choice > 4){
                    std::cout << "Invalid choice... Try again\n\n";
                    info_root_0_error = true;
                    system("pause");
                    }
                }
            }while(info_root_0_error);

            bool keep_going = true;
            std::string go_again;

            switch(choice){
                case 0: {
                    //route back to main menu
                    return;
                }
                case 1: {
                    //enter appointments loop
                    while(keep_going){
                        system("cls");
                        std::cout << "Appointment Information : What would you like to do?\n\n";
                        std::cout << "0. Go back\n\n";
                        std::cout << "1. View all appointments\n";
                        std::cout << "2. View appointment by ID\n";
                        std::cout << "Choice : ";
                        if(!(std::cin >> choice)){
                            std::cout << "Invalid choice... Try again\n";
                            //clear the cin buffer
                            std::cin.clear();//clears the error flag on the stdin
                            std::cin.ignore(1000, '\n');//skips to the next line of input
                            system("pause");
                        }
                        else{
                            switch(choice){
                                case 0: {
                                    //route back to general info selection menu
                                    keep_going = false;
                                    break;
                                }
                                case 1: {
                                    //view all appointments
                                    //check if schedules have past and future apmts : use all schedules
                                    break;
                                }
                                case 2: {
                                    //view specific appointment
                                    do{
                                        system("cls");
                                        int appointment_id;
                                        std::cout << "Appointment ID : ";
                                        if(!(std::cin >> choice)){
                                            std::cout << "\nInvalid input - Make sure to only use numbers for the appointment ID...\n";
                                            //clear the cin buffer
                                            std::cin.clear();//clears the error flag on the stdin
                                            std::cin.ignore(1000, '\n');//skips to the next line of input
                                        }
                                        else{
                                            //good input
                                            //look for apmt
                                            Appointment* apmt = find_appointment_by_id(appointment_id);

                                            //check for fail
                                            if(apmt->get_id() != -1){
                                                //found apmt -> display details
                                                apmt->display_details();
                                            }
                                            else{
                                                std::cout << "Sorry, I couldn't find that appointment...\n\n";
                                            }
                                        }
                                        std::cout << "Would you like to view another appointment? (y/n) : ";
                                        std::cin >> go_again;
                                        while(go_again != "y" && go_again != "n"){
                                            std::cout << "Sorry, I don't understand. Do you want to view another appointment? (y/n) : ";
                                            std::cin >> go_again;
                                        }
                                    }while(go_again == "y");
                                    break;
                                }
                                default: {
                                    std::cout << "Error: unhandled exception...\n\n";
                                    break;
                                }
                            }
                        }
                    }
                }
                case 2: {
                    //enter orders loop
                    while(keep_going){
                        system("cls");
                        std::cout << "Order Information : What would you like to do?\n\n";
                        std::cout << "0. Go back\n\n";
                        std::cout << "1. View all orders\n";
                        std::cout << "2. View orders by campus\n";
                        std::cout << "3. View order by ID\n";
                        std::cout << "Choice : ";
                        if(!(std::cin >> choice)){
                            std::cout << "Invalid choice... Try again\n";
                            //clear the cin buffer
                            std::cin.clear();//clears the error flag on the stdin
                            std::cin.ignore(1000, '\n');//skips to the next line of input
                            system("pause");
                        }
                        else{
                            switch(choice){
                                case 0: {
                                    //route back to general info selection menu
                                    keep_going = false;
                                    break;
                                }
                                case 1: {
                                    //view all orders
                                    system("cls");

                                    std::cout << "All Orders\n==================\n\n";
                                    for(Order o : all_orders){
                                        std::cout << "Order ID : " << o.get_id() << "\n";
                                    }

                                    system("pause");
                                    break;
                                }
                                case 2: {
                                    //view orders by campus
                                    do{
                                        system("cls");

                                        std::cout << "Which campus would you like to view orders for?\n\n";
                                        for(int i = 0; i < all_campuses.size(); i++){
                                            std::cout << i << ". " << all_campuses.at(i)->get_location() << "\n";
                                        }
                                        std::cout << "\n";

                                        std::cout << "Choice : ";
                                        if(!(std::cin >> choice)){
                                            std::cout << "Invalid choice... Try again\n";
                                            //clear the cin buffer
                                            std::cin.clear();//clears the error flag on the stdin
                                            std::cin.ignore(1000, '\n');//skips to the next line of input
                                        }
                                        else{
                                            std::cout << "\n";

                                            //check for bad input
                                            if(choice < 0 && choice > 7){
                                                std::cout << "Sorry, that isn't a valid campus...\n\n";
                                            }
                                            else{
                                                //good input
                                                int num_orders = 0;
                                                num_orders = display_orders_by_campus(all_campuses.at(choice));
                                                if(num_orders == 0){
                                                    std::cout << "No orders for the " << all_campuses.at(choice)->get_location() << " campus\n";
                                                }
                                            }
                                        }
                                        std::cout << "Would you like to view other orders? (y/n) : ";
                                        std::cin >> go_again;
                                    }while(go_again == "y");
                                    break;
                                }
                                case 3: {
                                    //view specific order
                                    do{
                                        system("cls");

                                        std::cout << "Order ID : ";
                                        int order_id;
                                        if(!(std::cin >> order_id)){
                                            std::cout << "Invalid choice... Try again\n";
                                            //clear the cin buffer
                                            std::cin.clear();//clears the error flag on the stdin
                                            std::cin.ignore(1000, '\n');//skips to the next line of input
                                        }
                                        else{
                                            //find order
                                            bool found = false;
                                            for(Order o : all_orders){
                                                //check id
                                                if(order_id == o.get_id()){
                                                    //o.display_details();
                                                    std::cout << "Order date requested : " << o.get_date_requested() << "\n";
                                                    found = true;
                                                }
                                            }
                                            //if not found
                                            if(!found){
                                                std::cout << "Sorry, I couldn't find that order...\n\n";
                                            }
                                        }

                                        std::cout << "Would you like to view another order? (y/n) : ";
                                        std::cin >> go_again;
                                        while(go_again != "y" && go_again != "n"){
                                            std::cout << "Sorry, I don't understand. Do you want to view another order? (y/n) : ";
                                            std::cin >> go_again;
                                        }
                                    }while(go_again == "y");
                                    break;
                                }
                                default: {
                                    std::cout << "Invalid choice... Try again\n";
                                    system("pause");
                                    break;
                                }
                            }
                        }
                    }
                }
                case 3: {
                    //enter shipments loop
                    while(keep_going){
                        system("cls");
                        std::cout << "Shipment Information : What would you like to do?\n\n";
                        std::cout << "0. Go back\n\n";
                        std::cout << "1. View all shipments\n";
                        std::cout << "2. View shipments by campus\n";
                        std::cout << "3. View shipment by ID\n";
                        std::cout << "Choice : ";
                        if(!(std::cin >> choice)){
                            std::cout << "Invalid choice... Try again\n";
                            //clear the cin buffer
                            std::cin.clear();//clears the error flag on the stdin
                            std::cin.ignore(1000, '\n');//skips to the next line of input
                            system("pause");
                        }
                        else{
                            switch(choice){
                                case 0: {
                                    //route back to general info selection menu
                                    keep_going = false;
                                    break;
                                }
                                case 1: {
                                    system("cls");
                                    //view all shipments
                                    for(Shipment s : all_shipments){
                                        //s.display_details();
                                    }
                                    system("pause");
                                    break;
                                }
                                case 2: {
                                    //view shipments by campus
                                    do{
                                        //get campus ID
                                        system("cls");
                                        std::cout << "Shipments by campus...\n\n";

                                        std::cout << "Choose which campus you want to view shipments for...\n";
                                        for(int i = 0; i < all_campuses.size(); i++){
                                            std::cout << i << ". " << all_campuses.at(i)->get_location() << "\n";
                                        }
                                        std::cout << "\nChoice : ";
                                        int num_shipments;

                                        int campus_id;
                                        if(!(std::cin >> campus_id)){
                                            std::cout << "Invalid choice... Try again\n";
                                            //clear the cin buffer
                                            std::cin.clear();//clears the error flag on the stdin
                                            std::cin.ignore(1000, '\n');//skips to the next line of input
                                        }
                                        else{
                                            //check for input error
                                            if(campus_id < 0 || campus_id > 7){
                                                std::cout << "Invalid campus location. Please try again...\n\n";
                                            }
                                            else{
                                                //good input -> find correct shipments
                                                num_shipments = display_shipments_by_campus(all_campuses.at(campus_id));
                                            }
                                        }

                                        if(num_shipments == 0){
                                            std::cout << "No shipments for this campus.\n\n";
                                        }

                                        std::cout << "Would you like to view other campus shipments? (y/n) : ";
                                        std::cin >> go_again;
                                        while(go_again != "y" && go_again != "n"){
                                            std::cout << "Sorry, I don't understand. Would you like to view other campus shipments? (y/n) : ";
                                            std::cin >> go_again;
                                        }
                                    }while(go_again == "y");
                                    break;
                                }
                                case 3: {
                                    //view specific shipment
                                    do{
                                        system("cls");
                                        //get id
                                        std::cout << "View shipment by ID...\n\n";
                                        std::cout  << "Shipment ID : ";
                                        int shipment_id;
                                        if(!(std::cin >> shipment_id)){
                                            std::cout << "Invalid choice... Try again\n";
                                            //clear the cin buffer
                                            std::cin.clear();//clears the error flag on the stdin
                                            std::cin.ignore(1000, '\n');//skips to the next line of input
                                        }
                                        else{
                                            //try to find shipment
                                            bool found = false;
                                            for(Shipment s : all_shipments){
                                                if(s.get_id() == shipment_id){
                                                    found = true;
                                                    //print details
                                                    //s.display_details();
                                                }
                                            }
                                            if(!found){
                                                std::cout << "I couldn't find that shipment.\n";
                                            }
                                        }
                                        std::cout << "\nWould you like to view another shipment? (y/n) : ";
                                        std::cin >> go_again;
                                        while(go_again != "y" && go_again != "n"){
                                            std::cout << "Sorry, I don't understand. Would you like to view another shipment? (y/n) : ";
                                            std::cin >> go_again;
                                        }
                                    }while(go_again == "y");
                                    break;
                                }
                                default: {
                                    std::cout << "Invalid choice... Try again\n";
                                    system("pause");
                                    break;
                                }
                            }
                        }
                    }
                }
                case 4: {
                    //enter schedules loop
                    while(keep_going){
                        system("cls");
                        std::cout << "Schedule Information : What would you like to do?\n\n";
                        std::cout << "0. Go back\n\n";
                        std::cout << "1. View all schedules\n";
                        std::cout << "2. View schedule by campus\n";
                        std::cout << "Choice : ";
                        if(!(std::cin >> choice)){
                            std::cout << "\nInvalid input - Make sure to only use numbers...\n";
                            //clear the cin buffer
                            std::cin.clear();//clears the error flag on the stdin
                            std::cin.ignore(1000, '\n');//skips to the next line of input
                            system("pause");
                        }
                        else{
                            switch(choice){
                                case 0: {
                                    //route back to general info selection menu
                                    keep_going = false;
                                    break;
                                }
                                case 1: {
                                    //view all schedules
                                    system("cls");
                                    for(int i = 0; i < all_schedules.size(); i++){
                                        //print the schedule campus name
                                        std::cout << all_campuses.at(i)->get_location() << " campus schedule - \n\n";
                                        //print the schedule details
                                        //all_schedules.at(i)->display_details();
                                    }
                                    system("pause");
                                    break;
                                }
                                case 2: {
                                    //view schedule by campus
                                    do{
                                        system("cls");
                                        std::cout << "View schedules by campus...\n\n";
                                        //print campus locations
                                        std::cout << "Choose which campus you want to view shipments for...\n";
                                        for(int i = 0; i < all_campuses.size(); i++){
                                            std::cout << i << ". " << all_campuses.at(i)->get_location() << "\n";
                                        }
                                        std::cout << "\n";

                                        //get choice
                                        std::cout << "Choice : ";
                                        if(!(std::cin >> choice)){
                                            std::cout << "\nInvalid input - Make sure to only use numbers for the campus location...\n";
                                            //clear the cin buffer
                                            std::cin.clear();//clears the error flag on the stdin
                                            std::cin.ignore(1000, '\n');//skips to the next line of input
                                        }
                                        else{
                                            //check input
                                            if(choice < 0 || choice > 7){
                                                std::cout << "Invalid campus location... Please try again.\n\n";
                                            }
                                            else{
                                                //good input -> find campus shipments
                                                //all_schedules.at(choice)->display_details();
                                            }
                                        }

                                        std::cout << "Would you like to view another schedule? (y/n) : ";
                                        std::cin >> go_again;
                                        while(go_again != "y" && go_again != "n"){
                                            std::cout << "Sorry, I don't understand. Would you like to view another schedule? (y/n) : ";
                                            std::cin >> go_again;
                                        }
                                    }while(go_again == "y");
                                    break;
                                }
                                default: {
                                    std::cout << "Invalid choice... Try again\n";
                                    system("pause");
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            system("cls");
        }
    }
    else{
        //user
        std::cout << "What is your appointment ID? : ";
        int appointment_id;
        if(!(std::cin >> appointment_id)){
            std::cout << "Invalid input... please only use numbers for your appointment ID.\n\n";
            //clear the cin buffer
            std::cin.clear();//clears the error flag on the stdin
            std::cin.ignore(1000, '\n');//skips to the next line of input
            system("pause");
        }
        else{
            //good input -> look for user appointments
            bool found = false;
            std::vector<Appointment*> user_apmts;
            for(schedule* s : all_schedules){
                for(Appointment* a : s->get_appointments()){
                    if(a->get_id() == appointment_id){
                        found = true;
                        user_apmts.push_back(a);
                        break;
                    }
                }
            }

            if(!found){
                std::cout << "Sorry, I couldn't find that appointment...\n\n";
            }
            else{
                std::cout << "I need to verify who you are. What is your school ID number? : ";
                int school_id;
                if(!(std::cin >> appointment_id)){
                    std::cout << "Invalid input... please only use numbers for your school ID number.\n\n";
                    //clear the cin buffer
                    std::cin.clear();//clears the error flag on the stdin
                    std::cin.ignore(1000, '\n');//skips to the next line of input
                    system("pause");
                }
                else{
                    //good input -> verify identity
                    std::cout << "checking your identity...\n\n";
                    if(user_apmts.at(1)->get_patient()->id == to_string(school_id)){
                        std::cout << "Here are your appointments, " << user_apmts.at(1)->get_patient()->firstname << "\n";
                        for(Appointment* a : user_apmts){
                            //print appointment details
                            a->display_details();
                        }
                        std::cout << "\n";
                    }
                    else{
                        std::cout << "Sorry, that is incorrect.\n\n";
                    }

                    system("pause");
                }
            }
        }

    }
}

bool display_all_appointments()
{
 	//1. Get all appointments to show
    Database db = Database("appointments.csv");

    std::vector<std::vector<std::string>> db_rows = db.get_rows();

    std::vector<Appointment *> all_apmts;

    for (std::vector<std::string> row : db_rows)
    {
            //create apmt obj
            Appointment *temp_apmt = new Appointment();
            //set members
            temp_apmt->set_id(stoi(row.at(0)));
            temp_apmt->init_from_existing();
            //past apmt
            all_apmts.push_back(temp_apmt);
        
    }

	//2. For each appointment, call->show_details() method
    for (int i = 0; i < all_apmts.size();i++)
    {
        Appointment *temp = all_apmts[0];
        temp->display_details();
    }
    return true;
}

int display_orders_by_campus(campus* c){
    int orders_found = 0;
    Database db = Database("orders.csv");
    std::vector<std::vector<std::string>> db_rows = db.get_rows();

    for(std::vector<std::string> row : db_rows){
        if(stoi(row.at(1)) == c->get_location_id()){
            //print order details
            Order o = Order();
            o.set_id(stoi(row.at(0)));
            if(o.init_from_existing()){
                //print details
                //o.display_details();
                orders_found++;
            }
        }
    }
    return orders_found;
}

int display_shipments_by_campus(campus* c){
    int shipments_found = 0;
    Database db = Database("shipments.csv");
    std::vector<std::vector<std::string>> db_rows = db.get_rows();

    for(std::vector<std::string> row : db_rows){
        if(stoi(row.at(2)) == c->get_location_id()){
            //print shipment details
            Shipment s = Shipment();
            s.set_id(stoi(row.at(0)));
            if(s.init_from_existing()){
                //print details
                //s.display_details();
                shipments_found++;
            }
        }
    }
    return shipments_found;
}

bool display_order_by_id(int id)
{
    Order *temp_order;
    temp_order->set_id(id);
    temp_order->init_from_existing();

    if(!temp_order->init_from_existing())
    {
        return false;
    }
    //temp_order->display_details();  //display_details() not finished?

    return true;
}

bool display_shipment_by_id(int id) 
{
    Shipment *ship;
    ship->set_id(id);
    ship->init_from_existing();

    if(!ship->init_from_existing())
    {
        return false;
    }
    //ship->display_details();  //display_details() in development

    return true;
}


bool display_appointment_by_id(int id)
{
    Appointment *selected_appt; //Create appointment pointer
    selected_appt = find_appointment_by_id(id); //set it to id

    if(!selected_appt->init_from_existing()) //Were we able to get the appointment info from the database?
    {
        return false; //no.
    }
    else ///Yes!...
    {
        selected_appt->display_details(); //display the info
        return true;
    }
}



void display_all_orders()
{
    Database db = Database("orders.csv");
    std::vector<std::vector<std::string>> db_rows = db.get_rows();

    for(std::vector<std::string> row : db_rows){
        Order o = Order();
        o.set_id(stoi(row.at(0)));
        if(o.init_from_existing()){
            //print order details
            //o.display_details(); //Function not finished?
        }
    }
}


void display_all_shipments()
{
    Database db = Database("shipments.csv");
    std::vector<std::vector<std::string>> db_rows = db.get_rows();
    
    for(std::vector<std::string> row : db_rows){
        Shipment s = Shipment();
        s.set_id(stoi(row.at(0)));
        if(s.init_from_existing()){
            //print shipment details
            //s.display_details(); //Function not finished?
        }
    }
}


bool display_low_demand_alerts()
{
    int temp_campus_id = -1; //The ID to check the campus against
    int temp_campus_suppply = -1;
    int campus_appointment_count = 0;
    bool any_low_demand = false;
    
   std::string campus_names[] = { "Ashtabula", "East Liverpool", "Geauga", "Kent", "Salem", "Stark", "Trumbull", "Tuscarawas"};
    
    Database db = Database("supplies.csv"); //Supply database
    std::vector<std::vector<std::string>> db_rows = db.get_rows();


    Database adb = Database("appointments.csv"); //Appointment database
    std::vector<std::vector<std::string>> adb_rows = adb.get_rows();


    for(std::vector<std::string> row : db_rows){
        
        temp_campus_id = stoi(row.at(0)); //Get the campus ID from this db row
        
        temp_campus_suppply = stoi(row.at(1)); //get this campus's supply count

        //Get appointment count for this campus?
        for (std::vector<std::string> arow : adb_rows)
        {
            if(stoi(arow.at(4)) == temp_campus_id) //Search each appointment to see if it is happening at the current campus
            {
                campus_appointment_count++; //Add one to the appointment counter
            }
        }

        //See if there is low demand for this campus
        if((temp_campus_suppply * 0.8) >= campus_appointment_count)
        {
            //Output which campus has low demand
            cout << "Low demand at the " << campus_names[temp_campus_id] << " campus!\n";
            //cout << "Low demand at the " << all_campuses.at(temp_campus_id)->get_location() << " campus!\n";

            any_low_demand = true; //Marks if any campus has an alert
        }
       
        campus_appointment_count = 0; //Reset appointment counter each loop
    }

    //Everywhere has adequate number of appointments set
    if(!any_low_demand)
    {
        cout << "No campus has low demand.\n";

    }

    return any_low_demand;

}

