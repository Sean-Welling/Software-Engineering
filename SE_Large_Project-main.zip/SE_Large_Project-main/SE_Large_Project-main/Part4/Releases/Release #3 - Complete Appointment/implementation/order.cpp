#include "../headers/order.h"

/**************************************************************************
 * Implementation of order.h
 *************************************************************************/

//Setters
bool Order::set_id(int id)
{
    this->id = id;
    if (this->id == id)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool Order::set_doses_needed(int doses_needed)
{
    this->doses_needed = doses_needed;
    if (this->doses_needed == doses_needed)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool Order::set_requester_id(int requester_id)
{
    this->requester_id = requester_id;
    if (this->requester_id == requester_id)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool Order::set_date_requested(std::string date_requested)
{
    this->date_requested = date_requested;
    if (this->date_requested == date_requested)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool Order::set_fulfilled(int fulfilled)
{
    this->fulfilled = fulfilled;
    if (this->fulfilled == fulfilled)
    {
        return true;
    }
    else
    {
        return false;
    }
}

//Getters
int Order::get_id()
{
    return this->id;
}
int Order::get_doses_needed()
{
    return this->doses_needed;
}
int Order::get_requester_id()
{
    return this->requester_id;
}
std::string Order::get_date_requested()
{
    return this->date_requested;
}
int Order::get_fulfilled()
{
    return this->fulfilled;
}

int Order::determine_doses_needed(Supply s)
{

    return 0;
}

void Order::send_order()
{
    // Create stream
    std::ofstream order_db;

    // Open file
    order_db.open("../database/orders.csv", std::ios_base::app);

    // Add to database
    order_db << this->id << "," << this->requester_id << "," << this->doses_needed << "," << this->date_requested << "," << this->fulfilled << std::endl;

    // Close file
    order_db.close();

    return;
}

bool populate_order(int num_doses){
    
        string dose_array[2];
        short loop=0;
        string line;
        ifstream myfile ("order.cvs");
    
        if (myfile.is_open())
        {
            while (! myfile.eof() )
            {
                getline (myfile,line);
                dose_array[loop] = line;
                cout << dose_array[loop] << endl;
                loop++;
            }
            myfile.close();
        }
        else cout << "can't open the file";
        system("PAUSE");
    
    vector<string> dose_vec(dose_array, dose_array + sizeof(dose_array)/sizeof(std::string));
    
    for(string str : dose_vec)
        cout << str << endl;
    
    return 0;
};

display_details(){
    
    int line = 2;
    
    std::ifstream f("orders.csv");
    std::string s;

    cout << "what order whould you like to see: " << endl;
    cin >> line;
    
    for (int i = 0; i <= line; i++)
            std::getline(f, s);

    std::cout << s;
    return 0;
    };

bool Order::init_from_existing(){
    //check that id is set
    if(this->id == -1){
        return false;
    }
    else{
        Database db = Database("orders.csv");
        std::vector<std::vector<std::string>> db_rows = db.get_rows();

        for(std::vector<std::string> row : db_rows){
            if(stoi(row.at(0)) == this->id){
                //set member values
                this->requester_id = stoi(row.at(1));
                this->doses_needed = stoi(row.at(2));
                this->date_requested = row.at(3);
                this->fulfilled = stoi(row.at(4));
                return true;
            }
        }
        return false;
    }
}
