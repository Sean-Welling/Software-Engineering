#include <iostream>

#include "../headers/Database.h"

int main(){
    Database* db = new Database();
    db->set_filename("orders.csv");
    
    std::vector<std::string> temp = {"temp1", "temp2", "temp3"};

    db->add_row(temp);

    return 0;
}