/*
   campus.h

   Declaration file for the campus class.
   
*/

#ifndef campus_h
#define campus_h

#include <string>
#include "supply.h"
#include "schedule.h"

using namespace std;

/**
   A representation of a physical KSU campus

   @author Daniel Earley
*/
class campus
{
public:
	
	void set_location(int campus_index);
	string get_location(); //Returns the location name of the campus

	
	int get_supply_count(); //Returns how many vaccines are available from its 'supply' object

	bool receive_shipment();
	float receive_payment();
	void send_payment(float payment_amount);

	/**
	 * Gets the id of this appointment's location
	 * @return location's index/id
	 * @author Clay
	 */
	int get_location_id();

private:
	string location;
	Supply campus_supply;
	schedule* campus_schedule;
	float account_balance;
};

#endif
