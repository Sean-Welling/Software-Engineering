/*
    Header file for custom Date class

    Date Created: 04/22/2021

    Author: Clay
*/

#ifndef date_h
#define date_h

#include <string>
#include <iostream>
#include <vector>
#include <time.h>

class Date
{
private:
    int month = 0;
    int day = 0;
    int year = 0;

public:
    //Constructors
    Date();
    Date(int month, int day, int year);
    Date(std::string month, std::string day, std::string year);
    /**
         * Constructs a new date object given the date as one string in the format : mm/dd/yyyy
         * @author Clay
         */
    Date(std::string full_date);

    //Setters
    bool set_month(int month);
    bool set_day(int day);
    bool set_year(int year);

    //Getters
    int get_month();
    int get_day();
    int get_year();

    //Other

    /**
         * Returns an array pointer to 3 strings in the format : [month, day, year]
         * Acceptable string formats - 
         * mm/dd/yy
         * mm-dd-yy
         * @author Clay
         */
    std::string *parse_date_string(std::string date, std::string format);

    /**
         * Splits a string into substrings given a delimeter
         * @return Vector of strings
         * @author Clay
         */
    std::vector<std::string> split_string(std::string base, char delim);

    /**
         * Prints this date's members given the format
         * Acceptable formats - 
         * mm/dd/yyyy
         * mm/dd/yy
         * mm-dd-yyyy
         * mm-dd-yy
         * @author Clay
         */
    void print_date(std::string format);

    /**
         * Gets this dates formatted string
         * @param format The format to put the string into
         * @return String
         * Acceptable formats - 
         * mm/dd/yyyy
         * mm/dd/yy
         * mm-dd-yyyy
         * mm-dd-yy
         * @author Clay
         * @date 04/24/2021
         */
    std::string get_formatted(std::string format);

    /**
         * Finds the delimeter in the given date string
         * @return success: delim | failed to find delim: m
         * Constraints: The delimeter cannot be m, d, or y
         * @author Clay
         */
    char get_delim(std::string date);

    /**
         * Formats the element that only has 1 character as an int but requires 2 characters in string format
         * @param element The element that needs formatted
         * @example format_element_string(5) -> "05"
         * @author Clay
         */
    std::string format_element_string(int element);

    /**
         * Checks if this date is a leap year
         * @returns 1: leap year | 0: not leap year | -1: error
         * @author Clay
         * @date 04/23/2021
         */
    int is_leap_year();

    /**
         * Setting this date's members from the given string
         * @returns true: success | false: failed
         * @author Clay
         * @date 04/24/2021
         */
    bool init_from_date_string(std::string date_string);
};

//  https://docs.microsoft.com/en-us/office/troubleshoot/excel/determine-a-leap-year

/**
 * Checks if the first date is earlier, the same, or later than the second date
 * @param date1 Date obj pointer
 * @param date2 Date obj pointer
 * @return -1: date1 is earlier than date2 | 1: date1 is later than date2 | 0: dates are the same
 */
int compare_dates(Date *date1, Date *date2);

/**
 * Allows for subtracting date objects
 * @returns Date that has members indicating the diffence in the difference members
 * @author Clay
 */
Date operator-(Date d1, Date d2);

/**
 * Allows for adding to one of the date members
 * @returns New date object
 * @author Clay
 * @date 04/24/2021
 * @example inp: Date("05/25/2021") + 3 -> output: Date("05/28/2021")
 */
Date operator+(Date &d1, int change);

/**
 * Allows for subtracting from one of the date members
 * @returns New date object
 * @author Clay
 * @date 04/26/2021
 * @example inp: Date("05/25/2021") - 3 -> output: Date("05/22/2021")
 */
Date operator-(Date &d1, int change);

/**
 * Gets the current date 
 * @return current date :: curr_date = mm/dd/YYYY
 */
const std::string get_curr_date();

/**
 * Gets the number of days in the given month
 * @param month_num The number of the month (1 based) : Jan = 1, Feb = 2, etc
 * @param leap_year If this month resides in a leap year
 * @return Int : Number of days in the month
 * @author Clay
 * @date 04/27/2021
 */
int get_month_days(int month_num, bool leap_year);

#endif