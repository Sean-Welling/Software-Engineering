#include <iostream>
#include <cstdlib> //   For srand()
#include <ctime> //     For random time seed

#include "../headers/Appointment.h"
#include "../headers/campus.h"
#include "../headers/LowDemand.h"
#include "../headers/order.h"
#include "../headers/patient.h"
#include "../headers/payment.h"
#include "../headers/schedule.h"
#include "../headers/shipment.h"
#include "../headers/studentStaff.h"
#include "../headers/Supply.h"
#include "../headers/vaccine.h"
#include "../headers/Date.h"
#include "../headers/Database.h"


//system specific functionality
bool register_patient();

bool modify_appointment();

/**
 * Checks for past appointments
 * Removes them from the log
 * Updates campus supplies
 * Processes incoming shipments
 * Processes outgoing orders
 * @returns int error code
 */
int system_init();

/**
 * Simulates a vaccine manufacturer processing orders and sending shipments. 
 * Finds all orders that were requested on the previous day. 
 * Calculates the number of vaccines that should be sent in shipment. 
 * "Sends"(logs) the shipment
 * @returns true: success | false: failed
 * @author Clay
 * @date 04/24/2021
 */
bool process_orders();


/*
* Initializes all campus schedules
* Creates schedules
* Populates schedules 
*/
bool init_campus_schedules();

void view_information();


/**
 * Display Appointment details for all appointments
 * Get all appointments
 * Call show_details
 * @return true
 * @author Sean
 * @date 04/28/2021
 */
bool display_all_appointments();

/**
 * Displays all the orders requested by the given campus
 * @returns Number of orders found
 * @author Clay
 * @date 04/28/2021
 */
int display_orders_by_campus(campus* c);

/**
 * Displays all the shipments requested by the given campus
 * @returns Number of shipments found
 * @author Clay
 * @date 04/28/2021
 */
int display_shipments_by_campus(campus* c);

/**
 * Displays the order requested by its id
 * @returns true : successful | false : failed
 * @author Sean
 * @date 04/28/2021
 */
bool display_order_by_id(int id);

/**
 * Displays the shipment details by its id
 * @returns true : successful | false : failed
 * @author Sean
 * @date 04/28/2021
 */
bool display_shipment_by_id(int id);


/**
 * Displays the appointment details by its id
 * @returns true if the id was found, otherwise false
 * @author Daniel
 * @date 04/29/2021
 */
bool display_appointment_by_id(int id);




/**
 * displays info for all the vaccine orders 
 * @author Daniel Edited Clay's display_orders_by_campus() function
 * @date 04/29/2021
 */
void display_all_orders();


/**
 * displays info for all vaccine shipments
 * @author Daniel Edited Clay's display_shipments_by_campus() function
 * @date 04/29/2021
 */
void display_all_shipments();



/**
 * Shows an alert saying which campuses have low demand
 * @returns true if one or more campuses had low demand 
 * @author Daniel
 * @date 04/29/2021
 */
bool display_low_demand_alerts();


