//
//  Supply.h
//
//
//  Created by Arthur Wolff on 3/18/21.
// Expanded by Daniel Earley on 2021-04-10
//

#ifndef Supply_h
#define Supply_h

#include <list>
using namespace std;

// ----- Relationships -------
// Vaccine: Aggregation
// Low Demand: Association
// Campus: Association
// Shipment: Association

class Supply
{
public:
   
    
    int get_vaccine_count(); //Gets the total number of vaccines available 
    
    bool vaccine(int item) const;

private:
    int count; //how many vaccines are available of all brands
    
};

#endif