#include "../headers/studentStaff.h"
#include "../headers/patient.h"
#include "../headers/System.h"
#include "studentStaff.cpp"
#include "patient.cpp"
 
int main()
{
    studentStaff *ss = new studentStaff();
    patient *p = new patient();
     
    p->register_patient(p, ss);

    std::cout << "KSU ID: " << p->id << endl;
    std::cout << "Username: " << p->username << endl;
    std::cout << "First Name: " << p->firstname << endl;
    std::cout << "Last Name: " << p->lastname << endl;
    std::cout << "Role: " << p->role << endl;
    std::cout << "Address: " << p->address << endl;
    std::cout << "Phone: " << p->phone << endl;
    std::cout << "Age: " << p->age << endl;

    patient *p2 = new patient();

    p2->get_patient(p2);

    std::cout << "KSU ID: " << p2->id << endl;
    std::cout << "Username: " << p2->username << endl;
    std::cout << "First Name: " << p2->firstname << endl;
    std::cout << "Last Name: " << p2->lastname << endl;
    std::cout << "Role: " << p2->role << endl;
    std::cout << "Address: " << p2->address << endl;
    std::cout << "Phone: " << p2->phone << endl;
    std::cout << "Age: " << p2->age << endl;
    std::cout << "Patient ID : " << p2->patient_id_num << endl;
    std::cout << "Vaccine: " << p2->vaccine_type << endl;

    std::cout << "Done!\n";

    return 0;
} 