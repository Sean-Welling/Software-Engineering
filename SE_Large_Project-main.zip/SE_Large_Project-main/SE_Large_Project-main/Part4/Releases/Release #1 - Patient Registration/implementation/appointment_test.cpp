#include "../headers/Appointment.h"
#include "../headers/patient.h"
#include "../headers/System.h"

int main()
{
    patient *p = new patient();

    Appointment *ap = new Appointment();

    ap->find_available_id();

    ap->set_date("03/25/2021");

    ap->get_second_date(14);

    // if (!ap->set_id(1))
    // {
    //     std::cout << "Failed to set id\n";
    // }
    // else
    // {
    //     std::cout << "Appointment ID : " << ap->get_id() << "\n\n";
    // }
    // std::cout << "Appointment ID: " << ap->get_id() << '\n';
    // ap->set_patient(p);
    // ap->set_date("04/07/2021");
    // ap->set_time("15:00");

    // if (ap->log_appointment() == 0)
    // {
    //     print_padded("Successfully logged appointment");
    // }
    // else
    // {
    //     print_padded("Couldn't log appointment");
    // }

    // std::cout << "Test finished.\n\n";

    std::cout << "Done!\n";

    return 0;
}