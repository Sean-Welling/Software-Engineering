#include "../headers/patient.h"

/**************************************************************************
 * Implementation of patient.h
 *************************************************************************/

std::vector<std::string> patient::get_studentStaff(studentStaff *ss){
    std::vector<std::string> new_record;
    new_record = ss->get_user_info();

    /*
    cout << "Record ID: " << new_record[0] << "\n"
         << "Record Username: " << new_record[1] << endl;
    */
    //return this->self;
    return new_record;
}

patient::patient()
{
    std::cout << "Creating new patient record from the KSU DB...\n";
    //std::vector<std::string> patient_record;
    //patient_record = get_user_info();
    //string id, username, firstname, lastname, role, address, phone, age = patient::get_studentStaff();
}

void patient::register_patient(patient *p, studentStaff *ss)
{
    // Set patient attributes using studentStaff record
    std::vector<std::string> new_record = get_studentStaff(ss);
    id = new_record[0];
    username = new_record[1];
    firstname = new_record[2];
    lastname = new_record[3];
    role = new_record[4];
    address = new_record[5];
    phone = new_record[6];
    age = new_record[7];

    // Assign KSU-HS ID number
    patient_id_num = "ksuhs" + id;

    // Add patient record to patient database

        // Create stream
        std::ofstream database;

        // Open file
        database.open("../database/patient.csv", std::ios_base::app);
        database << id << "," << username << "," << firstname << "," << lastname << "," << role << "," << address << "," << phone << "," << age << "," << patient_id_num << std::endl;
        database.close();
}

void patient::get_patient(patient *p)
{
    std::cout << "Please enter your Patient ID Number: \n";
    std::cin >> patient_id_num;
    std::cout << "Gathering patient records from the KSU_HS Patient DB...\n";

    // Create studentStaff record to be returned
    std::vector<std::string> record;

    // Create stream
    std::ifstream database;

    // Open file
    database.open("../database/patient.csv");

    bool found_record = false;

    std::string record_one;
    std::string record_two;
    std::string record_three;
    std::string record_four;
    std::string record_five;
    std::string record_six;
    std::string record_seven;
    std::string record_eight;
    std::string record_nine;
    std::string record_ten;

    while (getline(database, record_one, ',') && !found_record)
    {
        getline(database, record_two, ',');
        getline(database, record_three, ',');
        getline(database, record_four, ',');
        getline(database, record_five, ',');
        getline(database, record_six, ',');
        getline(database, record_seven, ',');
        getline(database, record_eight, ',');
        getline(database, record_nine, ',');
        getline(database, record_ten, '\n');

        if (record_nine == patient_id_num)
        {
            found_record = true;
            record.push_back(record_one);
            record.push_back(record_two);
            record.push_back(record_three);
            record.push_back(record_four);
            record.push_back(record_five);
            record.push_back(record_six);
            record.push_back(record_seven);
            record.push_back(record_eight);
            record.push_back(record_nine);
            record.push_back(record_ten);
        }
    }

    std::cout << record[0] << " " << record[1] << " " << record[2] << " " << record[3] << " " << record[4] << " " << record[5] << " " << record[6] << " " << record[7] << " " << record[8] << " " <<  record[9] << "\n";

    id = record[0];
    username = record[1];
    firstname = record[2];
    lastname = record[3];
    role = record[4];
    address = record[5];
    phone = record[6];
    age = record[7];
    patient_id_num = record[8];
    vaccine_type = record[9];

    // Close file
    database.close();

}