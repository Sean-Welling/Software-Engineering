#include "../headers/studentStaff.h"

/**************************************************************************
 * Implementation of studentStaff.h
 *************************************************************************/
studentStaff::studentStaff(){
    //std::cout << "Creating studentStaff.\n\n";
    std::cout << "Please enter Student or Faculty ID number: " << std::endl;
    std::cin >> id_num;
}

std::vector<std::string> studentStaff::get_user_info()
{

    std::cout << "Gathering Student and Faculty records from the KSU DB...\n";

    // Create studentStaff record to be returned
    std::vector<std::string> record;

    // Create stream
    std::ifstream database;

    // Open file
    database.open("../database/studentStaff.csv");

    bool found_record = false;

    std::string record_one;
    std::string record_two;
    std::string record_three;
    std::string record_four;
    std::string record_five;
    std::string record_six;
    std::string record_seven;
    std::string record_eight;

    while(getline(database, record_one, ',') && !found_record) 
    {
        getline(database,record_two,',');
        getline(database,record_three,',');
        getline(database,record_four,',');
        getline(database,record_five,',');
        getline(database,record_six,',');
        getline(database,record_seven,',');
        getline(database,record_eight,'\n');

        if (record_one == id_num)
        {
            found_record = true;
            record.push_back(record_one);
            record.push_back(record_two);
            record.push_back(record_three);
            record.push_back(record_four);
            record.push_back(record_five);
            record.push_back(record_six);
            record.push_back(record_seven);
            record.push_back(record_eight);
        }
    }

    std::cout << record[0] << " " << record[1] << " " << record[2]<< " " << record[3]<< " " << record[4]<< " " << record[5]<< " " << record[6]<< " " << record[7] << "\n";

    // Close file
    database.close();

    return record;
}