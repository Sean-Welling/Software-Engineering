//
//  supply.cpp
//
//
//  Created by Arthur Wolff on 3/22/21.
//  Expanded by Daniel Earley on 2021-04-10
// 
//

#include "../headers/Supply.h"

/*
 
 Implementation of Supply.h

 */

int Supply::get_vaccine_count()
{
	return count;
}
