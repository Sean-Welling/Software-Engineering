#include "../headers/campus.h"

/**************************************************************************
 * Implementation of campus.h
 *************************************************************************/


//Array of campus names (alphabetical)
std::string campus_names[] = { "Ashtabula", "East Liverpool", "Geauga", "Kent", "Salem", "Stark", "Trumbull", "Tuscarawas"};

int get_avg_days_to_receive_shipment(){ 
    
    int avg=0;
    int shipment1=1, shipment2=1, shipment3=1;
    string s;
    
    ifstream file("shipments.csv");
    if (file.is_open()){
        
        string line;
        getline(file, line);
        
        vector<int> date_sent;
        vector<int> estimated_receive_date;
        
        shipment1 = estimated_receive_date[1] - date_sent[1];
        shipment2 = estimated_receive_date[2] - date_sent[2];
        shipment3 = estimated_receive_date[3] - date_sent[3];
        
        avg = (shipment1 + shipment2 + shipment3)/3;
        
        return avg;
    }

}


Supply* campus::init_supply()
{
	Supply* created_supply = new Supply; //creates the supply pointer
    created_supply->set_vaccine_count(0); // set the supply count
    
    return created_supply; //returns the supply object
}

Supply* campus::get_supply()
{	
	Supply *temp_supply = new Supply(this->campus_supply);
	return temp_supply;
}

void campus::set_supply(Supply* s)
{
	campus_supply = *s; //sets the supply to the provided pointer
}

bool campus::verify_order()
{
	// Create stream
	std::ifstream order_db;

	// Open file
	order_db.open("../database/orders.csv");

	std::string order_id;
	std::string sender_id;
	std::string doses_requested;
	std::string date_requested;
	std::string fulfilled;

	while (getline(order_db, order_id, ','))
	{
		getline(order_db, sender_id, ',');
		getline(order_db, doses_requested, ',');
		getline(order_db, date_requested, ',');
		getline(order_db, fulfilled, '\n');


		if (this->get_location_id() == stoi(sender_id))
		{
			// Close file
			order_db.close();
			return true;
		}
	}

	// Close file
	order_db.close();
	return false;
}

void campus::set_location(int campus_index)
{
	location = campus_names[campus_index];
}

string campus::get_location()
{
	return location;
}


int campus::get_supply_count()
{
	return campus_supply.get_vaccine_count();
}

int campus::get_location_id(){
	for(int i = 0; i < sizeof(campus_names)/sizeof(campus_names[0]); i++){
		if(campus_names[i] == this->location){
			return i;
		}
	}
	return -1;
}

int campus::get_days_to_run_out(int past_week_count, int next_week_count)
{
	/*
	//This is all getting moved out of the function due to the circular include issue
	string curr_date = get_curr_date(); //string with current date
	Date temp = Date(curr_date);
	Date next_week(temp + 7); //the date of the end of next week (7 days later)
	Date last_week; //the starting date of last week ???
	int next_week_count = 0;
	int past_week_count = 0;
	
	//Need to find out how to get a date to a string for these functions here
	next_week_count = campus_schedule.find_avg_appointments_completed_per_day(curr_date, ???, false); //find number of appointments next week
	past_week_count = campus_schedule.find_avg_appointments_completed_per_day(???, curr_date, false); //find number of appointments last week
	*/

	int average_per_day = 0;

	if(past_week_count > (next_week_count * 1.10)) //If we used more doses last week then we are schduled to next week (plus a bit more), use last week's total as a baseline for the average count
	{
		average_per_day = int(past_week_count / 7); 
	}
	else //We are sceduled to use the same number or more doses from last week, so use that count and add some extra since more people may schedule before the end of the week
	{
		average_per_day = int((next_week_count * 1.15) / 7); // %115 of the schduled appointments, divided by 7 days
	}


	if(average_per_day <= 0)//the daily doses used is less than one
	{
		if(next_week_count == 0) //Literally no one is schduled for the next week, so we should be fine for a long while
		{
			return 30; //The large number will prevent an unneccessary order from happening, although this function will be called frequently enough it will be updated if more appointments are schedulded
		}
		else
		{
			average_per_day = 1; //prevents a divid by 1 error if there are less than 7 appointments next week. Could also return some set number instead if wanted
		}

	}

	return int(((campus_supply.get_vaccine_count()) / average_per_day) - 0.5); //how many vaccines we have over how many we are using per day, and then minus 0.5 to round the days down for a bit more leeway
}


bool campus::need_to_order(int past_week_count, int next_week_count)
{
	if(get_avg_days_to_receive_shipment() == 0) //There is no average found, i.e. no orders have been received yet
	{
		if(get_days_to_run_out(past_week_count, next_week_count) < 10) //we don't know how long it takes to recieve a shipment, but will we run out in under a week?
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	if ((get_avg_days_to_receive_shipment() + 3) >= get_days_to_run_out(past_week_count, next_week_count)) //Check if we can get a shipment sooner than when we'll run out. Includes a 3 day leeway
	{
		return true;
	}
	else
	{
		return false;
	}

}

int campus::get_avg_days_to_receive_shipment(){
	return 1;
}


std::vector<Order*> campus::get_past_orders(std::string start_date, std::string end_date, bool all){
	std::vector<Order*> past_orders;

	//Open orders database
	Database order_db = Database("orders.csv");

	if(all){
		//get all orders for this campus
		for(int i = 0; i < order_db.get_num_rows(); i++){
			std::vector<std::string> curr_row = order_db.get_rows().at(i);
			//create order object
			Order* temp_order = new Order();
			//set order members
			temp_order->set_id(stoi(curr_row.at(0)));
			temp_order->set_requester_id(stoi(curr_row.at(1)));
			temp_order->set_doses_needed(stoi(curr_row.at(2)));
			temp_order->set_date_requested(curr_row.at(3));
			temp_order->set_fulfilled(stoi(curr_row.at(4)));

			//add order to list
			past_orders.push_back(temp_order);
		}
	}
	else{
		Date* start_date_obj = new Date(start_date);
		Date* end_date_obj = new Date(end_date);

		//find orders between the given dates
		for(int i = 0; i < order_db.get_num_rows(); i++){
			std::vector<std::string> curr_row = order_db.get_rows().at(i);
			//check if campus is correct
			if(stoi(curr_row.at(1)) == this->get_location_id()){
				//same campus
				//create order object
				Order* temp_order = new Order();
				//set order members
				temp_order->set_id(stoi(curr_row.at(0)));
				temp_order->set_requester_id(stoi(curr_row.at(1)));
				temp_order->set_doses_needed(stoi(curr_row.at(2)));
				temp_order->set_date_requested(curr_row.at(3));
				temp_order->set_fulfilled(stoi(curr_row.at(4)));

				//check if in between the dates
				Date* order_date = new Date(curr_row.at(3));

				int start_date_cmp = compare_dates(order_date, start_date_obj);
				int end_date_cmp = compare_dates(order_date, end_date_obj);
				if((start_date_cmp == 0 || start_date_cmp == 1) && (end_date_cmp == 0 || end_date_cmp == -1)){
					//add order to list
					past_orders.push_back(temp_order);
				}
			}
		}
	}
	return past_orders;
}

int campus::estimate_num_doses_needed(int avg_appointments_completed_per_day){
	/*
		Algorithm - Should make it so that the probablity that two orders are awaiting fulfillment at the same time for this campus is low 
	*/

	//calculate the num doses to last for the avg time between placing a new order and receiving the shipment
	int num_doses = this->get_avg_days_to_receive_shipment() * avg_appointments_completed_per_day;
	return num_doses;
}
