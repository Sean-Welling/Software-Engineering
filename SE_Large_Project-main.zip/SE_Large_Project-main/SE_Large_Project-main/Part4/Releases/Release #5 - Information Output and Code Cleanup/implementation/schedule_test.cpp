#include <iostream>

#include "../headers/schedule.h"

int main()
{
    campus *c = new campus();
    c->set_location(0);

    Database db = Database("appointments.csv");
    db.print_database();

    schedule s = schedule();
    std::vector<Appointment*> campus_appointments = find_appointments_by_campus(c);
    for(Appointment* a : campus_appointments){
        std::cout << "ID : " << a->get_id() << "\n";
    }
    s.set_appointments(campus_appointments);

    //test for schedule->display_details
    //s.display_details();

    // //get past apmts : Arthur
    // //std::cout << "Past appointments in this schedule : " << s.get_past_apmts().size() << " apmts\n";

    //get_avg_appointments_completed_per_day : Clay
    //std::cout << "Avg appointments per day : " << s.find_avg_appointments_completed_per_day("04/05/2021", "04/08/2021") << "apmts/day\n"; //might need to get rid of all flag

    //test for schedule->get_appointments_in_range
    // std::vector<Appointment*> schedule_appointments = s.get_appointments_in_range("03/01/2021", "09/05/2021");

    // for(Appointment* a : schedule_appointments){
    //     std::cout << "apmt id : " << a->get_id() << " on " << a->get_date() << " at " << a->get_time() << "\n";
    // }

    return 0;
}