#include <iostream>

#include "../headers/order.h"

int main(){
    std::cout << "Testing order...\n\n";

    Order o = Order();
    
    //Testing order->init_from_existing
    // o.set_id(1);
    // if(o.init_from_existing()){
    //     std::cout << "Date requested : " << o.get_date_requested() << "\n";
    // }

    // o.set_date_requested("05/20/2021");
    // o.set_doses_needed(100);
    // o.set_fulfilled(0);
    // Database db = Database("orders.csv");
    // int id = db.find_available_id("order_id");
    // o.set_id(id);
    // o.set_requester_id(0);

    // //populate order - couldn't find : Arthur

    // //send_order : Sean
    // o.send_order();

    return 0;
}