//
//  supply.cpp
//
//
//  Created by Arthur Wolff on 3/22/21.
// 
//

#include "../headers/Supply.h"
#include <iostream>

//setters
bool Supply::set_id(int id){
    this->id = id;
    if(this->id == id){
        return true;
    }
    else{
        return false;
    }
}

//getters
int Supply::get_id(){
    return this->id;
}

//Other
bool Supply::init(){
    //check if ID is set
    if(this->id != -1){
        //open db
        Database db = Database("supplies.csv");

        std::vector<std::vector<std::string>> db_rows = db.get_rows();

        //find the supply record
        for(std::vector<std::string> row : db_rows){
            //check if row supply id == this id
            if(stoi(row.at(0)) == this->id){
                //found the record -> set this supply's members
                this->count = stoi(row.at(1));

                //break the loop to save time
                return true;
            }
        }
        //didn't find record
        return false;
    }
    else{
        return false;
    }
}

void update_supply(int change){
    
    int stark_count = 1 ,tusk_count = 1, main_count = 1, eliver_count = 1 ,geauga_count = 1, salem_count = 1, trum_count = 1, ash_count = 1;
    int university_count = stark_count+tusk_count+main_count;
    char vac_pick;
    int yn, repeat_yn;;

// shows supply levels
    std::cout << " Kent Main: " << main_count << std::endl;
    std::cout << " Stark: " << stark_count << std::endl;
    std::cout << " Tuscarawas: " << tusk_count << std::endl;
    std::cout << " East Liverpool: " << eliver_count << std::endl;
    std::cout << " Geauga: " << geauga_count << std::endl;
    std::cout << " Salem: " << salem_count << std::endl;
    std::cout << " Trumbull: " << trum_count << std::endl;
    std::cout << " Ashtabula: " << ash_count << std::endl;
    std::cout << " Total university supply: " << university_count << std::endl;
    std::cout << " does this supply count look correct?" << std::endl;
    std::cout << " if not press 0" << std::endl;
    cin >> yn;
    
// choose what suppy to edit
    if (yn == 0){
        std::cout << " which vaccice supply is incorrect?" << std::endl;
        std::cout << " press k for Stark" << std::endl;
        std::cout << " press t for Tuscarawas" << std::endl;
        std::cout << " press e for East Liverpool" << std::endl;
        std::cout << " press g for Geauga" << std::endl;
        std::cout << " press b for Trumbull" << std::endl;
        std::cout << " press s for Salem" << std::endl;
        std::cout << " press a for Ashtabula" << std::endl;
        std::cout << " press m for kent main" << std::endl;
        cin >> vac_pick;
   
// changes supply levels based on entry
        if (vac_pick == 'k'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> stark_count;
        }
        if (vac_pick == 't'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> tusk_count;
        }
        if (vac_pick == 'm'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> main_count;
        }
        if (vac_pick == 'e'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> eliver_count;
        }
        if (vac_pick == 'a'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> ash_count;
        }
        if (vac_pick == 'b'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> trum_count;
        }
        if (vac_pick == 's'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> salem_count;
        }
        if (vac_pick == 'g'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> geauga_count;
        }
        
        std::cout << " would you like to see the supply again? 1 for yes 0 for no" << std::endl;
        cin >> repeat_yn;
        
        if (repeat_yn == 1){
            std::cout << " Kent Main: " << main_count << std::endl;
            std::cout << " Stark: " << stark_count << std::endl;
            std::cout << " Tuscarawas: " << tusk_count << std::endl;
            std::cout << " East Liverpool: " << eliver_count << std::endl;
            std::cout << " Geauga: " << geauga_count << std::endl;
            std::cout << " Salem: " << salem_count << std::endl;
            std::cout << " Trumbull: " << trum_count << std::endl;
            std::cout << " Ashtabula: " << ash_count << std::endl;
            std::cout << " Total university supply: " << university_count << std::endl;
        }
    };
}




bool Supply::update_log()
{
    //check if ID is set
    if(this->id != -1){
        //open db
        Database db = Database("supplies.csv");

        std::vector<std::vector<std::string>> db_rows = db.get_rows();
        int row_num = -1;
        //find the supply record
        for(std::vector<std::string> row : db_rows){
            //check if row supply id == this id
            row_num++;
            if(stoi(row.at(0)) == this->id){
                

                //Delete the old record
                db.delete_row(row_num);

                //create a new record with the updated count
                std::vector<std::string> new_row = {to_string(this->id), to_string(this->count)};
                db.add_row(new_row); 
                
                 

                //break the loop to save time
                return true;
            }
        }
        //didn't find record
        return false;
    }
    else{
        return false;
    }

}






void Supply::set_vaccine_count(int total_count)
{
    count = total_count;
}


int Supply::get_vaccine_count()
{
	return count;
}


