#include <iostream>

#include "../headers/shipment.h"

int main(){
    std::cout << "testing shipment...\n\n";

    Shipment s = Shipment();

    s.set_id(3);

    //Testing init from existing
    // if(s.init_from_existing()){
    //     std::cout << "Found - date sent : " << s.get_send_date() << "\n";
    // }
    // else{
    //     std::cout << "Couldn't initialize this shipment\n";
    // }
    
    // s.set_receiver_id(1);
    // s.set_received(0);
    // s.set_send_date("05/25/2021");
    // s.set_estimated_arrival_date("05/28/2021");
    // s.set_total_doses(75);

    // s.log();

    return 0;
}