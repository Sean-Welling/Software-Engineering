#include "../headers/patient.h"
 
int main()
{
    // Get an existing or create new patient driver functianlity
        // std::cout << "Are you an existing KSU-HS Patient? (yes/y/no/n): \n";
        // string response;
        // std::cin >> response;

        // patient *pt = new patient();
        // if( response == "no" || response == "n")
        // {
        //     studentStaff *ss = new studentStaff();
        //     pt->register_patient(pt, ss);
        // } 
        // else
        // {
        //     //pt->patient_id_num = response;
        //     pt->get_patient(pt);
        // }

        // std::cout << "KSU ID: " << pt->id << endl;
        // std::cout << "Username: " << pt->username << endl;
        // std::cout << "First Name: " << pt->firstname << endl;
        // std::cout << "Last Name: " << pt->lastname << endl;
        // std::cout << "Role: " << pt->role << endl;
        // std::cout << "Address: " << pt->address << endl;
        // std::cout << "Phone: " << pt->phone << endl;
        // std::cout << "Age: " << pt->age << endl;
        // std::cout << "Patient ID : " << pt->patient_id_num << endl;
        // std::cout << "Vaccine: " << pt->vaccine_type << endl;
        
        


    // General testing of studentStaff and Patient
        /*
        // Registering new patient
        studentStaff *ss = new studentStaff();
        patient *p = new patient();
        
        p->register_patient(p, ss);

        std::cout << "KSU ID: " << p->id << endl;
        std::cout << "Username: " << p->username << endl;
        std::cout << "First Name: " << p->firstname << endl;
        std::cout << "Last Name: " << p->lastname << endl;
        std::cout << "Role: " << p->role << endl;
        std::cout << "Address: " << p->address << endl;
        std::cout << "Phone: " << p->phone << endl;
        std::cout << "Age: " << p->age << endl;


        // Get a current patient
        patient *p2 = new patient();

        p2->get_patient(p2);

        std::cout << "KSU ID: " << pt->id << endl;
        std::cout << "Username: " << pt->username << endl;
        std::cout << "First Name: " << pt->firstname << endl;
        std::cout << "Last Name: " << pt->lastname << endl;
        std::cout << "Role: " << pt->role << endl;
        std::cout << "Address: " << pt->address << endl;
        std::cout << "Phone: " << pt->phone << endl;
        std::cout << "Age: " << pt->age << endl;
        std::cout << "Patient ID : " << pt->patient_id_num << endl;
        std::cout << "Vaccine: " << pt->vaccine_type << endl;
        */

       patient p = patient();
       p.id = 1;
       p.init_from_existing();



    std::cout << "Done!\n";

    return 0;
} 