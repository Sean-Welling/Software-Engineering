#include "../headers/patient.h"

patient::patient()
{
    // std::cout << "Creating patient object...\n";
    //std::vector<std::string> patient_record;
    //patient_record = get_user_info();
    //string id, username, firstname, lastname, role, address, phone, age = patient::get_studentStaff();
    this->id = "not set";
}


std::vector<std::string> studentStaff::get_user_info()
{ 

    std::cout << "Gathering Student and Faculty records from the KSU DB...\n";

    // Create studentStaff record to be returned
    std::vector<std::string> record;

    // Create stream
    std::ifstream database;

    // Open file
    database.open("../database/studentStaff.csv");

    bool found_record = false;

    std::string record_one;
    std::string record_two;
    std::string record_three;
    std::string record_four;
    std::string record_five;
    std::string record_six;
    std::string record_seven;
    std::string record_eight;

    while(getline(database, record_one, ',') && !found_record) 
    {
        getline(database,record_two,',');
        getline(database,record_three,',');
        getline(database,record_four,',');
        getline(database,record_five,',');
        getline(database,record_six,',');
        getline(database,record_seven,',');
        getline(database,record_eight,'\n');

        if (record_one == id_num)
        {
            found_record = true;
            record.push_back(record_one);
            record.push_back(record_two);
            record.push_back(record_three);
            record.push_back(record_four);
            record.push_back(record_five);
            record.push_back(record_six);
            record.push_back(record_seven);
            record.push_back(record_eight);
        }
    }

    std::cout << record[0] << " " << record[1] << " " << record[2]<< " " << record[3]<< " " << record[4]<< " " << record[5]<< " " << record[6]<< " " << record[7] << "\n";

    // Close file
    database.close();

    return record;
}

void patient::register_patient(patient *p, studentStaff *ss)
{
    std::cout << "Are you an existing KSU-HS Patient? (yes/y/no/n): \n";
    string response;
    std::cin >> response;
    if( response == "no" || response == "n")
    {
        // Continue Registration
        // Set patient attributes using studentStaff record 
        std::vector<std::string> new_record = get_studentStaff(ss);
        id = new_record[0];
        username = new_record[1];
        firstname = new_record[2];
        lastname = new_record[3];
        role = new_record[4];
        address = new_record[5];
        phone = new_record[6];
        age = new_record[7];

        // Assign KSU-HS ID number
        patient_id_num = "ksuhs" + id;

        // Add patient record to patient database

        // Create stream
        std::ofstream database;

        // Open file
        database.open("../database/patient.csv", std::ios_base::app);
        database << id << "," << username << "," << firstname << "," << lastname << "," << role << "," << address << "," << phone << "," << age << "," << patient_id_num << std::endl;
        database.close();
    } 
    else
    {
        p->get_patient(p);
    }
    
} 

void patient::get_patient(patient *p)
{
    std::cout << "Please enter your Patient ID Number: \n";
    std::cin >> patient_id_num;
    std::cout << "Gathering patient records from the KSU_HS Patient DB...\n";

    // Create studentStaff record to be returned
    std::vector<std::string> record;

    // Create stream
    std::ifstream database;

    // Open file
    database.open("../database/patient.csv");

    bool found_record = false;

    std::string record_one;
    std::string record_two;
    std::string record_three;
    std::string record_four;
    std::string record_five;
    std::string record_six;
    std::string record_seven;
    std::string record_eight;
    std::string record_nine;
    std::string record_ten;

    while (getline(database, record_one, ',') && !found_record)
    {
        getline(database, record_two, ',');
        getline(database, record_three, ',');
        getline(database, record_four, ',');
        getline(database, record_five, ',');
        getline(database, record_six, ',');
        getline(database, record_seven, ',');
        getline(database, record_eight, ',');
        getline(database, record_nine, ',');
        getline(database, record_ten, '\n');

        if (record_nine == patient_id_num)
        {
            found_record = true;
            record.push_back(record_one);
            record.push_back(record_two);
            record.push_back(record_three);
            record.push_back(record_four);
            record.push_back(record_five);
            record.push_back(record_six);
            record.push_back(record_seven);
            record.push_back(record_eight);
            record.push_back(record_nine);
            record.push_back(record_ten);
        }
    }

    std::cout << record[0] << " " << record[1] << " " << record[2] << " " << record[3] << " " << record[4] << " " << record[5] << " " << record[6] << " " << record[7] << " " << record[8] << " " <<  record[9] << "\n";

    p->id = record[0];
    p->username = record[1];
    p->firstname = record[2];
    p->lastname = record[3];
    p->role = record[4];
    p->address = record[5];
    p->phone = record[6];
    p->age = record[7];
    p->patient_id_num = record[8];
    p->vaccine_type = record[9];

    // Close file
    database.close();

}

std::vector<std::string> patient::get_studentStaff(studentStaff *ss){
    std::vector<std::string> new_record; 
    new_record = ss->get_user_info();


    /*
    cout << "Record ID: " << new_record[0] << "\n"
         << "Record Username: " << new_record[1] << endl;
    */
    //return this->self;
    return new_record;
}


studentStaff::studentStaff(){
    //std::cout << "Creating studentStaff.\n\n";
    std::cout << "Please enter Student or Faculty ID number: " << std::endl;
    std::cin >> id_num;
}


int main()
{
    // Get an existing or create new patient driver functianlity
        // std::cout << "Are you an existing KSU-HS Patient? (yes/y/no/n): \n";
        // string response;
        // std::cin >> response;

        // patient *pt = new patient();
        // if( response == "no" || response == "n")
        // {
        //     studentStaff *ss = new studentStaff();
        //     pt->register_patient(pt, ss);
        // } 
        // else
        // {
        //     //pt->patient_id_num = response;
        //     pt->get_patient(pt);
        // }

        // std::cout << "KSU ID: " << pt->id << endl;
        // std::cout << "Username: " << pt->username << endl;
        // std::cout << "First Name: " << pt->firstname << endl;
        // std::cout << "Last Name: " << pt->lastname << endl;
        // std::cout << "Role: " << pt->role << endl;
        // std::cout << "Address: " << pt->address << endl;
        // std::cout << "Phone: " << pt->phone << endl;
        // std::cout << "Age: " << pt->age << endl;
        // std::cout << "Patient ID : " << pt->patient_id_num << endl;
        // std::cout << "Vaccine: " << pt->vaccine_type << endl;
        
        


    // General testing of studentStaff and Patient
        /*
        // Registering new patient
        studentStaff *ss = new studentStaff();
        patient *p = new patient();
        
        p->register_patient(p, ss);

        std::cout << "KSU ID: " << p->id << endl;
        std::cout << "Username: " << p->username << endl;
        std::cout << "First Name: " << p->firstname << endl;
        std::cout << "Last Name: " << p->lastname << endl;
        std::cout << "Role: " << p->role << endl;
        std::cout << "Address: " << p->address << endl;
        std::cout << "Phone: " << p->phone << endl;
        std::cout << "Age: " << p->age << endl;


        // Get a current patient
        patient *p2 = new patient();

        p2->get_patient(p2);

        std::cout << "KSU ID: " << pt->id << endl;
        std::cout << "Username: " << pt->username << endl;
        std::cout << "First Name: " << pt->firstname << endl;
        std::cout << "Last Name: " << pt->lastname << endl;
        std::cout << "Role: " << pt->role << endl;
        std::cout << "Address: " << pt->address << endl;
        std::cout << "Phone: " << pt->phone << endl;
        std::cout << "Age: " << pt->age << endl;
        std::cout << "Patient ID : " << pt->patient_id_num << endl;
        std::cout << "Vaccine: " << pt->vaccine_type << endl;
        */


    patient *pt = new patient();
    studentStaff *ss = new studentStaff();
    pt->register_patient(pt,ss);



    std::cout << "Done!\n";

    return 0;
} 