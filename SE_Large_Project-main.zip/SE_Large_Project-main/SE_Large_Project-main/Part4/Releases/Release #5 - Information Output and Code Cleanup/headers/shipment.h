//  shipment.h
//  Author: Clay Casper
//  Date: 3/24/2021

/*
    Relationships
    -------------
    Supply - Association
    Campus - Association
    Order - Association
*/

#ifndef shipment_h
#define shipment_h

#include <iostream>
#include <string>

#include "Supply.h"
#include "Database.h"

/**************************************************************************
 * Class definition : Shipment
 * @author Clay Casper
 *************************************************************************/

class Shipment
{
private:
    int id;
    int total_doses;
    std::string send_date;
    std::string estimated_arrival_date;
    bool received;
    int receiver_id;
    int order_id;

public:
    //Setters
    bool set_id(int id);
    bool set_total_doses(int total_doses);
    bool set_send_date(std::string send_date);
    bool set_estimated_arrival_date(std::string estimated_arrival_date);
    bool set_received(bool received);
    bool set_receiver_id(int receiver_id);
    bool set_order_id(int order_id);

    //Getters
    int get_id();
    int get_total_doses();
    std::string get_send_date();
    std::string get_estimated_arrival_date();
    bool get_received();
    int get_receiver_id();
    int get_order_id();

    /**
     * Based off the given supply, determines how many doses to send in the shipment.
     * 
     * @param s The supply being considered when determining how many doses to send.
     * @return The number of doses to be sent in the shipment.
     */
    int determine_doses(Supply s);

    /**
     * Divides this shipment between all the campuses. One campus may receive all, none, or a part of the shipment.
     * 
     * @return An array of the campuses and the associated number of doses to receive from this shipment.
     */
    int **split_between_campuses();

    /**
     * Sends the shipment to KSU-HS where it is then divided amongst campuses and sent to the campuses.
     */
    void send_shipment(); //maybe add validation : see payment

    /**
     * Finds an available ID for this shipment using the shipments db
     * @author Clay
     * @date 04/24/2021
     */
    int find_available_id();

    /*
    displays the shipment details based on row
    */
    void shipment_details();

    /**
     * Logs this shipment into the shipments db
     * @returns true: success | false: failed
     * @author Clay
     * @date 04/24/2021
     */
    bool log();

    /**
     * Defines this shipments member values from the orders DB using its ID. This order's ID must be set.
     * @returns true: success | false: failed
     * @author Clay
     * @date 04/28/2021
     */
    bool init_from_existing();
};

#endif
