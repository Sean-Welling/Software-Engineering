#include <iostream>

#include "../headers/Database.h"

int main(){
    Database* db = new Database();
    db->set_filename("orders.csv");
    db->init();

    db->print_database();

    db->delete_row(1);

    db->print_database();

    return 0;
}