#include "../headers/Database.h"

Database::Database(){
    this->filename = "";
    this->initialized = false;
}
Database::Database(std::string filename){
    this->filename = filename;

    //initialize database values
    this->init();
}

//Setters
bool Database::set_filename(std::string filename){
    this->filename = filename;
    if(this->filename == filename){
        //initialize
        this->init();
        return true;
    }
    else{
        return false;
    }
}
bool Database::set_num_rows(int num_rows){
    this->num_rows = num_rows;
    if(this->num_rows == num_rows){
        return true;
    }
    else{
        return false;
    }
}
bool Database::set_num_cols(int num_cols){
    this->num_cols = num_cols;
    if(this->num_cols == num_cols){
        return true;
    }
    else{
        return false;
    }
}

bool Database::set_header(std::vector<std::string> header){
    this->header = header;
    if(this->header == header){
        return true;
    }
    else{
        return false;
    }
}
bool Database::set_rows(std::vector<std::vector<std::string>> rows){
    this->rows = rows;
    if(this->rows == rows){
        return true;
    }
    else{
        return false;
    }
}

//Getters
std::string Database::get_filename(){
    return this->filename;
}
int Database::get_num_rows(){
    return this->num_rows;
}
int Database::get_num_cols(){
    return this->num_cols;
}
std::vector<std::string> Database::get_header(){
    return this->header;
}
std::vector<std::vector<std::string>> Database::get_rows(){
    return this->rows;
}

//Other
bool Database::init(){
    //check if filename is set
    if(this->filename != ""){
        std::vector<std::string> header_row = this->get_database_header();

        this->num_cols = header_row.size();
        this->header = header_row;

        //get row strings
        std::vector<std::string> lines = this->get_db_row_strings();
        std::vector<std::vector<std::string>> all_rows;

        if(!lines.empty()){
            //format each line
            for(int i = 0; i < lines.size(); i++){
                all_rows.push_back(format_row(lines.at(i)));
            }

            this->num_rows = all_rows.size();
        }
        else{
            this->num_rows = 0;
        }
        this->rows = all_rows;
        this->initialized = true;
    }
    else{
        //filename not set
        return false;
    }
    return false;
}

std::vector<std::string> Database::get_db_row_strings(){
    std::vector<std::string> lines;

    //Check if filename is set
    if(this->filename != ""){
        //create stream
        std::ifstream log;

        //open file
        log.open("database/" + this->filename);

        if(!log.is_open()){
            std::cout << "Failed to open " + this->filename << "\n";
            return lines;
        }

        int row_num = 0;
        int col_num = 0;
        std::string curr_line = "";
        char curr_char;

        while (log.get(curr_char))
        {
            if (curr_char == '\n')
            {
                if (row_num != 0)
                {
                    lines.push_back(curr_line);
                }
                curr_line = "";

                row_num++;
            }
            else
            {
                curr_line += curr_char;
            }
        }

        //close file
        log.close();
    }
    else{
        std::cout << "Filename not set\n";
        return lines;
    }

    return lines;
}

std::vector<std::string> Database::get_database_header(){
    std::vector<std::string> header;

    //Check filename is set
    if(this->filename != ""){
        //open db
        std::ifstream db;
        db.open("database/" + this->filename);
        if(!db.is_open()){
            std::cout << "Failed to open database/" << this->filename << "\n";
            return header;
        }
        else{
            std::string header_line;
            getline(db, header_line);

            header = format_row(header_line);
            return header;
        }
    }
    else{
        std::cout << "ERROR: Couldn't get database header because filename isn't set\n\n";
        return header;
    }
}

std::vector<std::string> format_row(std::string s){
    std::vector<std::string> row;

    std::string curr_word = "";

    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == ',')
        {
            //add col to row
            row.push_back(curr_word);
            //clear word
            curr_word = "";
        }
        else
        {
            curr_word += s[i];
        }
    }

    row.push_back(curr_word);

    return row;
}

void Database::print_database(){
    //reload data into obj
    this->init();

    char horizontal_divider = '=';
    int left_padding = 5;

    //check the database has been initialized
    if(this->initialized){
        //get max col widths
        std::vector<int> max_widths;
        int total_width = 0;
        for(int i = 0; i < this->num_cols; i++){
            max_widths.push_back(this->get_col_max_width(i));
            total_width += this->get_col_max_width(i);
        }
        //add dividers to total width
        total_width += (this->num_cols - 1) * 3;

        //print header

        //print padding
        for(int i = 0; i < left_padding; i++){
            std::cout << ' ';
        }
        int extra_space;
        for(int i = 0; i < this->num_cols; i++){
            //print content
            std::cout << this->header.at(i);

            //calculate extra spaces
            extra_space = max_widths.at(i) - this->header.at(i).length();

            //print extra space
            for(int j = 0; j < extra_space; j++){
                std::cout << ' ';
            }
            //print vertical divider
            if(i != num_cols-1){
                std::cout << " | ";
            }
        }
        std::cout << "\n";
        
        //print horizontal divider
        for(int i = 0; i < left_padding; i++){
            std::cout << ' ';
        }
        for(int i = 0; i < total_width; i++){
            std::cout << horizontal_divider;
        }
        std::cout << "\n";

        //print each row
        for(int i = 0; i < this->num_rows; i++){
            //print padding
            for(int i = 0; i < left_padding; i++){
                std::cout << ' ';
            }
            //loop through each col
            for(int j = 0; j < this->num_cols; j++){
                //print content
                std::cout << this->rows.at(i).at(j);

                //calculate extra spaces
                extra_space = max_widths.at(j) - this->rows.at(i).at(j).length();

                //print extra space
                for(int e = 0; e < extra_space; e++){
                    std::cout << ' ';
                }
                //print vertical divider
                if(j != num_cols-1){
                    std::cout << " | ";
                }
            }
            std::cout << "\n";
        }
    }
}

int Database::get_col_max_width(int col){
    //check if initialized
    int max = -1;
    if(this->initialized){
        //check header
        int header_col_length = this->header.at(col).length();
        if(header_col_length > max){
            max = header_col_length;
        }

        for(int i = 0; i < this->num_rows; i++){
            int curr_row_col_length = this->rows.at(i).at(col).length();
            if(curr_row_col_length > max){
                max = curr_row_col_length;
            }
        }
    }
    return max;
}

bool Database::delete_row(int row_num){
    //check if initialized
    if(this->initialized){
        //get all unformatted rows
        std::string file_string = unformat_row(this->header, ',');
        file_string += '\n';

        for(int i = 0; i < this->num_rows; i++){
            if(i != row_num){
                //unformat and add to string
                file_string += unformat_row(this->rows.at(i), ',') + '\n';
            }
        }
        
        //overwrite
        this->overwrite(file_string);
        
        //reload data into obj
        this->init();
    }
    else{
        return false;
    }
    return false;
}

std::string unformat_row(std::vector<std::string> record, char delim){
    std::string unformatted = "";

    for(int i = 0; i < record.size(); i++){
        //add word to line
        unformatted += record.at(i);
        if(i != record.size()-1){
            unformatted += delim;
        }
    }

    return unformatted;
}

bool Database::overwrite(std::string content){
    std::ofstream file;
    file.open("database/" + this->filename);

    if(file.is_open()){
        file << content;
    }
    else{
        return false;
    }

    return true;
}

int Database::find_available_id(std::string column_name){
    //find column index
    int column_index = -1;
    for(int i = 0; i < this->num_cols; i++){
        if(this->header.at(i) == column_name){
            column_index = i;
            break;
        }
    }

    if(column_index == -1){
        //couldn't find the column specified
        return -1;
    }
    else{
        //check if there are rows in this database
        if(this->num_rows == 0){
            return 0;
        }
        int available_id = 0;
        bool available;
        //found the column specified
        do{
            available = true;
            //go through each row and check ID
            for(std::vector<std::string> row : this->rows){
                if(stoi(row.at(column_index)) == available_id){
                    available = false;
                    available_id++;
                    break;
                }
            }
        }while(available != true);

        return available_id;
    }
}

bool Database::add_row(std::vector<std::string> row_content){
    //attempt to open log
    std::ofstream log;
    log.open("database/" + this->filename, std::ios::app);

    if(log.is_open()){
        for(int i = 0; i < row_content.size(); i++){
            log << row_content.at(i);
            if(i != row_content.size()-1){
                log << ',';
            }
        }
        log << "\n";
        log.close();

        //add to this obj
        this->rows.push_back(row_content);
        
        return true;
    }
    else{
        std::cerr << "Couldn't open database/" + this->filename << "\n";
        log.close();
        return false;
    }
}