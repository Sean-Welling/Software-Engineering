/*
    Implementation file for custom Date class

    Date Created: 04/22/2021

    Author: Clay
*/

#include "../headers/Date.h"

//constant data related to dates and time
const std::string month_names[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

const int month_days_non_leap[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

const int month_days_leap[12] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

//Constructors
Date::Date(){

}
Date::Date(int month, int day, int year){
    if(this->set_month(month)){
        if(this->set_day(day)){
            if(!this->set_year(year)){
                std::cout << "Couldn't set this date's year\n";
            }
        }
        else{
            std::cout << "Couldn't set this date's day\n";
        }
    }
    else{
        std::cout << "Couldn't set this date's month\n";
    }
}
Date::Date(std::string month, std::string day, std::string year){
    if(this->set_month(stoi(month))){
        if(this->set_day(stoi(day))){
            if(!this->set_year(stoi(year))){
                std::cout << "Couldn't set this date's year\n";
            }
        }
        else{
            std::cout << "Couldn't set this date's day\n";
        }
    }
    else{
        std::cout << "Couldn't set this date's month\n";
    }
}
Date::Date(std::string full_date){
    this->init_from_date_string(full_date);
}

//Setters
bool Date::set_month(int month){
    this->month = month;
    if(this->month == month){
        return true;
    }
    else{
        return false;
    }
}
bool Date::set_day(int day){
    this->day = day;
    if(this->day == day){
        return true;
    }
    else{
        return false;
    }
}
bool Date::set_year(int year){
    this->year = year;
    if(this->year == year){
        return true;
    }
    else{
        return false;
    }
}

//Getters
int Date::get_month(){
    return this->month;
}
int Date::get_day(){
    return this->day;
}
int Date::get_year(){
    return this->year;
}

//Other

std::string* Date::parse_date_string(std::string date, std::string format){
    if(format != "mm/dd/yyyy" && format != "mm-dd-yyyy"){
        return NULL;
    }
    else{
        //https://stackoverflow.com/questions/7527356/return-string-array-in-c-function
        std::string* parsed_date = new std::string[3];

        if(format == "mm/dd/yyyy"){
            std::vector<std::string> parsed = this->split_string(date, '/');

            parsed_date[0] = parsed.at(0);
            parsed_date[1] = parsed.at(1);
            parsed_date[2] = parsed.at(2);
        }
        else if(format == "mm-dd-yyyy"){
            std::vector<std::string> parsed = this->split_string(date, '-');

            parsed_date[0] = parsed.at(0);
            parsed_date[1] = parsed.at(1);
            parsed_date[2] = parsed.at(2);
        }
        return parsed_date;
    }
}

std::vector<std::string> Date::split_string(std::string base, char delim){
    std::vector<std::string> split_strings;

    //go through each character and check for the delim
    std::string current_word = "";
    for(int i = 0; i < base.length(); i++){
        //check for delim
        if(base[i] == delim){
            //add current_string to array
            split_strings.push_back(current_word);

            //reset the current string
            current_word = "";
        }
        else{
            //add current char to current string
            current_word += base[i];
        }
    }

    //add last word
    split_strings.push_back(current_word);

    return split_strings;
}

void Date::print_date(std::string format){
    std::string acceptable_formats[] = {"mm/dd/yyyy", "mm/dd/yy", "mm-dd-yyyy", "mm-dd-yy"};
    //check format
    bool good_format = false;
    for(int i = 0; i < sizeof(acceptable_formats)/sizeof(acceptable_formats[0]); i++){
        if(format == acceptable_formats[i]){
            good_format = true;
        }
    }

    if(good_format){
        //get delimeter
        char delim = this->get_delim(format);
        
        std::vector<std::string> split_format = this->split_string(format, delim);

        //print
        int month_iteration = 0;
        int day_iteration = 0;
        int year_iteration = 0;
        if(split_format.at(2) == "yy"){
            year_iteration = 2;
        }

        std::string month_string = this->format_element_string(this->month);
        std::string day_string = this->format_element_string(this->day);
        std::string year_string = std::to_string(this->year);

        for(int i = 0; i < format.length(); i++){
            switch(format[i]){
                case 'm':{
                    std::cout << month_string[month_iteration];
                    month_iteration++;
                    break;
                }
                case 'd':{
                    std::cout << day_string[day_iteration];
                    day_iteration++;
                    break;
                }
                case 'y':{
                    std::cout << year_string[year_iteration];
                    year_iteration++;
                    break;
                }
                default:{
                    std::cout << format[i];
                    break;
                }
            }
        }
    }
    else{
        std::cout << "Can't print date: Incorrect format\n";
    }
}

std::string Date::get_formatted(std::string format){
    std::string final_string = "";

    std::string acceptable_formats[] = {"mm/dd/yyyy", "mm/dd/yy", "mm-dd-yyyy", "mm-dd-yy"};
    //check format
    bool good_format = false;
    for(int i = 0; i < sizeof(acceptable_formats)/sizeof(acceptable_formats[0]); i++){
        if(format == acceptable_formats[i]){
            good_format = true;
        }
    }

    if(good_format){
        //get delimeter
        char delim = this->get_delim(format);
        
        std::vector<std::string> split_format = this->split_string(format, delim);

        //print
        int month_iteration = 0;
        int day_iteration = 0;
        int year_iteration = 0;
        if(split_format.at(2) == "yy"){
            year_iteration = 2;
        }

        std::string month_string = this->format_element_string(this->month);
        std::string day_string = this->format_element_string(this->day);
        std::string year_string = std::to_string(this->year);

        for(int i = 0; i < format.length(); i++){
            switch(format[i]){
                case 'm':{
                    final_string += month_string[month_iteration];
                    month_iteration++;
                    break;
                }
                case 'd':{
                    final_string += day_string[day_iteration];
                    day_iteration++;
                    break;
                }
                case 'y':{
                    final_string += year_string[year_iteration];
                    year_iteration++;
                    break;
                }
                default:{
                    final_string += format[i];
                    break;
                }
            }
        }
    }
    else{
        std::cout << "Can't print date: Incorrect format\n";
    }

    return final_string;
}

char Date::get_delim(std::string date){
    for(int i = 0; i < date.length(); i++){
        if(date[i] != 'm' && date[i] != 'd' && date[i] != 'y'){
            return date[i];
        }
    }
    return 'm';
}

std::string Date::format_element_string(int element){
    std::string formatted = "";

    if(element < 10){
        formatted += '0';
        formatted += std::to_string(element);
    }
    else{
        formatted = std::to_string(element);
    }

    return formatted;
}

int compare_dates(Date* date1, Date* date2){
    //check year
    if(date1->get_year() < date2->get_year()){
        return -1;
    }
    else if(date1->get_year() > date2->get_year()){
        return 1;
    }
    else{
        //check month
        if(date1->get_month() < date2->get_month()){
            return -1;
        }
        else if(date1->get_month() > date2->get_month()){
            return 1;
        }
        else{
            //check day
            if(date1->get_day() < date2->get_day()){
                return -1;
            }
            else if(date1->get_day() > date2->get_day()){
                return 1;
            }
            else{
                return 0;
            }
        }
    }
}

Date operator -(Date d1, Date d2){
    Date difference = Date();

    //get the later date
    Date later_date;
    Date earlier_date;
    if(compare_dates(&d1, &d2) == -1){
        //d1 is earlier than d2
        later_date = d2;
        earlier_date = d1;
    }
    else{
        later_date = d1;
        earlier_date = d2;
    }

    //subtract
    int year_diff = later_date.get_year() - earlier_date.get_year();
    int month_diff = later_date.get_month() - earlier_date.get_month();
    int day_diff = later_date.get_day() - earlier_date.get_day();

    //set members
    difference.set_month(month_diff);
    difference.set_day(day_diff);
    difference.set_year(year_diff);

    return difference;
}

int Date::is_leap_year(){
    //check if year is set
    if(this->year != 0){
        if(this->year % 4 == 0){
            if(this->year % 100 == 0){
                if(this->year % 400 == 0){
                    return 1;
                }
                else{
                    return 0;
                }
            }
            else{
                return 1;
            }
        }
        else{
            return 0;
        }
    }
    else{
        return -1;
    }
}

const std::string get_curr_date() {
    time_t     now = time(0);
    struct tm  tstruct;
    char       curr_date[80];
    tstruct = *localtime(&now);
    strftime(curr_date, sizeof(curr_date), "%m/%d/%Y", &tstruct);

    return curr_date;
}

bool Date::init_from_date_string(std::string date_string){
    //check format
    if(date_string[2] == '/' && date_string[5] == '/'){
        //Parse string for month, day, and year
        std::string* members = this->parse_date_string(date_string, "mm/dd/yyyy");

        //initialize members
        if(this->set_month(stoi(*members))){
            if(this->set_day(stoi(*(members+1)))){
                if(this->set_year(stoi(*(members+2)))){
                    return true;
                }
                else{
                    std::cerr << "Couldn't set this date's year\n";
                    return false;
                }
            }
            else{
                std::cerr << "Couldn't set this date's day\n";
                return false;
            }
        }
        else{
            std::cerr << "Couldn't set this date's month\n";
            return false;
        }
    }
    else{
        std::cerr << "Couldn't initialize the new date's members because the input string had an incorrect format.\n";
        return false;
    }
}

Date operator +(Date &d1, int change){
    Date final_date = d1;
    /*
        Algorithm

        1. while the total days to add is greater than the days left in current month -> increment month and set days to 0
        2. set days as what's left in total days to add
    */
    int total_days_to_add = change;
    bool go_again;

    do{

        go_again = false;
        //calculate days left in curr_month
        int days_left_in_month;
        if(final_date.is_leap_year()){
            days_left_in_month = month_days_leap[final_date.get_month() - 1] - final_date.get_day();
        }
        else{
            days_left_in_month = month_days_non_leap[final_date.get_month() - 1] - final_date.get_day();
        }

        if(total_days_to_add - days_left_in_month > 0){
            //indicate loop
            go_again = true;

            //increment month -> check if need to increment year
            if(final_date.get_month() == 12){
                final_date.set_month(1);
                //increment year
                final_date.set_year(final_date.get_year() + 1);
            }
            else{
                final_date.set_month(final_date.get_month() + 1);
            }

            //set days to 1
            final_date.set_day(1);

            //remove days left in curr month from total days to remove -> need to account for extra day when incrementing month
            total_days_to_add -= (days_left_in_month + 1);
        }
        else{
            //add the days to curr day value
            final_date.set_day(final_date.get_day() + total_days_to_add);
        }

    }while(go_again);

    return final_date;
}

Date operator -(Date &d1, int change){
    Date final_date = d1;
    /*
        Algorithm

        1. subtract the change from the current day ->
            if(-) : decrement month / decrease change / set days to previous month's total days
            else : set days to curr day - change
    */
    int total_days_to_subtract = change;
    bool go_again;

    do{
        go_again = true;

        //check if change overflows month days
        int overflow;
        overflow = final_date.get_day() - change;

        if(overflow < 1){
            //change month
            if(final_date.get_month() == 1){
                final_date.set_month(12);
                //change year
                final_date.set_year(final_date.get_year()-1);
            }
            else{
                final_date.set_month(final_date.get_month()-1);
            }

            //decrease change
            change -= final_date.get_day();

            //set the new day value
            if(final_date.is_leap_year()){
                final_date.set_day(month_days_leap[final_date.get_month()-1]);
            }
            else{
                final_date.set_day(month_days_non_leap[final_date.get_month()-1]);
            }
        }
        else{
            //change the day value
            final_date.set_day(overflow);

            //set flag
            go_again = false;
        }
        
    }while(go_again);

    return final_date;
}

int get_month_days(int month_num, bool leap_year){
    if(leap_year){
        return month_days_leap[month_num - 1];
    }
    else{
        return month_days_non_leap[month_num - 1];
    }
}