//
//  supply.cpp
//
//
//  Created by Arthur Wolff on 3/22/21.
//  Expanded by Daniel Earley on 2021-04-10
// 
//

#include "../headers/Supply.h"
#include <iostream>

void update_supply(int change){
    
    int stark_count = 1 ,tusk_count = 1, main_count = 1, eliver_count = 1 ,geauga_count = 1, salem_count = 1, trum_count = 1, ash_count = 1;
    int university_count = stark_count+tusk_count+main_count;
    char vac_pick;
    int yn, repeat_yn;;

// shows supply levels
    std::cout << " Kent Main: " << main_count << std::endl;
    std::cout << " Stark: " << stark_count << std::endl;
    std::cout << " Tuscarawas: " << tusk_count << std::endl;
    std::cout << " East Liverpool: " << eliver_count << std::endl;
    std::cout << " Geauga: " << geauga_count << std::endl;
    std::cout << " Salem: " << salem_count << std::endl;
    std::cout << " Trumbull: " << trum_count << std::endl;
    std::cout << " Ashtabula: " << ash_count << std::endl;
    std::cout << " Total university supply: " << university_count << std::endl;
    std::cout << " does this supply count look correct?" << std::endl;
    std::cout << " if not press 0" << std::endl;
    cin >> yn;
    
// choose what suppy to edit
    if (yn == 0){
        std::cout << " which vaccice supply is incorrect?" << std::endl;
        std::cout << " press k for Stark" << std::endl;
        std::cout << " press t for Tuscarawas" << std::endl;
        std::cout << " press e for East Liverpool" << std::endl;
        std::cout << " press g for Geauga" << std::endl;
        std::cout << " press b for Trumbull" << std::endl;
        std::cout << " press s for Salem" << std::endl;
        std::cout << " press a for Ashtabula" << std::endl;
        std::cout << " press m for kent main" << std::endl;
        cin >> vac_pick;
   
// changes supply levels based on entry
        if (vac_pick == 'k'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> stark_count;
        }
        if (vac_pick == 't'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> tusk_count;
        }
        if (vac_pick == 'm'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> main_count;
        }
        if (vac_pick == 'e'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> eliver_count;
        }
        if (vac_pick == 'a'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> ash_count;
        }
        if (vac_pick == 'b'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> trum_count;
        }
        if (vac_pick == 's'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> salem_count;
        }
        if (vac_pick == 'g'){
            std::cout << "what is the corret count?" << std::endl;
            cin >> geauga_count;
        }
        
        std::cout << " would you like to see the supply again? 1 for yes 0 for no" << std::endl;
        cin >> repeat_yn;
        
        if (repeat_yn == 1){
            std::cout << " Kent Main: " << main_count << std::endl;
            std::cout << " Stark: " << stark_count << std::endl;
            std::cout << " Tuscarawas: " << tusk_count << std::endl;
            std::cout << " East Liverpool: " << eliver_count << std::endl;
            std::cout << " Geauga: " << geauga_count << std::endl;
            std::cout << " Salem: " << salem_count << std::endl;
            std::cout << " Trumbull: " << trum_count << std::endl;
            std::cout << " Ashtabula: " << ash_count << std::endl;
            std::cout << " Total university supply: " << university_count << std::endl;
        }
    };
}

int Supply::get_vaccine_count()
{
	return count;
}
