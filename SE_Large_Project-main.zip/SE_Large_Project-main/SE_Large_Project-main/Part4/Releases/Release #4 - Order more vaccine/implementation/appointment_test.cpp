#include "../headers/Appointment.h"

int main()
{
    // campus* c = new campus();
    // c->set_location(0);

    // std::cout << "campus id : " << c->get_location_id() << "\n";

    // std::vector<Appointment*> appointments = find_appointments_by_campus(c);

    campus* c = new campus();
    c->set_location(0);

    find_appointments_by_campus(c);


    std::cout << "Done!\n";

    return 0;
}