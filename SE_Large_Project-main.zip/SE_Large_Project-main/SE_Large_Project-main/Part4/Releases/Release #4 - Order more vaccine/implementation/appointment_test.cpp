#include "../headers/Appointment.h"

int main()
{
    // campus* c = new campus();
    // c->set_location(0);

    // std::cout << "campus id : " << c->get_location_id() << "\n";

    // std::vector<Appointment*> appointments = find_appointments_by_campus(c);

    // campus* c = new campus();
    // c->set_location(0);

    // Appointment ap = Appointment();
    // std::cout << get_curr_date() << "\n";
    // //ap.get_past_apmts();

    //Test find_appointment_by_id
    // std::cout << "Appointment ID : ";
    // int id;
    // std::cin >> id;

    // Appointment apmt = *find_appointment_by_id(id);
    
    // if(apmt.get_id() != -1){
    //     std::cout << "Appointment Id : " << apmt.get_id() << "\n";
    //     std::cout << apmt.get_patient()->firstname << " " << apmt.get_patient()->lastname << ", your appointment is on " << apmt.get_date() << " at " << apmt.get_time() << " at the " << apmt.get_campus()->get_location() << " campus.\n\n";
    // }
    // else{
    //     std::cout << "Couldn't find your appointment...\n";
    // }


    std::cout << "Done!\n";

    return 0;
}