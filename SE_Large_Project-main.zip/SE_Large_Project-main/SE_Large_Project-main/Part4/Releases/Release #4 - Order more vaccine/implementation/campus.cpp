#include "../headers/campus.h"

/**************************************************************************
 * Implementation of campus.h
 *************************************************************************/


//Array of campus names (alphabetical)
std::string campus_names[] = { "Ashtabula", "East Liverpool", "Geauga", "Kent", "Salem", "Stark", "Trumbull", "Tuscarawas"};


void campus::set_location(int campus_index)
{
	location = campus_names[campus_index];
}

string campus::get_location()
{
	return location;
}


int campus::get_supply_count()
{
	return campus_supply.get_vaccine_count();
}

int campus::get_location_id(){
	for(int i = 0; i < sizeof(campus_names)/sizeof(campus_names[0]); i++){
		if(campus_names[i] == this->location){
			return i;
		}
	}
	return -1;
}

std::vector<Order*> campus::get_past_orders(std::string start_date, std::string end_date, bool all){
	std::vector<Order*> past_orders;

	//Open orders database
	Database order_db = Database("orders.csv");

	if(all){
		//get all orders for this campus
		for(int i = 0; i < order_db.get_num_rows(); i++){
			std::vector<std::string> curr_row = order_db.get_rows().at(i);
			//create order object
			Order* temp_order = new Order();
			//set order members
			temp_order->set_id(stoi(curr_row.at(0)));
			temp_order->set_requester_id(stoi(curr_row.at(1)));
			temp_order->set_doses_needed(stoi(curr_row.at(2)));
			temp_order->set_date_requested(curr_row.at(3));
			temp_order->set_fulfilled(stoi(curr_row.at(4)));

			//add order to list
			past_orders.push_back(temp_order);
		}
	}
	else{
		Date* start_date_obj = new Date(start_date);
		Date* end_date_obj = new Date(end_date);

		//find orders between the given dates
		for(int i = 0; i < order_db.get_num_rows(); i++){
			std::vector<std::string> curr_row = order_db.get_rows().at(i);
			//create order object
			Order* temp_order = new Order();
			//set order members
			temp_order->set_id(stoi(curr_row.at(0)));
			temp_order->set_requester_id(stoi(curr_row.at(1)));
			temp_order->set_doses_needed(stoi(curr_row.at(2)));
			temp_order->set_date_requested(curr_row.at(3));
			temp_order->set_fulfilled(stoi(curr_row.at(4)));

			//check if in between the dates
			Date* order_date = new Date(curr_row.at(3));

			int start_date_cmp = compare_dates(order_date, start_date_obj);
			int end_date_cmp = compare_dates(order_date, end_date_obj);
			if((start_date_cmp == 0 || start_date_cmp == 1) && (end_date_cmp == 0 || end_date_cmp == -1)){
				//add order to list
				past_orders.push_back(temp_order);
			}
		}
	}
	return past_orders;
}