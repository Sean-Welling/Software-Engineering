//  order.h
//  Author: Clay Casper
//  Date: 3/24/2021

/*
    Relationships
    -------------
    Shipment - Association
    Campus - Association
*/

#ifndef order_h
#define order_h

#include <iostream>
#include <string>

#include "./Supply.h"

/**************************************************************************
 * Class definition : Order
 * @author Clay Casper
 *************************************************************************/

class Order
{

private:
    int id;
    int doses_needed;
    int requester_id;
    std::string date_requested;
    bool fulfilled;

public:
    //Setters
    bool set_id(int id);
    bool set_doses_needed(int doses_needed);
    bool set_requester_id(int requester_id);
    bool set_date_requested(std::string date_requested);
    bool set_fulfilled(int fulfilled);

    //Getters
    int get_id();
    int get_doses_needed();
    int get_requester_id();
    std::string get_date_requested();
    int get_fulfilled();

    //Getters
    /**
     * Based off the given supply, determines how many doses to request in the order.
     * 
     * @param s The supply being considered when determining how many doses to request.
     * @return The number of doses to be requested in the order.
     */
    int determine_doses_needed(Supply s);
    /**
     * Sends the order to the KSU-HS where it is routed to a pharmaceutical company
     */
    void send_order(); //Might want to validate the receiver received the payment
    
    //  TO FIX : Arthur
    //bool populate_order(int num_doses, campus* sender); 
};

#endif
