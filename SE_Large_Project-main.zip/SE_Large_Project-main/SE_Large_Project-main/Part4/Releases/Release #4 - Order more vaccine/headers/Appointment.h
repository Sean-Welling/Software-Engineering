//
//  Appointment.h
//
//
//  Created by Arthur Wolff on 3/18/21.
//
//  Edited by Clay Casper on 4/6/2021

#ifndef Appointment_h
#define Appointment_h

//includes
#include "patient.h"
#include "campus.h"
#include "Display.h"
#include "Date.h"

// ------ Relationships ------
// Low Demand: Association
// Payment: Association
// Campus: Association
// Patient: Association
// Schedule: Aggregation

#include <list>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <math.h>
#include <time.h>

using namespace std;

class Appointment
{
public:
    // bool lowDemand(int item) const;
    // bool payment(int item) const;
    // bool campus(int item) const;
    // //bool patient(int item) const;
    // bool schedule(int item) const;

    Appointment();

    Appointment(patient *p, std::string date, std::string time);

    //setters

    /**
     * Sets the reference to the appointment's patient
     * @param p The appointment's patient
     * @return Whether or not the patient was set successfully
     */
    bool set_patient(patient *p);

    /**
     * Sets the date of the appointment
     * @param date Appointment's date
     * @return Whether the appointment's date was set successfully or not
     */
    bool set_date(string date);

    /**
     * Sets the time of the appointment
     * @param time Appointment's time
     * @return Whether the appointment's time was set successfully or not
     */
    bool set_time(string time);

    bool set_id(int id);

    /**
     * Sets the reference to this appointment's campus
     * @param c Pointer to the campus object where this appointment takes place
     * @return Whether the appointment's campus was set properly or not
     */
    bool set_campus(campus *c);

    /**
     * Sets this appointment's iteration number
     * ie. first appointment / second appointment
     */
    bool set_iteration(int i);

    //getters

    /**
     * Returns this appointment's patient reference
     * @return The reference to this appointment's patient
     */
    patient *get_patient();

    /**
     * Returns this appointment's date
     * @return The date of this appointment
     */
    string get_date();

    /**
     * Returns this appointment's time
     * @return The time of this appointment
     */
    string get_time();

    /**
     * Returns a reference to this appointment's campus
     * @return Reference to this appointment's campus
     */
    campus *get_campus();

    /**
     * Returns this appointment's ID
     * @return This apointment's ID
     */
    int get_id();

    /**
     * Returns which appointment iteration this appointment is
     * ie. 1st appointment / 2nd appointment
     * @return This apointment's iteration number
     */
    int get_iteration();

    //other

    /**
     * Records this appointment's information to the database
     * @return Error code. 0 == No Error, 1 == Couldn't open log
     */
    int log_appointment(std::string database_filename);

    /**
     * Finds the first available appointment ID
     * @return The first available ID
     */
    int find_available_id();//MIGRATE --> DATABASE

    /**
     * Gets all records from the appointments log
     * @return List of rows from the log :: Row = [id, patient id, date, time, campus id]
     */
    std::vector<std::vector<std::string>> get_appointment_rows();//MIGRATE --> DATABASE

    /**
     * Creates a vector from a string representing one row in a csv database
     * @param s The string the makes up the row
     * @return Vector that indicates the columns in the row through its indeces
     */
    std::vector<std::string> get_row_vector(std::string s);//MIGRATE --> DATABASE

    /**
     * Computes the date that is x days after this appointment's date
     * @param days_between The days between the first appointment and the second appointment
     * @return The date (m/d/yyyy) as a string
     */
    std::string get_second_date(int days_between);

    /**
     * Changes this appointments date
     * @param new_date The new date the replace the old date
     * @return true: successfully changed the date | false: failed to change the date
     */
    bool change_date(std::string new_date);



    /**
     * Changes this appointment's time
     * @param new_date The new time that replaces the old time
     * @return true: successfully changed the time | false: failed to change the time
     * @author Daniel
     */
    bool change_time(std::string new_time);

    /**
     * Finds an appointment's record in the DB by its ID
     * @param id The appointment's ID
     * @return A vector representing that appointment's DB record
     */
    std::vector<std::string> find_record_by_id(int id);//Remove and replace calls with find_record --> SEE NOTES

    /**
     * Finds the record number given the appointment's ID
     * @param id The appointment's ID
     * @return The record number (0 based) of the appointment
     */
    int get_record_number(int id);//CHANGE --> SEE NOTES

    /**
     * Set this appointment's attributes using its ID and existing information
     * @return true: success | false: failed
     * @author Clay
     */
    bool init_from_existing();

    /**
     * Finds this appointment's record in either complete appointments DB or upcoming appointments DB using its ID
     * @return Vector representing this appointments data from DB | fail : empty vector
     * @author Clay
     */
    std::vector<std::string> find_record();//CHANGE to use Database functionality

    /**
     * Prints this appointment's details to standard out
     * @author Clay
     */
    void display_details();

    /**
     * Used to modify this appointment
     * @return true: success | false: failed
     */
    bool modify();

    /**
     * Completes the appointment
     * Removes record from log
     * Updates campus supply if dose was administered
     * @param good Indicates whether the dose was administered or not
     * @return true: successful completion | false: error
     */
    bool complete(bool good, int num_apmts_last_week, int num_apmts_next_week, int avg_apmts_per_day);

    /**
     * Asks the user which appointment this is for them
     * @example First appointment, second appointment, etc
     * @return true: successful | false: failed
     * @author Clay
     */
    bool ask_appointment_iteration();

    /**
     * Deletes this appointments record from the appointment database
     * @author Clay
     */
    bool delete_record();

private:
    //list<int> items;
    int id = -1;
    patient *p;
    campus *c;
    /* Format : m/dd/yyyy */
    string date;
    string ap_time;
    int iteration;
};

/**
 * Finds all of this campus' orders
 * @return vector with all appointment objects
 * @param completed Whether to find completed or upcoming appointments
 * @author Clay
 */
std::vector<Appointment*> find_appointments_by_campus(campus* c, bool completed);

/**
 * Finds an appointment by the given ID
 * @param id The appointment's ID
 * @returns An appointment obj for this appointment
 * @author Clay
 * @date 04/27/2021
 */
Appointment* find_appointment_by_id(int id);

#endif /* Appointment_h */
