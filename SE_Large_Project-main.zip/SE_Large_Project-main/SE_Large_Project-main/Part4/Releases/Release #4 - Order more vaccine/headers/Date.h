/*
    Header file for custom Date class

    Date Created: 04/22/2021

    Author: Clay
*/

#ifndef date_h
#define date_h

#include <string>
#include <iostream>
#include <vector>

class Date{
    private:
        int month;
        int day;
        int year;

    public:
        //Constructors
        Date();
        Date(int month, int day, int year);
        Date(std::string month, std::string day, std::string year);
        /**
         * Constructs a new date object given the date as one string in the format : mm/dd/yyyy
         * @author Clay
         */
        Date(std::string full_date);

        //Setters
        bool set_month(int month);
        bool set_day(int day);
        bool set_year(int year);

        //Getters
        int get_month();
        int get_day();
        int get_year();

        //Other

        /**
         * Returns an array pointer to 3 strings in the format : [month, day, year]
         * Acceptable string formats - 
         * mm/dd/yy
         * mm-dd-yy
         * @author Clay
         */
        std::string* parse_date_string(std::string date, std::string format);

        /**
         * Splits a string into substrings given a delimeter
         * @return Vector of strings
         * @author Clay
         */
        std::vector<std::string> split_string(std::string base, char delim);

        /**
         * Prints this date's members given the format
         * Acceptable formats - 
         * mm/dd/yyyy
         * mm/dd/yy
         * mm-dd-yyyy
         * mm-dd-yy
         * @author Clay
         */
        void print_date(std::string format);

        /**
         * Finds the delimeter in the given date string
         * @return success: delim | failed to find delim: m
         * Constraints: The delimeter cannot be m, d, or y
         * @author Clay
         */
        char get_delim(std::string date);

        /**
         * Formats the element that only has 1 character as an int but requires 2 characters in string format
         * @param element The element that needs formatted
         * @example format_element_string(5) -> "05"
         * @author Clay
         */
        std::string format_element_string(int element);
};

/**
 * Checks if the first date is earlier, the same, or later than the second date
 * @param date1 Date obj pointer
 * @param date2 Date obj pointer
 * @return -1: date1 is earlier than date2 | 1: date1 is later than date2 | 0: dates are the same
 */
int compare_dates(Date* date1, Date* date2);

#endif