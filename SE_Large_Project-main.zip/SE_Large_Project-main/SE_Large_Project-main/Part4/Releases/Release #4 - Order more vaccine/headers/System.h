#include <iostream>

#include "../headers/Appointment.h"
#include "../headers/campus.h"
#include "../headers/LowDemand.h"
#include "../headers/order.h"
#include "../headers/patient.h"
#include "../headers/payment.h"
#include "../headers/schedule.h"
#include "../headers/shipment.h"
#include "../headers/studentStaff.h"
#include "../headers/Supply.h"
#include "../headers/vaccine.h"

//system specific functionality
bool register_patient();

bool modify_appointment();

/**
 * Checks for past appointments
 * Removes them from the log
 * Updates campus supplies
 */
bool system_init();