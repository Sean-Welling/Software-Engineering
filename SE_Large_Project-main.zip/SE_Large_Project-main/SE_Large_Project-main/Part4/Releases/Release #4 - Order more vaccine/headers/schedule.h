#ifndef schedule_h
#define schedule_h

#include "Appointment.h"
#include <ctime>
#include <vector>

/**************************************************************************
 * Class definition : schedule
 * @author Sean Welling
 *************************************************************************/

class schedule 
{
    private:
        std::vector<Appointment*> appointments;
        
public:
    //Setters
    bool set_appointments(std::vector<Appointment*> appointments);

    //Getters
    std::vector<Appointment*> get_appointments();



    /**
     * Returns the year, month, day or full date as requested
     * @return true: successful | false: failed
     * @author Daniel
     */
    int current_year();
    int current_month();
    int current_day();
    char* get_current_date();

    /**
     * Deletes an appointment's record from DB using its id
     * @param id The appointment's ID
     * @return true: successful | false: failed
     * @author Clay
     */
    bool delete_appointment(int id);

    /**
     * Gets all the rows in a DB in string format
     * @param db_file The filename of the DB
     * @returns Vector containing vectors of strings
     * @author Clay
     */
    std::vector<std::vector<std::string>> get_db_rows(std::string db_file);

    /**
     * Changes a string into a vector representing a row and its columns from a database
     * @param s The string to format
     * @return Vector holding all the row's column values
     * @author Clay
     */
    std::vector<std::string> format_row(std::string s);

    /**
     * Finds the record number given which column and the column int value to find
     * @param id_column the Column index to search by
     * @param id The value to search by
     * @param db_filename The filename of the database
     * @return The row number of the record *Doesn't include file header row
     * @author Clay
     */
    int get_record_number(int id_column, int id, std::string db_filename);

    /**
     * Gets a copy of the line in the specifed DB at the specified line
     * @param db_filename The filename of the database
     * @param line_num The number of the line to copy
     * @return String representing the line in the DB *0 based
     * @author Clay
     */
    std::string copy_db_line(std::string db_filename, int line_num);

    /**
     * Deletes a single line from a database
     * @param db_filename The filename of the database
     * @param line_num The number of the line to copy
     * @return true: success | false: failed
     * @author Clay
     */
    bool delete_line(std::string db_filename, int line_num);

    /**
     * Change a vector of columns into one string
     * @param record The vector of columns
     * @param delim The delimeter to divide the columns in the string
     * @return The string containing all values from the vector separated by the delimeter
     * @author Clay
     */
    std::string unformat_row(std::vector<std::string> record, char delim);

    /**
     * Writes a string to a database
     * @param db_filename The filename of the datatbase to write to
     * @param content_to_write The string to write to the database
     * @return true: success | false: failed
     */
    bool write_to_database(std::string db_filename, std::string content_to_write);

    /**
     * Gets the header from a database file
     * @param The filepath of the database
     * @return The formatted header
     * @author Clay
     */
    std::vector<std::string> get_database_header(std::string db_filename);

    /**
     * Finds the appointment record in the database
     */
    std::vector<std::string> find_appointment(int id);

    int find_avg_appointments_completed_per_day(std::string start, std::string end, bool all);
};

#endif /* schedule_h */