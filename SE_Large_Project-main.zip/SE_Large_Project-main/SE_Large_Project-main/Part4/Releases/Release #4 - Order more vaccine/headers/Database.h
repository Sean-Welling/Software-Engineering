/*
    Header file for Database class and related functionality

    Date Created: 04/22/2021

    Author: Clay
*/

#ifndef database_h
#define database_h

#include <iostream>
#include <string>
#include <vector>
#include <fstream>

class Database{
    private:
        std::string filename;
        int num_rows;
        int num_cols;
        std::vector<std::string> header;
        std::vector<std::vector<std::string>> rows;
        bool initialized;

        /**
         * Gets the max width in characters for a given col
         * @param col The col to look in
         * @author Clay
         */
        int get_col_max_width(int col);

    public:
        Database();
        Database(std::string filename);

        //Setters
        bool set_filename(std::string filename);
        bool set_num_rows(int num_rows);
        bool set_num_cols(int num_cols);
        bool set_header(std::vector<std::string> header);
        bool set_rows(std::vector<std::vector<std::string>> rows);

        //Getters
        std::string get_filename();
        int get_num_rows();
        int get_num_cols();
        std::vector<std::string> get_header();
        std::vector<std::vector<std::string>> get_rows();

        //Other
        bool init();

        /**
        * Gets the header from a database file
        * @param The filepath of the database
        * @return The formatted header
        * @author Clay
        */
        std::vector<std::string> get_database_header();

        /**
        * Gets all the rows in a DB in string format
        * @param db_file The filename of the DB
        * @returns Vector containing vectors of strings
        * @author Clay
        */
        std::vector<std::string> get_db_row_strings();

        /**
         * Prints the database header and all rows to the standard out
         * @author Clay
         */
        void print_database();

        /**
         * Deletes a single line from a database
         * @param db_filename The filename of the database
         * @param line_num The number of the line to copy (0 based)
         * @return true: success | false: failed
         * @author Clay
         */
        bool delete_row(int row_num);

        /**
         * Overwrites this db file with the given content
         * @returns true: success | false: failed
         * @author Clay
         */
        bool overwrite(std::string content);

        /**
         * Finds the first available ID in this database
         * @return The first available ID
         */
        int find_available_id(std::string column_name);

        /**
         * Adds a row to this db and this obj
         * @author Clay
         * @date 04/24/2021
         */
        bool add_row(std::vector<std::string> row_content);
    
};

/**
* Changes a string into a vector representing a row and its columns from a database
* @param s The string to format
* @return Vector holding all the row's column values
* @author Clay
*/
std::vector<std::string> format_row(std::string s);

/**
 * Change a vector of columns into one string
 * @param row_num The row to unformat
 * @param delim The delimeter to divide the columns in the string
 * @return The string containing all values from the vector separated by the delimeter
 * @author Clay
 */
std::string unformat_row(std::vector<std::string> record, char delim);

#endif