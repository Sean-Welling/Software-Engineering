/*
   campus.h

   Declaration file for the campus class.
   
*/

#ifndef campus_h
#define campus_h

#include <string>
#include <vector>

#include "Supply.h"
#include "order.h"
#include "Date.h"
#include "Database.h"
#include "patient.h"
#include "Shipment.h"

using namespace std;

/**
   A representation of a physical KSU campus

   @author Daniel Earley
*/
class campus
{
public:
	
	void set_location(int campus_index);
	string get_location(); //Returns the location name of the campus

	
	int get_supply_count(); //Returns how many vaccines are available from its 'supply' object

	bool receive_shipment();
	float receive_payment();
	void send_payment(float payment_amount);


	//Just needed to declare these to clear the other errors
	int get_avg_days_to_receive_shipment();

	/**
	 * Determines if an order for more vaccines need to be placed
	 * @return true if need to order, otherwise false
	 * @param past_week_count how many appointments this campus had last week
	 * @param next_week_count how many appointments this campus is scheduled to have in the next week
	 * @author Daniel
	 */
	bool need_to_order(int past_week_count, int next_week_count);


	/**
	 * Gets the id of this appointment's location
	 * @return location's index/id
	 * @author Clay
	 */
	int get_location_id();



	/**
	 * Creates the campus supply object
	 * @return the created supply object
	 * @author Daniel
	 */
	Supply* init_supply();

	/**
	 * Gets the campus supply object
	 * @return campus supply object
	 * @author Sean
	 */
	Supply* get_supply();
	
	/**
	 * Sets the campus supply object
	 * @author Daniel
	 */
	void set_supply(Supply* s);

	/**
	 * Verifies order submission
	 * @return true if order is placed, otherwise false
	 * @author Sean
	 */
	bool verify_order();
	
	/**
	 * Checks the average of how many vaccines are being used per day(rounded up) against the current stock
	 * @return the expected number of days before the stock is depleted.
	 * @param past_week_count how many appointments this campus had last week
	 * @param next_week_count how many appointments this campus is scheduled to have in the next week
	 * @author Daniel
	 */
	int get_days_to_run_out(int past_week_count, int next_week_count);


	/**
	 * Gets all the past orders from this campus
	 * @param start_date The date in string format of the start of the time range to find orders in
	 * @param end_date The date in string format of the end of the time range to find orders in
	 * @return A vector of pointers to order objects depicting orders from this campus in the given time range
	 */
	std::vector<Order*> get_past_orders(std::string start_date, std::string end_date, bool all);
	
	/**
	 * Gets past shipments then suptracts the dates recvide from shiped to get the average
	 */
	int get_avg_days_to_receive_shipment()
	
	/*
	searches the chipments database for a campus id and outputs it 
	@author arthur
	*/
	//	TO FIX : Arthur
	
	//std::vector<shipment>> get_past_shipments(int days);
	
	/**
	 * Estimates how many doses should be requested in a new order given the avg days it takes to receive a shipment, the avg doses used each day, and the num days to run out
	 * @param avg_appointments_completed_per_day The average number of appointments completed per day from an anonymous date range
	 * @returns Int: num doses to request in an order
	 * @author Clay
	 * @date 04/26/2021
	 */
	int estimate_num_doses_needed(int avg_appointments_completed_per_day);

private:
	string location = "";
	Supply campus_supply;
	float account_balance;
};

#endif
