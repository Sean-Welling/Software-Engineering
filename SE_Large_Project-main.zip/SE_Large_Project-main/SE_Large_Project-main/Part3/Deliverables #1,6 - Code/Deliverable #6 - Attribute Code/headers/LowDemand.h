//
//  LowDemand.h
//  
//
//  Created by Arthur Wolff on 3/18/21.
//

#ifndef LowDemand_h
#define LowDemand_h

// ----- Relationships -----
// Supply: Association
// Appointment: Association
// Campus: Association

#include <list>
using namespace std;

class LowDemand
{
public:
    bool supply(int item) const;
    bool appointment(int item) const;
    bool campus(int item) const;
    
private:
    list<int> items;
    
};

#endif /* LowDemand_h */
