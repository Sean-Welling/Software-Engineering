//
//  Appointment.h
//  
//
//  Created by Arthur Wolff on 3/18/21.
//

#ifndef Appointment_h
#define Appointment_h

// ------ Relationships ------
// Low Demand: Association
// Payment: Association
// Campus: Association
// Patient: Association
// Schedule: Aggregation

#include <list>
using namespace std;

class Appointment
{
public:
    bool lowDemand(int item) const;
    bool payment(int item) const;
    bool campus(int item) const;
    bool patient(int item) const;
    bool schedule(int item) const;
    
private:
    list<int> items;
};

#endif /* Appointment_h */
