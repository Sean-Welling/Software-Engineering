#ifndef schedule_h
#define schedule_h

#include "appointment.h"

/**************************************************************************
 * Class definition : schedule
 * @author Sean Welling
 *************************************************************************/

class schedule 
{
public:
    void show_schedule(); //Displays the overall schedule of upcoming appointments
    void add_appointment(int MM, int DD, int time); //Adds an appointment to the schedule
    void remove_appointment(int MM, int DD, int time); //Removes appointment from the schedule
};

#endif /* schedule_h */