/*
   campus.h

   Declaration file for the campus class.
   
*/

#ifndef campus_h
#define campus_h

#include <string>
#include "supply.h"

using namespace std;

/**
   A representation of a physical KSU campus

   @author Daniel Earley
*/
class campus
{
public:
	string get_location();
	bool receive_shipment();
	float receive_payment();
	void send_payment(float payment_amount);

private:
	string location;
	Supply campus_supply;
	float account_balance;
};

#endif
