#include "../headers/payment.h"

/**************************************************************************
 * Implementation of payment.h
 *************************************************************************/

bool Payment::patient_is_insured(patient p)
{

    return 0;
}