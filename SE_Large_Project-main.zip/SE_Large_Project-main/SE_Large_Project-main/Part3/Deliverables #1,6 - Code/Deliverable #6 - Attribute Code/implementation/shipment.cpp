#include "../headers/shipment.h"

/**************************************************************************
 * Implementation of shipment.h
 *************************************************************************/

int Shipment::determine_doses(Supply s)
{

    return 0;
}

int **Shipment::split_between_campuses()
{

    return 0;
}

void Shipment::send_shipment()
{

    return;
}