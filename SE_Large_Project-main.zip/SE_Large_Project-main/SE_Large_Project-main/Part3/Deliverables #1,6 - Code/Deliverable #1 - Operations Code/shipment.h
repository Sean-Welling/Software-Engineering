//  shipment.h
//  Author: Clay Casper
//  Date: 3/24/2021

/*
    Relationships
    -------------
    Supply - Association
    Campus - Association
    Order - Association
*/

#ifndef shipment_h
#define shipment_h

#include <iostream>
#include <string>

#include "Supply.h"

/**************************************************************************
 * Class definition : Shipment
 * @author Clay Casper
 *************************************************************************/

class Shipment
{
private:
public:
    /**
     * Based off the given supply, determines how many doses to send in the shipment.
     * 
     * @param s The supply being considered when determining how many doses to send.
     * @return The number of doses to be sent in the shipment.
     */
    int determine_doses(Supply s);

    /**
     * Divides this shipment between all the campuses. One campus may receive all, none, or a part of the shipment.
     * 
     * @return An array of the campuses and the associated number of doses to receive from this shipment.
     */
    int **split_between_campuses();

    /**
     * Sends the shipment to KSU-HS where it is then divided amongst campuses and sent to the campuses.
     */
    void send_shipment(); //maybe add validation : see payment
};

#endif