//  order.h
//  Author: Clay Casper
//  Date: 3/24/2021

/*
    Relationships
    -------------
    Shipment - Association
    Campus - Association
*/

#ifndef order_h
#define order_h

#include <iostream>
#include <string>

#include "./Supply.h"

/**************************************************************************
 * Class definition : Order
 * @author Clay Casper
 *************************************************************************/

class Order
{

private:
public:
    /**
     * Based off the given supply, determines how many doses to request in the order.
     * 
     * @param s The supply being considered when determining how many doses to request.
     * @return The number of doses to be requested in the order.
     */
    int determine_doses_needed(Supply s);
    /**
     * Sends the order to the KSU-HS where it is routed to a pharmaceutical company
     */
    void send_order(); //Might want to validate the receiver received the payment
};

#endif