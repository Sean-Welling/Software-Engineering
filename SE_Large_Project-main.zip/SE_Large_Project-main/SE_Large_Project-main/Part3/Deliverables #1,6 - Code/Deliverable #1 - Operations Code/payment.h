//  payment.h
//  Author: Clay Casper
//  Date: 3/24/2021

/*
    Relationships
    -------------
    Appointment - Association
    Campus - Association
*/

#ifndef payment_h
#define payment_h

#include <iostream>
#include <string>

#include "./patient.h"

/**************************************************************************
 * Class definition : Payment
 * @author Clay Casper
 *************************************************************************/

class Payment
{

private:
public:
    /**
     * Determines whether theh given patient is insured or not.
     * 
     * @param p The patient.
     * @return Whether or not the given patient is insured.
     */
    bool patient_is_insured(patient p);
};

#endif