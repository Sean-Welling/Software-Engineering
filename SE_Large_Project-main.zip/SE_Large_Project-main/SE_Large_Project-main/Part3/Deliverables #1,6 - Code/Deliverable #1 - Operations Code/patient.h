/*
   patient.h

   Declaration file for the patient class.

*/

#ifndef patient_h
#define patient_h

#include <string>


using namespace std;

/**
   Stores patient information

   @author Daniel Earley
*/
class patient {
public:
	bool receive_vaccine_dose();
	void show_vaccine_history();
	void show_appointment_schedule();
private:


};

#endif