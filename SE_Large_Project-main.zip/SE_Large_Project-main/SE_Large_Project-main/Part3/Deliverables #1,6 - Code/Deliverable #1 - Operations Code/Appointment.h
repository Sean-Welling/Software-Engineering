//
//  Appointment.h
//  
//
//  Created by Arthur Wolff on 3/18/21.
//

#ifndef Appointment_h
#define Appointment_h


#include <list>
using namespace std;

class Appointment
{
public:
    bool lowDemand() const;
    bool payment() const;
    bool campus() const;
    bool patient() const;
    bool schedule() const;
    
private:
};

#endif /* Appointment_h */
