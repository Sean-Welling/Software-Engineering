/*
   campus.h

   Declaration file for the campus class.
   
*/

#ifndef campus_h
#define campus_h

#include <string>

using namespace std;

/**
   A representation of a physical KSU campus

   @author Daniel Earley

*/
class campus {
public:
	string get_location();
	bool receive_shipment();
	float receive_payment();
	void send_payment();

private:


};

#endif
