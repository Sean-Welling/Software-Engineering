#ifndef schedule_h
#define schedule_h

#include "appointment.h"

/**************************************************************************
 * Class definition : schedule
 * @author Sean Welling
 *************************************************************************/

class schedule 
{
public:
    void show_schedule(); //Displays the overall schedule of upcoming appointments
    void add_appointment(); //Adds an appointment to the schedule
    void remove_appointment(); //Removes appointment from the schedule
};

#endif /* schedule_h */