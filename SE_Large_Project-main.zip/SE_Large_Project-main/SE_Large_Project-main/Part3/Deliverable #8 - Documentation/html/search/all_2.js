var searchData=
[
  ['determine_5fdoses_2',['determine_doses',['../class_shipment.html#ae3298b9ed746b953f1a860035316d8aa',1,'Shipment']]],
  ['determine_5fdoses_5fneeded_3',['determine_doses_needed',['../class_order.html#a65f7c12dabdc59709a2f10c363b75be3',1,'Order']]]
];
