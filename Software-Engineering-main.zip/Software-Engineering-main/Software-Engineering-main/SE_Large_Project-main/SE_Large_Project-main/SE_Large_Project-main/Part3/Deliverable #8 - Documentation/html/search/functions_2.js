var searchData=
[
  ['send_5forder_31',['send_order',['../class_order.html#aa222849ba341eec90d84e65a5b781070',1,'Order']]],
  ['send_5fshipment_32',['send_shipment',['../class_shipment.html#a5886af3e76d316112b790aa3cc516b49',1,'Shipment']]],
  ['split_5fbetween_5fcampuses_33',['split_between_campuses',['../class_shipment.html#aa9c0b19e24a250805f1870cd6e6dcdc1',1,'Shipment']]]
];
