#include "../headers/order.h"

/**************************************************************************
 * Implementation of order.h
 *************************************************************************/

int Order::determine_doses_needed(Supply s)
{

    return 0;
}

void Order::send_order()
{

    return;
}