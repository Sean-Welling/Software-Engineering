//
//  Supply.h
//
//
//  Created by Arthur Wolff on 3/18/21.
//

#ifndef Supply_h
#define Supply_h

#include <list>
using namespace std;

// ----- Relationships -------
// Vaccine: Aggregation
// Low Demand: Association
// Campus: Association
// Shipment: Association

class Supply
{
public:
    bool vaccine(int item) const;
    bool lowDemand(int item) const;
    bool campus(int item) const;
    bool shipment(int item) const;

private:
    list<int> items;
};

#endif