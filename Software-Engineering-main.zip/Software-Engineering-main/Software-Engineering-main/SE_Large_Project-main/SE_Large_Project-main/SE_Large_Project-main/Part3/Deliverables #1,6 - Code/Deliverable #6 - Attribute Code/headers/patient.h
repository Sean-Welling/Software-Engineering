/*
   patient.h

   Declaration file for the patient class.

*/

#ifndef patient_h
#define patient_h

#include <string>
#include "studentStaff.h"
#include "appointment.h"
#include "vaccine.h"

using namespace std;

/**
   Stores patient information

   @author Daniel Earley
*/
class patient
{
public:
	bool receive_vaccine_dose(vaccine dose, Appointment reception_date);
	void show_vaccine_history();
	void show_appointment_schedule();

private:
	string insurance_provider;
	studentStaff self;
	Appointment upcoming;
	Appointment previous;
};

#endif