#ifndef studentStaff_h
#define studentStaff_h

/**************************************************************************
 * Class definition : studentStaff
 * @author Sean Welling
 *************************************************************************/

class studentStaff 
{
public:
    void get_user_info(); //Gets user information such as:name, birth, age, address, phone, role(grade or job role), KSU - ID number
};

#endif /* studentStaff_h */