//
//  Supply.h
//
//
//  Created by Arthur Wolff on 3/18/21.
//

#ifndef Supply_h
#define Supply_h

#include <list>
using namespace std;

class Supply
{
public:
    bool vaccine() const;
    bool lowDemand() const;
    bool campus() const;
    bool shipment() const;
    
private:

};

