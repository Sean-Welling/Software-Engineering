/*
   vaccine.h

   Declaration file for the vaccine class.

*/

#ifndef vaccine_h
#define vaccine_h


#include <string>

using namespace std;

/**
   Stores brand and dose information about a particular vaccine

   @author Daniel Earley

*/
class vaccine {
public:
	string display_info();
	
private:


	
};

#endif
