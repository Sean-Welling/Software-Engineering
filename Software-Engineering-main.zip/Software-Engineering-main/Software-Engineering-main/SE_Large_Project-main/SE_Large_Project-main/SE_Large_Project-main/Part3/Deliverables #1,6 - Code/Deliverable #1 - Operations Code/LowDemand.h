//
//  LowDemand.h
//  
//
//  Created by Arthur Wolff on 3/18/21.
//

#ifndef LowDemand_h
#define LowDemand_h

#include <list>
using namespace std;

class LowDemand
{
public:
    bool supply() const;
    bool appointment() const;
    bool campus() const;
    
private:
    
};

#endif /* LowDemand_h */
