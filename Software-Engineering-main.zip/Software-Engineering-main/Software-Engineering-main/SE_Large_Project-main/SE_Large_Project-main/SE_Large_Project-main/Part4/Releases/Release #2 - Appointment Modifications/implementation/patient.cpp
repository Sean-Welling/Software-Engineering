#include "../headers/patient.h"

/**************************************************************************
 * Implementation of patient.h
 *************************************************************************/

std::vector<std::string> patient::get_studentStaff(studentStaff *ss){
    std::vector<std::string> new_record;
    new_record = ss->get_user_info();

    /*
    cout << "Record ID: " << new_record[0] << "\n"
         << "Record Username: " << new_record[1] << endl;
    */
    //return this->self;
    return new_record;
}

patient::patient()
{
    // std::cout << "Creating patient object...\n";
    //std::vector<std::string> patient_record;
    //patient_record = get_user_info();
    //string id, username, firstname, lastname, role, address, phone, age = patient::get_studentStaff();
    this->id = "not set";
}

void patient::register_patient(patient *p, studentStaff *ss)
{
    // Set patient attributes using studentStaff record
    std::vector<std::string> new_record = get_studentStaff(ss);
    id = new_record[0];
    username = new_record[1];
    firstname = new_record[2];
    lastname = new_record[3];
    role = new_record[4];
    address = new_record[5];
    phone = new_record[6];
    age = new_record[7];

    // Assign KSU-HS ID number
    patient_id_num = "ksuhs" + id;

    // Add patient record to patient database

        // Create stream
        std::ofstream database;

        // Open file
        database.open("../database/patient.csv", std::ios_base::app);
        database << id << "," << username << "," << firstname << "," << lastname << "," << role << "," << address << "," << phone << "," << age << "," << patient_id_num << std::endl;
        database.close();
}

void patient::get_patient(patient *p)
{
    std::cout << "Please enter your Patient ID Number: \n";
    std::cin >> patient_id_num;
    std::cout << "Gathering patient records from the KSU_HS Patient DB...\n";

    // Create studentStaff record to be returned
    std::vector<std::string> record;

    // Create stream
    std::ifstream database;

    // Open file
    database.open("../database/patient.csv");

    bool found_record = false;

    std::string record_one;
    std::string record_two;
    std::string record_three;
    std::string record_four;
    std::string record_five;
    std::string record_six;
    std::string record_seven;
    std::string record_eight;
    std::string record_nine;
    std::string record_ten;

    while (getline(database, record_one, ',') && !found_record)
    {
        getline(database, record_two, ',');
        getline(database, record_three, ',');
        getline(database, record_four, ',');
        getline(database, record_five, ',');
        getline(database, record_six, ',');
        getline(database, record_seven, ',');
        getline(database, record_eight, ',');
        getline(database, record_nine, ',');
        getline(database, record_ten, '\n');

        if (record_nine == patient_id_num)
        {
            found_record = true;
            record.push_back(record_one);
            record.push_back(record_two);
            record.push_back(record_three);
            record.push_back(record_four);
            record.push_back(record_five);
            record.push_back(record_six);
            record.push_back(record_seven);
            record.push_back(record_eight);
            record.push_back(record_nine);
            record.push_back(record_ten);
        }
    }

    std::cout << record[0] << " " << record[1] << " " << record[2] << " " << record[3] << " " << record[4] << " " << record[5] << " " << record[6] << " " << record[7] << " " << record[8] << " " <<  record[9] << "\n";

    id = record[0];
    username = record[1];
    firstname = record[2];
    lastname = record[3];
    role = record[4];
    address = record[5];
    phone = record[6];
    age = record[7];
    patient_id_num = record[8];
    vaccine_type = record[9];

    // Close file
    database.close();

}

std::vector<std::string> patient::find_patient_record(){
    int ID_INDEX = 0;
    //open the patient DB
    ifstream db;
    db.open("database/patient.csv");

    std::string curr_line;
    std::vector<std::string> curr_record;

    if(!db.is_open()){
        std::cout << "Couldn't open file\n";
        return curr_record;
    }

    int line_num = 0;
    while(getline(db, curr_line)){
        if(line_num != 0){
            curr_record = format_patient_record(curr_line);
            
            if(curr_record.at(ID_INDEX) == this->id){
                db.close();
                return curr_record;
            }
        }
        line_num++;
    }
    db.close();
    return curr_record;
}

std::vector<std::string> patient::format_patient_record(std::string line){
    std::vector<std::string> record;

    std::string curr_column = "";
    char curr_char;
    for(int i = 0; i < line.length(); i++){
        curr_char = line[i];
        if(curr_char == ','){
            record.push_back(curr_column);
            curr_column = "";
        }
        else{
            curr_column += curr_char;
        }
    }
    record.push_back(curr_column);

    return record;
}

bool patient::init_from_existing(){
    //make sure id is set
    if(this->id == "not set"){
        return false;
    }
    else{
        //get record
        std::vector<std::string> record = this->find_patient_record();

        //set id
        this->id = record.at(0);

        //set username
        this->username = record.at(1);

        //set firstname
        this->firstname = record.at(2);

        //set lastname
        this->lastname = record.at(3);

        //set role
        this->role = record.at(4);

        //set address
        this->address = record.at(5);

        //set phone
        this->phone = record.at(6);

        //set age
        this->age = record.at(7);

        //set patient id num
        this->patient_id_num = record.at(8);

        return true;
    }
}