#include "../headers/Appointment.h"
#include "../headers/System.h"
#include "appointment.cpp"
#include "../headers/Appointment.h"


int main()
{
    // campus* c = new campus();
    // c->set_location(0);

    // std::cout << "campus id : " << c->get_location_id() << "\n";

    // std::vector<Appointment*> appointments = find_appointments_by_campus(c);
    print_padded("Initializing system...");
    bool no_error = true;
    schedule* curr_schedule = new schedule();

    //get current date

    std::vector<Appointment*> past_apmts;

    //get all past appointments using current date
    past_apmts = get_past_apmts();
    std::cout << past_apmts[0] << "\n";


    campus* c = new campus();
    c->set_location(0);

    find_appointments_by_campus(c);


    std::cout << "Done!\n";

    return 0;
}