//
//  appointment.cpp
//
//
//  Created by Arthur Wolff on 3/22/21.
//

#include "../headers/Appointment.h"

/*
 
 Implementation of Appointment.h

 */

const int CURR_YEAR = 2021;

std::string month_names[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

int month_days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

Appointment::Appointment()
{

    //set leap year days
    if (CURR_YEAR % 4 == 0)
    {
        if (CURR_YEAR % 100 == 0)
        {
            if (CURR_YEAR % 400 == 0)
            {
                //leap year
                month_days[1] = 29;
            }
        }
        else
        {
            //leap year
            month_days[1] = 29;
        }
    }

    this->id = -1;
}

Appointment::Appointment(patient *p, std::string date, std::string time)
{
    //set patient, date, and time
    this->set_patient(p);
    this->set_date(date);
    this->set_time(time);

    //set leap year days
    if (CURR_YEAR % 4 == 0)
    {
        if (CURR_YEAR % 100 == 0)
        {
            if (CURR_YEAR % 400 == 0)
            {
                //leap year
                month_days[1] = 29;
            }
        }
        else
        {
            //leap year
            month_days[1] = 29;
        }
    }
}

bool Appointment::set_patient(patient *p)
{
    this->p = p;

    if (this->p == p)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_date(std::string date)
{
    this->date = date;

    if (this->date == date)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_time(std::string time)
{
    this->time = time;

    if (this->time == time)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_id(int id)
{
    this->id = id;

    if (this->id == id)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_campus(campus *c)
{
    this->c = c;

    if (this->c == c)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

//getters

patient *Appointment::get_patient()
{
    return this->p;
}

std::string Appointment::get_date()
{
    return this->date;
}

std::string Appointment::get_time()
{
    return this->time;
}

int Appointment::get_id()
{
    return this->id;
}

campus *Appointment::get_campus()
{
    return this->c;
}

int Appointment::log_appointment()
{
    //open appointment log file
    std::string filename = "database/appointments.csv";

    //create file stream
    std::ofstream log;

    //open the file
    log.open(filename, std::ios::app);

    if (!log)
    {
        return 0;
    }

    //write to file
    log << this->id << "," << this->p->id << "," << this->date << "," << this->time << ","
        << to_string(this->c->get_location_id()) << "\n";

    //close file
    log.close();

    return 1;
}

int Appointment::find_available_id()
{
    const int ID_INDEX = 0;

    int id = 1;
    //get all ids
    std::vector<std::vector<std::string>> rows = get_appointment_rows();

    //check rows for matching id
    bool available = true;

    do
    {
        //check for match

        for (int i = 0; i < rows.size(); i++)
        {
            std::vector<std::string> curr_row = rows.at(i);
            //check id
            std::string curr_row_id = curr_row.at(ID_INDEX);

            int curr_id_int_v = std::stoi(curr_row_id);
            if (curr_id_int_v == id)
            {
                available = false;
                break;
            }
            else
            {
                available = true;
            }
        }

        //if match increment
        if (!available)
        {
            id++;
        }
    } while (available == false);

    return id;
}

std::vector<std::vector<std::string>> Appointment::get_appointment_rows()
{

    //create stream
    std::ifstream log;

    //open file
    log.open("database/appointments.csv");

    int row_num = 0;
    int col_num = 0;
    std::string curr_line = "";
    char curr_char;

    std::vector<std::string> lines;

    while (log.get(curr_char))
    {
        if (curr_char == '\n')
        {
            if (row_num != 0)
            {
                lines.push_back(curr_line);
            }
            curr_line = "";

            row_num++;
        }
        else
        {
            curr_line += curr_char;
        }
    }

    std::vector<std::vector<std::string>> rows;

    //create row vectors
    for (int i = 0; i < lines.size(); i++)
    {
        //read line
        rows.push_back(get_row_vector(lines.at(i)));
    }

    //close file
    log.close();

    return rows;
}

std::vector<std::string> Appointment::get_row_vector(std::string s)
{
    std::vector<std::string> row;

    std::string curr_word = "";

    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == ',')
        {
            //add col to row
            row.push_back(curr_word);
            //clear word
            curr_word = "";
        }
        else
        {
            curr_word += s[i];
        }
    }

    row.push_back(curr_word);

    return row;
}

std::string Appointment::get_second_date(int days_between)
{
    int first_date_month;
    int first_date_day;
    int first_date_year;

    int second_date_month;
    int second_date_day;
    int second_date_year;

    //parse first appointment date
    int index = 0;
    std::string curr_word = "";
    for (int i = 0; i < this->date.length(); i++)
    {
        if (this->date[i] == '/')
        {
            switch (index)
            {
            case 0:
                first_date_month = stoi(curr_word);
                break;
            case 1:
                first_date_day = stoi(curr_word);
                break;
            }
            curr_word = "";
            index++;
        }
        else
        {
            curr_word += this->date[i];
        }
    }

    first_date_year = stoi(curr_word);

    //add days
    int curr_month_index = first_date_month - 1;
    second_date_year = first_date_year;
    second_date_month = first_date_month;
    second_date_day = first_date_day;

    //add days between to first day
    second_date_day += days_between;

    //check if second day is greater than last months days
    while (second_date_day > month_days[curr_month_index])
    {
        //set second day % last month days

        second_date_day = second_date_day - month_days[curr_month_index];

        //increment the month
        if (curr_month_index == 11)
        {
            second_date_month = 1;
            curr_month_index = 0;
            second_date_year++;
        }
        else
        {
            second_date_month++;
            curr_month_index++;
        }
    }

    std::string second_date = to_string(second_date_month) + '/' + to_string(second_date_day) + '/' + to_string(second_date_year);

    return second_date;
}

bool Appointment::change_date(std::string new_date)
{
    int ID_INDEX = 0;

    //find the appointment record and delete it using the old ID
    std::vector<std::string> record = find_record_by_id(this->id);

    //old id
    int old_id = stoi(record.at(ID_INDEX));

    //Update appointment date
    if(!this->set_date(new_date)){
        return 0;
    }

    //delete the record
    schedule* current_schedule = new schedule();

    current_schedule->delete_appointment(this->id);

    //Log the new updated appointment
    if(!this->log_appointment()){
        return false;
    }

    return true;
}


bool Appointment::change_time(std::string new_time)
{
    int ID_INDEX = 0;

    //find the appointment record and delete it using the old ID
    std::vector<std::string> record = find_record_by_id(this->id);

    //old id
    int old_id = stoi(record.at(ID_INDEX));

    //Update appointment time
    if(!this->set_time(new_time)){
        return 0;
    }

    //delete the record
    schedule* current_schedule = new schedule();

    current_schedule->delete_appointment(this->id);

    //Log the new updated appointment
    if(!this->log_appointment()){
        return false;
    }

    return true;
}




//delete an appointment 
void deleteAppt(string path, string eraseLine) {
    string line;
    ifstream fin;
    
    // copies file other then the ones to be deleted
    fin.open(path);
    ofstream temp;
    temp.open("appointment.csv");

    // writes all but line to be delted into the file
    while (getline(fin, line)) {
        if (line != eraseLine)
            temp << line << endl;
    }

    temp.close();
    fin.close();

    const char * p = path.c_str();
    remove(p);
    rename("appointment.csv", p);
}

std::vector<std::string> Appointment::find_record_by_id(int id)
{
    //The index of the ID column
    int ID_INDEX = 0;

    //get all appointment rows
    std::vector<std::vector<std::string>> all_rows = this->get_appointment_rows();

    //Loop through all rows and check the id
    std::vector<std::string> current_row;
    for (int row_num = 0; row_num < all_rows.size(); row_num++)
    {
        current_row = all_rows.at(row_num);
        if (stoi(current_row.at(ID_INDEX)) == id)
        {
            return current_row;
        }
    }
    return current_row;
}

int Appointment::get_record_number(int id)
{
    //The index of the ID column
    int ID_INDEX = 0;

    //get all appointment rows
    std::vector<std::vector<std::string>> all_rows = this->get_appointment_rows();

    //Loop through all rows and check the id
    for (int row_num = 0; row_num < all_rows.size(); row_num++)
    {
        std::vector<std::string> current_row = all_rows.at(row_num);
        if (stoi(current_row.at(ID_INDEX)) == id)
        {
            return row_num;
        }
    }
    return -1;
}

bool Appointment::init_from_existing(){
    //make sure id is set
    if(this->id == -1){
        return false;
    }
    else{
        //get record
        std::vector<std::string> appointment_record = this->find_record();

        //get patient
        //create new patient
        patient* apmt_patient = new patient();
        //use appointment record to set patient id
        apmt_patient->id = appointment_record[1];
        //find the patient's record
        std::vector<std::string> patient_record = apmt_patient->find_patient_record();
        //set apmt patient
        //init patient
        apmt_patient->init_from_existing();
        if(!this->set_patient(apmt_patient)){
            return false;
        }

        //set date
        if(!this->set_date(appointment_record.at(2))){
            return false;
        }

        //set time
        if(!this->set_time(appointment_record.at(3))){
            return false;
        }

        //get campus
        //create new campus
        campus* apmt_campus = new campus();
        //set location of campus
        apmt_campus->set_location(stoi(appointment_record.at(4)));

        //set appointment campus
        if(!this->set_campus(apmt_campus)){
            return false;
        }

        return true;
    }
}

std::vector<std::string> Appointment::find_record(){
    int ID_INDEX = 0;
    //open the patient DB
    ifstream db;
    db.open("database/appointments.csv");

    std::string curr_line;
    std::vector<std::string> curr_record;

    if(!db.is_open()){
        std::cout << "Couldn't open file\n";
        return curr_record;
    }

    int line_num = 0;
    while(getline(db, curr_line)){
        if(line_num != 0){
            curr_record = this->get_row_vector(curr_line);
            
            if(stoi(curr_record.at(ID_INDEX)) == this->id){
                db.close();
                return curr_record;
            }
        }
        line_num++;
    }
    db.close();
    return curr_record;
}

void Appointment::display_details(){
    std::cout << "Appointment Details\n";
    std::cout << "=============================\n\n";

    std::cout << "ID : " + to_string(this->id) + "\n";
    std::cout << "Campus : " + this->c->get_location() + "\n";
    std::cout << "Date : " + this->date + "\n";
    std::cout << "Time : " + this->time + "\n";
    std::cout << "Patient : " + this->p->firstname + " " + this->p->lastname + "\n\n";
}

bool Appointment::modify(){
    //display details
    this->display_details();

    //prompt user what they want to do
    std::cout << "How do you want to modify your appointment?\n\n";
    std::cout << "(1) Change campus\n";
    std::cout << "(2) Change date\n";
    std::cout << "(3) Change time\n";
    std::cout << "(4) Cancel appointment\n";

    int choice;
    std::cout << "Choice : ";
    std::cin >> choice;

    std::string new_date;
    std::string new_time;


    switch (choice)
    {
    case 1:
        //call change campus
        std::cout << "Which location would you like to move your appointment to?\n\n";
        std::cout << "(1) Ashtabula\n";
        std::cout << "(2) East Liverpool\n";
        std::cout << "(3) Geauga\n";
        std::cout << "(4) Kent\n";
        std::cout << "(5) Salem\n";
        std::cout << "(6) Stark\n";
        std::cout << "(7) Trumbull\n";
        std::cout << "(8) Tuscarawas\n";

        int new_location;
        do{
        std::cout << "Choice : ";
        std::cin >> new_location;
        if (new_location < 1 || new_location > 8){
            std::cout << "Sorry, that was an invalid entry. Please select one of the locations 1-8.\n";
        }
        } while (new_location < 1 || new_location > 8);

        this->c->set_location(new_location -1);
        this->set_campus(c);

        std::cout << "Available appointments for " << this->c->get_location() << " at " << this->time << "\n";
        std::cout << "================================================\n\n";
        
        std::cout << "New date : ";
        std::cin >> new_date;

        //call change date
        if (!this->change_date(new_date))
        {
            return false;
        }

        break;

    case 2: {
        //Check if they want to stay at the same campus
        std::cout << "Do you still want to get your vaccine at the " << this->c->get_location() << " campus? (y/n): ";
        //wait for correct response
        char response;
        do{
            //get response
            std::cin >> response;
            if(response != 'y' && response != 'n')
                std::cout << "Sorry, I don't understand. Type either a 'y' for yes or 'n' for no.\n";
        }while(response != 'y' && response != 'n');

        if(response == 'y'){
            std::cout << "Available appointments for " << this->c->get_location() << " at " << this->time << "\n";
            std::cout << "================================================\n\n";
            

        }
        else{
            std::cout << "Available dates for all campuses at " << this->time << "\n";
            std::cout << "================================================\n\n";
        }

        std::cout << "New date : ";
        std::string new_date;
        std::cin >> new_date;

        //call change date
        if(!this->change_date(new_date)){
            return false;
        }
        else{
            print_padded("Successfully changed your appointment date!\n\n");
            this->display_details();
        }
        
        break;
    }

    case 3:
        //call change time
        std::cout << "Do you still want to get your vaccine at the " << this->c->get_location() << " campus? (y/n): ";
        //wait for correct response
        char response;
        do{
            //get response
            std::cin >> response;
            if(response != 'y' && response != 'n')
                std::cout << "Sorry, I don't understand. Type either a 'y' for yes or 'n' for no.\n";
        }while(response != 'y' && response != 'n');

        if(response == 'y'){
            std::cout << "Available appointments for " << this->c->get_location() << " on " << this->date << "\n";
            std::cout << "================================================\n\n";
            

        }
        else{
            std::cout << "Available times for all campuses on " << this->date << "\n";
            std::cout << "================================================\n\n";
        }

        std::cout << "New time : ";
        std::cin >> new_time;

        //call change date
        if(!this->change_time(new_time)){
            return false;
        }
        else{
            print_padded("Successfully changed your appointment time!\n\n");
            this->display_details();
        }

        break;

    case 4:
        //call delete appointment
        break;
    
    default:
        break;
    }
    return true;
}
