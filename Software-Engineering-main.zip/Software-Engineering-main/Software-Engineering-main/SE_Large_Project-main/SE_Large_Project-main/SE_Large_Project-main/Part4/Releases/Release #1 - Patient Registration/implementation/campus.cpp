#include "../headers/campus.h"

/**************************************************************************
 * Implementation of campus.h
 *************************************************************************/


//Array of campus names (alphabetical)
std::string campus_names[] = { "Ashtabula", "East Liverpool", "Geauga", "Kent", "Salem", "Stark", "Trumbull", "Tuscarawas"};


void campus::set_location(int campus_index)
{
	location = campus_names[campus_index];
}

string campus::get_location()
{
	return location;
}


int campus::get_supply_count()
{
	return campus_supply.get_vaccine_count();
}
