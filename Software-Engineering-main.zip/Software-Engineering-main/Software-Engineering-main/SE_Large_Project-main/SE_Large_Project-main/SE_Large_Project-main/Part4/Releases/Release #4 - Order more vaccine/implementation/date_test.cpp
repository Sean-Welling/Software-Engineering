#include <iostream>

#include "../headers/Date.h"

//Test file for testing Date.h

int main(){
    std::cout << "Testing date class...\n\n";

    Date* date1 = new Date("05/11/2021");
    Date* date2 = new Date("05/11/2021");

    std::cout << compare_dates(date1, date2) << "\n";

    delete date1;
    delete date2;

    date1 = new Date("05/10/2021");
    date2 = new Date("05/11/2021");

    std::cout << compare_dates(date1, date2) << "\n";

    delete date1;
    delete date2;

    date1 = new Date("05/11/2021");
    date2 = new Date("05/10/2021");

    std::cout << compare_dates(date1, date2) << "\n";

    delete date1;
    delete date2;

    return 0;
}