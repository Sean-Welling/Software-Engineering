/*
   patient.h

   Declaration file for the patient class.

*/

#ifndef patient_h
#define patient_h

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "studentStaff.h"
#include "vaccine.h"
 
using namespace std;


/**
   Stores patient information

   @author Daniel Earley
*/
class patient
{
	 
public:
	string id;
	string username;
	string firstname;
	string lastname;
	string role;
	string address;
	string phone;
	string age;
	string patient_id_num;
	string vaccine_type;

	//studentStaff ss;

	bool receive_vaccine_dose(vaccine dose/*, Appointment reception_date*/);
	void show_vaccine_history();
	void show_appointment_schedule();

	patient();

	/**
     * Gets records from the patient database and assigns those attributes to a patient object
	 * @param p a patient object
     */
	void get_patient(patient *p);
	
	/**
     * Gets records from the patient database and assigns those attributes to a patient object
	 * @param p a patient object
     */
	void get_patient(patient *p, string patient_id_num);

	/**
	 * Finds this patient's record in the DB
	 * @return A vector representing this patient's record in the DB
	 * @author Clay
	 */
	std::vector<std::string> find_patient_record();

	/**
	 * Turns a string into a vector representing one patient record from the DB
	 * @param line The string to turn into the vector
	 * @return A vector containing all columns of the record
	 * @author Clay
	 */
	std::vector<std::string> format_patient_record(std::string line);

	/**
     * Gets records from the studentStaff database
     * @return single record from the database :: record = [id, username, firstname, lastname, role, address, phone, age]
     */
	std::vector<std::string> get_studentStaff(studentStaff *ss);

	/**
     * Adds a patient record to the patient database
	 * @param p a patient object
	 * @param ss a studentStaff object
     * @return single record from the database :: record = [id, username, firstname, lastname, role, address, phone, age]
     */
	void register_patient(patient *p, studentStaff *ss);

	/**
     * Set this patient's attributes using its ID and existing information
     * @return true: success | false: failed
     * @author Clay
     */
    bool init_from_existing();

	//get_studentStaff(studentStaff *ss);//Added by Clay

private:
	string insurance_provider;
	studentStaff* self;
	// Appointment upcoming; /* Taken out by Clay */
	// Appointment previous; /* Taken out by Clay */
};

#endif