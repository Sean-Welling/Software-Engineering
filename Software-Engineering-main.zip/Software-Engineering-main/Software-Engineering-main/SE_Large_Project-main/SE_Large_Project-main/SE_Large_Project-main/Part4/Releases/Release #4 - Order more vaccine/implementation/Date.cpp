/*
    Implementation file for custom Date class

    Date Created: 04/22/2021

    Author: Clay
*/

#include "../headers/Date.h"

//Constructors
Date::Date(){

}
Date::Date(int month, int day, int year){
    if(this->set_month(month)){
        if(this->set_day(day)){
            if(!this->set_year(year)){
                std::cout << "Couldn't set this date's year\n";
            }
        }
        else{
            std::cout << "Couldn't set this date's day\n";
        }
    }
    else{
        std::cout << "Couldn't set this date's month\n";
    }
}
Date::Date(std::string month, std::string day, std::string year){
    if(this->set_month(stoi(month))){
        if(this->set_day(stoi(day))){
            if(!this->set_year(stoi(year))){
                std::cout << "Couldn't set this date's year\n";
            }
        }
        else{
            std::cout << "Couldn't set this date's day\n";
        }
    }
    else{
        std::cout << "Couldn't set this date's month\n";
    }
}
Date::Date(std::string full_date){
    //check format
    if(full_date[2] == '/' && full_date[5] == '/'){
        //Parse string for month, day, and year
        std::string* members = this->parse_date_string(full_date, "mm/dd/yyyy");

        //initialize members
        this->set_month(stoi(*members));
        this->set_day(stoi(*(members+1)));
        this->set_year(stoi(*(members+2)));
    }
    else{
        std::cout << "Couldn't initialize the new date's members because the input string had an incorrect format.\n";
    }
}

//Setters
bool Date::set_month(int month){
    this->month = month;
    if(this->month == month){
        return true;
    }
    else{
        return false;
    }
}
bool Date::set_day(int day){
    this->day = day;
    if(this->day == day){
        return true;
    }
    else{
        return false;
    }
}
bool Date::set_year(int year){
    this->year = year;
    if(this->year == year){
        return true;
    }
    else{
        return false;
    }
}

//Getters
int Date::get_month(){
    return this->month;
}
int Date::get_day(){
    return this->day;
}
int Date::get_year(){
    return this->year;
}

//Other

std::string* Date::parse_date_string(std::string date, std::string format){
    if(format != "mm/dd/yyyy" && format != "mm-dd-yyyy"){
        return NULL;
    }
    else{
        //https://stackoverflow.com/questions/7527356/return-string-array-in-c-function
        std::string* parsed_date = new std::string[3];

        if(format == "mm/dd/yyyy"){
            std::vector<std::string> parsed = this->split_string(date, '/');

            parsed_date[0] = parsed.at(0);
            parsed_date[1] = parsed.at(1);
            parsed_date[2] = parsed.at(2);
        }
        else if(format == "mm-dd-yyyy"){
            std::vector<std::string> parsed = this->split_string(date, '-');

            parsed_date[0] = parsed.at(0);
            parsed_date[1] = parsed.at(1);
            parsed_date[2] = parsed.at(2);
        }
        return parsed_date;
    }
}

std::vector<std::string> Date::split_string(std::string base, char delim){
    std::vector<std::string> split_strings;

    //go through each character and check for the delim
    std::string current_word = "";
    for(int i = 0; i < base.length(); i++){
        //check for delim
        if(base[i] == delim){
            //add current_string to array
            split_strings.push_back(current_word);

            //reset the current string
            current_word = "";
        }
        else{
            //add current char to current string
            current_word += base[i];
        }
    }

    //add last word
    split_strings.push_back(current_word);

    return split_strings;
}

void Date::print_date(std::string format){
    std::string acceptable_formats[] = {"mm/dd/yyyy", "mm/dd/yy", "mm-dd-yyyy", "mm-dd-yy"};
    //check format
    bool good_format = false;
    for(int i = 0; i < sizeof(acceptable_formats)/sizeof(acceptable_formats[0]); i++){
        if(format == acceptable_formats[i]){
            good_format = true;
        }
    }

    if(good_format){
        //get delimeter
        char delim = this->get_delim(format);
        
        std::vector<std::string> split_format = this->split_string(format, delim);

        //print
        int month_iteration = 0;
        int day_iteration = 0;
        int year_iteration = 0;
        if(split_format.at(2) == "yy"){
            year_iteration = 2;
        }

        std::string month_string = this->format_element_string(this->month);
        std::string day_string = this->format_element_string(this->day);
        std::string year_string = std::to_string(this->year);

        for(int i = 0; i < format.length(); i++){
            switch(format[i]){
                case 'm':{
                    std::cout << month_string[month_iteration];
                    month_iteration++;
                    break;
                }
                case 'd':{
                    std::cout << day_string[day_iteration];
                    day_iteration++;
                    break;
                }
                case 'y':{
                    std::cout << year_string[year_iteration];
                    year_iteration++;
                    break;
                }
                default:{
                    std::cout << format[i];
                    break;
                }
            }
        }
    }
    else{
        std::cout << "Can't print date: Incorrect format\n";
    }
}

char Date::get_delim(std::string date){
    for(int i = 0; i < date.length(); i++){
        if(date[i] != 'm' && date[i] != 'd' && date[i] != 'y'){
            return date[i];
        }
    }
    return 'm';
}

std::string Date::format_element_string(int element){
    std::string formatted = "";

    if(element < 10){
        formatted += '0';
        formatted += std::to_string(element);
    }
    else{
        formatted = std::to_string(element);
    }

    return formatted;
}

int compare_dates(Date* date1, Date* date2){
    //check year
    if(date1->get_year() < date2->get_year()){
        return -1;
    }
    else if(date1->get_year() > date2->get_year()){
        return 1;
    }
    else{
        //check month
        if(date1->get_month() < date2->get_month()){
            return -1;
        }
        else if(date1->get_month() > date2->get_month()){
            return 1;
        }
        else{
            //check day
            if(date1->get_day() < date2->get_day()){
                return -1;
            }
            else if(date1->get_day() > date2->get_day()){
                return 1;
            }
            else{
                return 0;
            }
        }
    }
}