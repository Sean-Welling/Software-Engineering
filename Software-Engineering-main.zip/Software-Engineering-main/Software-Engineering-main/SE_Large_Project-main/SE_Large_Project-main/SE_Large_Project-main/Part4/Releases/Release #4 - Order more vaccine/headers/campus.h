/*
   campus.h

   Declaration file for the campus class.
   
*/

#ifndef campus_h
#define campus_h

#include <string>
#include <vector>

#include "Supply.h"
#include "order.h"
#include "Date.h"
#include "Database.h"
#include "patient.h"

using namespace std;

/**
   A representation of a physical KSU campus

   @author Daniel Earley
*/
class campus
{
public:
	
	void set_location(int campus_index);
	string get_location(); //Returns the location name of the campus

	
	int get_supply_count(); //Returns how many vaccines are available from its 'supply' object

	bool receive_shipment();
	float receive_payment();
	void send_payment(float payment_amount);

	/**
	 * Gets the id of this appointment's location
	 * @return location's index/id
	 * @author Clay
	 */
	int get_location_id();

	/**
	 * Gets all the past orders from this campus
	 * @param start_date The date in string format of the start of the time range to find orders in
	 * @param end_date The date in string format of the end of the time range to find orders in
	 * @return A vector of pointers to order objects depicting orders from this campus in the given time range
	 */
	std::vector<Order*> get_past_orders(std::string start_date, std::string end_date, bool all);

private:
	string location = "";
	Supply campus_supply;
	float account_balance;
};

#endif
