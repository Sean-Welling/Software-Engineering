#include "../headers/order.h"

/**************************************************************************
 * Implementation of order.h
 *************************************************************************/

//Setters
bool Order::set_id(int id){
    this->id = id;
    if(this->id == id){
        return true;
    }
    else{
        return false;
    }
}
bool Order::set_doses_needed(int doses_needed){
    this->doses_needed = doses_needed;
    if(this->doses_needed == doses_needed){
        return true;
    }
    else{
        return false;
    }
}
bool Order::set_requester_id(int requester_id){
    this->requester_id = requester_id;
    if(this->requester_id == requester_id){
        return true;
    }
    else{
        return false;
    }
}
bool Order::set_date_requested(std::string date_requested){
    this->date_requested = date_requested;
    if(this->date_requested == date_requested){
        return true;
    }
    else{
        return false;
    }
}
bool Order::set_fulfilled(int fulfilled){
    this->fulfilled = fulfilled;
    if(this->fulfilled == fulfilled){
        return true;
    }
    else{
        return false;
    }
}

//Getters
int Order::get_id(){
    return this->id;
}
int Order::get_doses_needed(){
    return this->doses_needed;
}
int Order::get_requester_id(){
    return this->requester_id;
}
std::string Order::get_date_requested(){
    return this->date_requested;
}
int Order::get_fulfilled(){
    return this->fulfilled;
}

int Order::determine_doses_needed(Supply s)
{

    return 0;
}

void Order::send_order()
{

    return;
}