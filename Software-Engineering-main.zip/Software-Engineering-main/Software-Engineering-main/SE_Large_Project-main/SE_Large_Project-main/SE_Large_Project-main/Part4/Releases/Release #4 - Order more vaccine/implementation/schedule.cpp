//
//  schedule.cpp
//  schedule
//
//  Created by Arthur Wolff on 4/11/21.
//

#include "../headers/schedule.h"
#include <ctime>

//Setters
bool schedule::set_appointments(std::vector<Appointment*> appointments){
    this->appointments = appointments;
    if(this->appointments == appointments){
        return true;
    }
    else{
        return false;
    }
}

//Getters
std::vector<Appointment*> schedule::get_appointments(){
    return this->appointments;
}

int current_year()
{

    time_t ttime = time(0);
    tm *local_time = localtime(&ttime);
    return 1900 + local_time->tm_year;

}

int current_month()
{

    time_t ttime = time(0);
    tm *local_time = localtime(&ttime);
    return 1 + local_time->tm_mon;


}

int current_day()
{

    time_t ttime = time(0);
    tm *local_time = localtime(&ttime);
    return local_time->tm_mday;

}

char* get_current_date()
{

    time_t ttime = time(0);
    char* dt = ctime(&ttime);
    return dt;

}


bool schedule::delete_appointment(int id){
    //get the record number
    int row_num = get_record_number(0, id, "appointments.csv") + 1;

    //Copy line
    std::string line_copy = copy_db_line("appointments.csv", row_num);

    if(delete_line("appointments.csv", row_num)){
        return true;
    }
    else{
        return false;
    }
}

std::vector<std::vector<std::string>> schedule::get_db_rows(std::string db_file)
{
    //create stream
    std::ifstream log;
    std::vector<std::vector<std::string>> rows;

    //open file
    log.open("database/" + db_file);

    if(!log.is_open()){
        std::cout << "Failed to open 1 " + db_file << "\n";
        return rows;
    }

    int row_num = 0;
    int col_num = 0;
    std::string curr_line = "";
    char curr_char;

    std::vector<std::string> lines;

    while (log.get(curr_char))
    {
        if (curr_char == '\n')
        {
            if (row_num != 0)
            {
                lines.push_back(curr_line);
            }
            curr_line = "";

            row_num++;
        }
        else
        {
            curr_line += curr_char;
        }
    }

    //create row vectors
    for (int i = 0; i < lines.size(); i++)
    {
        //read line
        rows.push_back(format_row(lines.at(i)));
    }

    //close file
    log.close();

    return rows;
}

std::vector<std::string> schedule::format_row(std::string s)
{
    std::vector<std::string> row;

    std::string curr_word = "";

    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == ',')
        {
            //add col to row
            row.push_back(curr_word);
            //clear word
            curr_word = "";
        }
        else
        {
            curr_word += s[i];
        }
    }

    row.push_back(curr_word);

    return row;
}

int schedule::get_record_number(int id_column, int id, std::string db_filename)
{
    //get all appointment rows
    std::vector<std::vector<std::string>> all_rows = this->get_db_rows(db_filename);

    //Loop through all rows and check the id
    for (int row_num = 0; row_num < all_rows.size(); row_num++)
    {
        std::vector<std::string> current_row = all_rows.at(row_num);
        if (stoi(current_row.at(id_column)) == id)
        {
            return row_num;
        }
    }
    return -1;
}

std::string schedule::copy_db_line(std::string db_filename, int line_num){
    std::string copy = "";

    //open file
    ifstream file;
    file.open("database/" + db_filename);
    if(!file.is_open()){
        std::cout << "Failed to open database/" + db_filename << "\n";
        return copy;
    }
    else{
        //read file
        int curr_line_num = 0;
        while(getline(file, copy)){
            if(curr_line_num == line_num){
                return copy;
            }
            curr_line_num++;
        }
    }
    return copy;
}

bool schedule::delete_line(std::string db_filename, int line_num){
    //get all unformatted rows
    std::string file_string = "";

    std::vector<std::vector<std::string>> all_formatted_rows = get_db_rows(db_filename);
    if(all_formatted_rows.size() == 0){
        return false;
    }

    //prepend header
    std::vector<std::string> header = get_database_header(db_filename);

    all_formatted_rows.insert(all_formatted_rows.begin(), header);

    //loop through all rows and exculde the line num to delete
    for(int i = 0; i < all_formatted_rows.size(); i++){
        if(i != line_num){
            std::string curr_unformatted_row = unformat_row(all_formatted_rows.at(i), ',');
            //add this string and line break to file string
            file_string += curr_unformatted_row;
            file_string += "\n";
        }
    }

    std::string file_to_remove = "database/" + db_filename;

    //remove old file
    if(!remove(file_to_remove.c_str())){
        //successfully removed
        //create new file
        ofstream new_file;
        new_file.open(file_to_remove);
        if(!new_file.is_open()){
            std::cout << "Couldn't create " + db_filename << "\n";
            return false;
        }
        else{
            //write new content to file
            write_to_database(file_to_remove, file_string);
        }
    }
    else{
        std::cout << "Couldn't remove " + file_to_remove << "\n";
        return false;
    }

    return true;
}

std::string schedule::unformat_row(std::vector<std::string> record, char delim){
    std::string unformatted = "";

    for(int i = 0; i < record.size(); i++){
        //add word to line
        unformatted += record.at(i);
        if(i != record.size()-1){
            unformatted += delim;
        }
    }

    return unformatted;
}

bool schedule::write_to_database(std::string db_filename, std::string content_to_write){
    //open db
    ofstream db;
    db.open(db_filename, ios::app);

    if(!db.is_open()){
        std::cout << "Couldn't open " + db_filename << "\n";
        return false;
    }
    else{
        //write to the database
        db << content_to_write;
    }
    return true;
}

std::vector<std::string> schedule::get_database_header(std::string db_filename){
    std::vector<std::string> header;

    //open db
    ifstream db;
    db.open("database/" + db_filename);
    if(!db.is_open()){
        std::cout << "Failed to open database/" << db_filename << "\n";
        return header;
    }
    else{
        std::string header_line;
        getline(db, header_line);

        header = format_row(header_line);
        return header;
    }
}

std::vector<std::string> schedule::find_appointment(int id){
    int ID_INDEX = 0;

    //get all rows
    std::vector<std::vector<std::string>> rows = get_db_rows("appointments.csv");

    std::vector<std::string> row;
    for(int i = 0; i < rows.size(); i++){
        if(stoi(rows.at(i).at(ID_INDEX)) == id){
            row = rows.at(i);
            break;
        }
    }
    return row;
}

int schedule::find_avg_appointments_completed_per_day(std::string start, std::string end, bool all){
    
}