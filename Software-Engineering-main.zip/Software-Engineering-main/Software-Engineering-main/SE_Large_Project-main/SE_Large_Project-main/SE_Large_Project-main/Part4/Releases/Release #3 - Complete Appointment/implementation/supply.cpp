//
//  supply.cpp
//
//
//  Created by Arthur Wolff on 3/22/21.
//  Expanded by Daniel Earley on 2021-04-10
// 
//

#include "../headers/Supply.h"

void update_supply(int change){
    
    int stark_count = 1 ,tusk_count = 1, main_count = 1, eliver_count = 1 ,geauga_count = 1, salem_count = 1, trum_count = 1, ash_count = 1;
    int university_count = stark_count+tusk_count+main_count;
    char vac_pick;
    int yn, repeat_yn;;

// shows supply levels
    cout << " Kent Main: " << main_count << endl;
    cout << " Stark: " << stark_count << endl;
    cout << " Tuscarawas: " << tusk_count << endl;
    cout << " East Liverpool: " << eliver_count << endl;
    cout << " Geauga: " << geauga_count << endl;
    cout << " Salem: " << salem_count << endl;
    cout << " Trumbull: " << trum_count << endl;
    cout << " Ashtabula: " << ash_count << endl;
    cout << " Total university supply: " << university_count << endl;
    cout << " does this supply count look correct?" << endl;
    cout << " if not press 0" << endl;
    cin >> yn;
    
// choose what suppy to edit
    if (yn == 0){
        cout << " which vaccice supply is incorrect?" << endl;
        cout << " press k for Stark" << endl;
        cout << " press t for Tuscarawas" << endl;
        cout << " press e for East Liverpool" << endl;
        cout << " press g for Geauga" << endl;
        cout << " press b for Trumbull" << endl;
        cout << " press s for Salem" << endl;
        cout << " press a for Ashtabula" << endl;
        cout << " press m for kent main" << endl;
        cin >> vac_pick;
   
// changes supply levels based on entry
        if (vac_pick == 'k'){
            cout << "what is the corret count?" << endl;
            cin >> stark_count;
        }
        if (vac_pick == 't'){
            cout << "what is the corret count?" << endl;
            cin >> tusk_count;
        }
        if (vac_pick == 'm'){
            cout << "what is the corret count?" << endl;
            cin >> main_count;
        }
        if (vac_pick == 'e'){
            cout << "what is the corret count?" << endl;
            cin >> eliver_count;
        }
        if (vac_pick == 'a'){
            cout << "what is the corret count?" << endl;
            cin >> ash_count;
        }
        if (vac_pick == 'b'){
            cout << "what is the corret count?" << endl;
            cin >> trum_count;
        }
        if (vac_pick == 's'){
            cout << "what is the corret count?" << endl;
            cin >> salem_count;
        }
        if (vac_pick == 'g'){
            cout << "what is the corret count?" << endl;
            cin >> geauga_count;
        }
        
        cout << " would you like to see the supply again? 1 for yes 0 for no" << endl;
        cin >> repeat_yn;
        
        if (repeat_yn == 1){
            cout << " Kent Main: " << main_count << endl;
            cout << " Stark: " << stark_count << endl;
            cout << " Tuscarawas: " << tusk_count << endl;
            cout << " East Liverpool: " << eliver_count << endl;
            cout << " Geauga: " << geauga_count << endl;
            cout << " Salem: " << salem_count << endl;
            cout << " Trumbull: " << trum_count << endl;
            cout << " Ashtabula: " << ash_count << endl;
            cout << " Total university supply: " << university_count << endl;
        }
    };
}

int Supply::get_vaccine_count()
{
	return count;
}
