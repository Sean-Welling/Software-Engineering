#include <iostream>

#include "../headers/campus.h"

int main(){
    //Create campus
    campus* c = new campus();

    //Get all past orders
    std::vector<Order*> orders = c->get_past_orders("05/15/2021", "05/20/2021", false);

    //print orders
    for(int i = 0; i < orders.size(); i++){
        std::cout << "Order\n";
        std::cout << "=================================\n";
        std::cout << "ID: " << orders.at(i)->get_id() << "\n";
        std::cout << "Date requested: " << orders.at(i)->get_date_requested() << "\n";
        std::cout << "Campus: " << orders.at(i)->get_requester_id() << "\n";
        std::cout << "Num doses requested: " << orders.at(i)->get_doses_needed() << "\n";
        std::cout << "Fulfilled: " << orders.at(i)->get_fulfilled() << "\n\n";
    }

    return 0;
}