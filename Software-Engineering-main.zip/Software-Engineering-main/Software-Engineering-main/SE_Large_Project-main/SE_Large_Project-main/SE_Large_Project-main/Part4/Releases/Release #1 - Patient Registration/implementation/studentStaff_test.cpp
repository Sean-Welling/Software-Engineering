#include "../headers/studentStaff.h"
#include "../headers/System.h"
#include "studentStaff.cpp"

int main()
{
    studentStaff *ss = new studentStaff();
    
    ss->get_user_info();

    std::cout << "Done!\n";

    return 0;
} 