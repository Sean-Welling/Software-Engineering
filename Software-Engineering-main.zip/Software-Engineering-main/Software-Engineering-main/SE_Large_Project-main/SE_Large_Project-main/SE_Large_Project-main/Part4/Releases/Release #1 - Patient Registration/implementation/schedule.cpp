//
//  schedule.cpp
//  schedule
//
//  Created by Arthur Wolff on 4/11/21.
//

#include <iostream>
using namespace std;
//#include "schedule.h"

#include <iostream>
#include <algorithm>
using namespace std;

int Mon[]={},Tue[]={},Wed[]={},Thur[]={},Fri[]={},Sat[]={},Sun[]={};
int mCount, tCount, wCount, rCount, fCount, sCount, uCount;
string choice;
int repeat = 1;
int correct = 0;
int ind;

int main() {
    
// Make appointment--------------------------
    
    while (repeat == 1){
        //times need to be entered in 24 hour time ex 2:00pm = 1400
    cout << "enter the day of the week you would like to shedulae an apppointment for -Mon- -Tue- -Wed- -Thur- -Fri- -Sat- -Sun-" <<endl;
    cin >> choice;
    
    //lets you input times for appoinments
    if (choice == "Mon") {
        cout << "enter a time you would like to schedule for" <<endl;
        cin >> Mon[mCount];
        mCount++;
    }
    if (choice == "Tue") {
        cout << "enter a time you would like to schedule for" <<endl;
        cin >> Tue[tCount];
        tCount++;
    }
    if (choice == "Wed") {
        cout << "enter a time you would like to schedule for" <<endl;
        cin >> Wed[wCount];
        wCount++;
    }
    if (choice == "Thur") {
        cout << "enter a time you would like to schedule for" <<endl;
        cin >> Thur[rCount];
        rCount++;
    }
    if (choice == "Fri") {
        cout << "enter a time you would like to schedule for" <<endl;
        cin >> Fri[fCount];
        fCount++;
    }
    if (choice == "Sat") {
        cout << "enter a time you would like to schedule for" <<endl;
        cin >> Sat[sCount];
        sCount++;
    }
    if (choice == "Sun") {
        cout << "enter a time you would like to schedule for" <<endl;
        cin >> Sun[uCount];
        uCount++;
    }
        
        cout << "would you like to enter another? enter 1 for yes or 0 for no " <<endl;
        cin >> repeat;
    
    }//end loop
    
//Display schedule-----------------------------------------
    
    //sots the times into cronological order
    sort(Mon, Mon+mCount);
    sort(Tue, Tue+tCount);
    sort(Wed, Wed+wCount);
    sort(Thur, Thur+rCount);
    sort(Fri, Fri+fCount);
    sort(Sat, Sat+sCount);
    sort(Sun, Sun+uCount);

    cout << "Mondays schedul is: "<<endl;

        for (int i = 0; i < mCount; ++i) {
            cout << Mon[i] << "  "<<endl;
        }
    
    cout << "Tuesdays schedul is: "<<endl;

        for (int i = 0; i < tCount; ++i) {
            cout << Tue[i] << "  "<<endl;
        }
    
    cout << "Wednesdays schedul is: "<<endl;

        for (int i = 0; i < wCount; ++i) {
            cout << Wed[i] << "  "<<endl;
        }
    
    cout << "Thursdays schedul is: "<<endl;

        for (int i = 0; i < rCount; ++i) {
            cout << Thur[i] << "  "<<endl;
        }
    
    cout << "Fridays schedul is: "<<endl;

        for (int i = 0; i < fCount; ++i) {
            cout << Fri[i] << "  "<<endl;
        }
    
    cout << "Saturadsys schedul is: "<<endl;

        for (int i = 0; i < sCount; ++i) {
            cout << Sat[i] << "  "<<endl;
        }
    
    cout << "Sundays schedul is: "<<endl;

        for (int i = 0; i < uCount; ++i) {
            cout << Sun[i] << "  "<<endl;
        }
    
// delete times -----------------------------------
    
    cout << "does everything look correct? 1 for yes 0 for no" <<endl;
    cin >> correct;
    
    while (correct == 0){
        
        cout << "which day is incorrect?" <<endl;
        cin >> choice;
        
        cout<<"Enter position to be deleted"<<endl;
        cin>>ind;
        ind--;
        
        // finds value to delte and removes it
        if (choice == "Mon") {
            for(int i = ind; i <= mCount-1; i++)
            {
                Mon[i]=Mon[i+1];
            }
            Mon[mCount-1]={};
            cout << "Mondays new schedul is: "<<endl;

                for (int i = 0; i < mCount; ++i) {
                    cout << Mon[i] << "  "<<endl;
                }
        }
        if (choice == "Tue") {
            for(int i = ind; i <= tCount-1; i++)
            {
                Tue[i]=Tue[i+1];
            }
            Tue[tCount-1]={};
            cout << "Mondays new schedul is: "<<endl;

                for (int i = 0; i < tCount; ++i) {
                    cout << Tue[i] << "  "<<endl;
                }
        }
        if (choice == "Wed") {
            for(int i = ind; i <= wCount-1; i++)
            {
                Wed[i]=Wed[i+1];
            }
            Wed[wCount-1]={};
            cout << "Mondays new schedul is: "<<endl;

                for (int i = 0; i < wCount; ++i) {
                    cout << Wed[i] << "  "<<endl;
                }
        }
        if (choice == "Thur") {
            for(int i = ind; i <= rCount-1; i++)
            {
                Thur[i]=Thur[i+1];
            }
            Thur[rCount-1]={};
            cout << "Mondays new schedul is: "<<endl;

                for (int i = 0; i < rCount; ++i) {
                    cout << Thur[i] << "  "<<endl;
                }
        }
        if (choice == "Fri") {
            for(int i = ind; i <= fCount-1; i++)
            {
                Fri[i]=Fri[i+1];
            }
            Fri[fCount-1]={};
            cout << "Mondays new schedul is: "<<endl;

                for (int i = 0; i < fCount; ++i) {
                    cout << Fri[i] << "  "<<endl;
                }
        }
        if (choice == "Sat") {
            for(int i = ind; i <= sCount-1; i++)
            {
                Sat[i]=Sat[i+1];
            }
            Sat[sCount-1]={};
            cout << "Mondays new schedul is: "<<endl;

                for (int i = 0; i < sCount; ++i) {
                    cout << Sat[i] << "  "<<endl;
                }
        }
        if (choice == "Sun") {
            for(int i = ind; i <= uCount-1; i++)
            {
                Sun[i]=Sun[i+1];
            }
            Sun[uCount-1]={};
            cout << "Mondays new schedul is: "<<endl;

                for (int i = 0; i < uCount; ++i) {
                    cout << Sun[i] << "  "<<endl;
                }
        }
        
        cout << "is everything correct now? 1 for yes 0 for no" <<endl;
        cin >> correct;
    }
};

