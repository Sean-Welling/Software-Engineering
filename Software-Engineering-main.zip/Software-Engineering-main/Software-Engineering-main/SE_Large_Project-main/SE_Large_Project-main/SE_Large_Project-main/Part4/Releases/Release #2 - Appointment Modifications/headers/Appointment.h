//
//  Appointment.h
//
//
//  Created by Arthur Wolff on 3/18/21.
//
//  Edited by Clay Casper on 4/6/2021

#ifndef Appointment_h
#define Appointment_h

//includes
#include "patient.h"
#include "campus.h"
#include "Display.h"
#include "schedule.h"

// ------ Relationships ------
// Low Demand: Association
// Payment: Association
// Campus: Association
// Patient: Association
// Schedule: Aggregation

#include <list>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <math.h>

using namespace std;

class Appointment
{
public:
    // bool lowDemand(int item) const;
    // bool payment(int item) const;
    // bool campus(int item) const;
    // //bool patient(int item) const;
    // bool schedule(int item) const;

    Appointment();

    Appointment(patient *p, std::string date, std::string time);

    //setters

    /**
     * Sets the reference to the appointment's patient
     * @param p The appointment's patient
     * @return Whether or not the patient was set successfully
     */
    bool set_patient(patient *p);

    /**
     * Sets the date of the appointment
     * @param date Appointment's date
     * @return Whether the appointment's date was set successfully or not
     */
    bool set_date(string date);

    /**
     * Sets the time of the appointment
     * @param time Appointment's time
     * @return Whether the appointment's time was set successfully or not
     */
    bool set_time(string time);

    bool set_id(int id);

    /**
     * Sets the reference to this appointment's campus
     * @param c Pointer to the campus object where this appointment takes place
     * @return Whether the appointment's campus was set properly or not
     */
    bool set_campus(campus *c);

    //getters

    /**
     * Returns this appointment's patient reference
     * @return The reference to this appointment's patient
     */
    patient *get_patient();

    /**
     * Returns this appointment's date
     * @return The date of this appointment
     */
    string get_date();

    /**
     * Returns this appointment's time
     * @return The time of this appointment
     */
    string get_time();

    /**
     * Returns a reference to this appointment's campus
     * @return Reference to this appointment's campus
     */
    campus *get_campus();

    /**
     * Returns this appointment's ID
     * @return This apointment's ID
     */
    int get_id();

    //other

    /**
     * Records this appointment's information to the database
     * @return Error code. 0 == No Error, 1 == Couldn't open log
     */
    int log_appointment();

    /**
     * Finds the first available appointment ID
     * @return The first available ID
     */
    int find_available_id();

    /**
     * Gets all records from the appointments log
     * @return List of rows from the log :: Row = [id, patient id, date, time, campus id]
     */
    std::vector<std::vector<std::string>> get_appointment_rows();

    /**
     * Creates a vector from a string representing one row in a csv database
     * @param s The string the makes up the row
     * @return Vector that indicates the columns in the row through its indeces
     */
    std::vector<std::string> get_row_vector(std::string s);

    /**
     * Computes the date that is x days after this appointment's date
     * @param days_between The days between the first appointment and the second appointment
     * @return The date (m/d/yyyy) as a string
     */
    std::string get_second_date(int days_between);

    /**
     * Changes this appointments date
     * @param new_date The new date the replace the old date
     * @return true: successfully changed the date | false: failed to change the date
     */
    bool change_date(std::string new_date);



    /**
     * Changes this appointment's time
     * @param new_date The new time that replaces the old time
     * @return true: successfully changed the time | false: failed to change the time
     * @author Daniel
     */
    bool change_time(std::string new_time);






    /**
     * Finds an appointment's record in the DB by its ID
     * @param id The appointment's ID
     * @return A vector representing that appointment's DB record
     */
    std::vector<std::string> find_record_by_id(int id);

    /**
     * Finds the record number given the appointment's ID
     * @param id The appointment's ID
     * @return The record number (0 based) of the appointment
     */
    int get_record_number(int id);

    /**
     * Set this appointment's attributes using its ID and existing information
     * @return true: success | false: failed
     * @author Clay
     */
    bool init_from_existing();

    /**
     * Finds this appointment's record in the DB
     * @return Vector representing this appointments record in DB
     * @author Clay
     */
    std::vector<std::string> find_record();

    /**
     * Prints this appointment's details to standard out
     * @author Clay
     */
    void display_details();

    /**
     * Used to modify this appointment
     * @return true: success | false: failed
     */
    bool modify();

private:
    //list<int> items;
    int id;
    patient *p;
    campus *c;
    /* Format : m/dd/yyyy */
    string date;
    string time;
};

#endif /* Appointment_h */
