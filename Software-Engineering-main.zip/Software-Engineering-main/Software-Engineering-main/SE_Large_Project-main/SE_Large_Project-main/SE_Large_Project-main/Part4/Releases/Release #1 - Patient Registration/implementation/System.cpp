#include "../headers/System.h"

bool register_patient()
{
    int error_code = 0;

    //create patient
    patient *pt = new patient();

    //find available appointment times and locations (Schedule)

    //choose appointment time/date and location
    std::string date = "04/14/2021";
    std::string time = "15:00";
   

    //Creates a campus object for each location. Just sets campus location name
    campus* selected_campus[8]{};
    for (int i = 0; i < 8; i++)
    {
        selected_campus[i]->set_location(i);
    }
 
    //Choice of campus location for the appointment (3 for Kent)
    int campus_index = 3;



    //create appointment
    Appointment *apmt = new Appointment();

    //set id
    apmt->set_id(apmt->find_available_id());

    //set appointment patient
    if(apmt->set_patient(pt)){
        //set date
        if(apmt->set_date(date)){
            //set time
            if(apmt->set_time(time)){
                //set appointment campus
                if(apmt->set_campus(selected_campus[campus_index]))
                    if(!apmt->log_appointment()){
                        error_code = 5;
                    }
            }
            else{
                error_code = 3;
            }
        }
        else{
            error_code = 2;
        }
    }
    else{
        error_code = 1;
    }

    if (error_code == 0)
    {
        print_padded("Patient successfully registered for" + apmt->get_date() + " at " + apmt->get_time() + " at the Campus " + "temp" + "\n");
        return true;
    }
    else
    {
        print_padded("ERROR: Couldn't register patient.\n");
        return false;
    }
}