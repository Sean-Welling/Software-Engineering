//
//  appointment.cpp
//
//
//  Created by Arthur Wolff on 3/22/21.
//

#include "../headers/Appointment.h"

/*
 
 Implementation of Appointment.h

 */

const int CURR_YEAR = 2021;

std::string month_names[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

int month_days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

Appointment::Appointment()
{

    //set leap year days
    if (CURR_YEAR % 4 == 0)
    {
        if (CURR_YEAR % 100 == 0)
        {
            if (CURR_YEAR % 400 == 0)
            {
                //leap year
                month_days[1] = 29;
            }
        }
        else
        {
            //leap year
            month_days[1] = 29;
        }
    }
}

Appointment::Appointment(patient *p, std::string date, std::string time)
{
    //set patient, date, and time
    this->set_patient(p);
    this->set_date(date);
    this->set_time(time);

    //set leap year days
    if (CURR_YEAR % 4 == 0)
    {
        if (CURR_YEAR % 100 == 0)
        {
            if (CURR_YEAR % 400 == 0)
            {
                //leap year
                month_days[1] = 29;
            }
        }
        else
        {
            //leap year
            month_days[1] = 29;
        }
    }
}

bool Appointment::set_patient(patient *p)
{
    this->p = p;

    if (this->p == p)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_date(std::string date)
{
    this->date = date;

    if (this->date == date)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_time(std::string time)
{
    this->time = time;

    if (this->time == time)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_id(int id)
{
    this->id = id;

    if (this->id == id)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_campus(campus *c)
{
    this->c = c;

    if (this->c == c)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

//getters

patient *Appointment::get_patient()
{
    return this->p;
}

std::string Appointment::get_date()
{
    return this->date;
}

std::string Appointment::get_time()
{
    return this->time;
}

int Appointment::get_id()
{
    return this->id;
}

campus *Appointment::get_campus()
{
    return this->c;
}

int Appointment::log_appointment()
{
    //open appointment log file
    std::string filename = "database/appointments.csv";

    //create file stream
    std::ofstream log;

    //open the file
    log.open(filename, std::ios::app);

    if (!log)
    {
        return 0;
    }

    //write to file
    log << this->id << "," << this->p->id << "," << this->date << "," << this->time << ","
        << "campus_id"
        << "\n";

    //close file
    log.close();

    return 1;
}

int Appointment::find_available_id()
{
    const int ID_INDEX = 0;

    int id = 1;
    //get all ids
    std::vector<std::vector<std::string>> rows = get_appointment_rows();

    //check rows for matching id
    bool available = true;

    do
    {
        //check for match
        
        for (int i = 0; i < rows.size(); i++){
            std::vector<std::string> curr_row = rows.at(i);
            //check id
            std::string curr_row_id = curr_row.at(ID_INDEX);

            int curr_id_int_v = std::stoi(curr_row_id);
            if (curr_id_int_v == id)
            {
                available = false;
                break;
            }
            else
            {
                available = true;
            }
        }

        //if match increment
        if (!available)
        {
            id++;
        }
    } while (available == false);

    return id;
}

std::vector<std::vector<std::string>> Appointment::get_appointment_rows()
{

    //create stream
    std::ifstream log;

    //open file
    log.open("database/appointments.csv");

    int row_num = 0;
    int col_num = 0;
    std::string curr_line = "";
    char curr_char;

    std::vector<std::string> lines;

    while (log.get(curr_char))
    {
        if (curr_char == '\n')
        {
            if (row_num != 0)
            {
                lines.push_back(curr_line);
            }
            curr_line = "";

            row_num++;
        }
        else
        {
            curr_line += curr_char;
        }
    }

    std::vector<std::vector<std::string>> rows;

    //create row vectors
    for (int i = 0; i < lines.size(); i++)
    {
        //read line
        rows.push_back(get_row_vector(lines.at(i)));
    }

    //close file
    log.close();

    return rows;
}

std::vector<std::string> Appointment::get_row_vector(std::string s)
{
    std::vector<std::string> row;

    std::string curr_word = "";

    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == ',')
        {
            //add col to row
            row.push_back(curr_word);
            //clear word
            curr_word = "";
        }
        else
        {
            curr_word += s[i];
        }
    }

    row.push_back(curr_word);

    return row;
}

std::string Appointment::get_second_date(int days_between)
{
    int first_date_month;
    int first_date_day;
    int first_date_year;

    int second_date_month;
    int second_date_day;
    int second_date_year;

    //parse first appointment date
    int index = 0;
    std::string curr_word = "";
    for (int i = 0; i < this->date.length(); i++)
    {
        if (this->date[i] == '/')
        {
            switch (index)
            {
            case 0:
                first_date_month = stoi(curr_word);
                break;
            case 1:
                first_date_day = stoi(curr_word);
                break;
            }
            curr_word = "";
            index++;
        }
        else
        {
            curr_word += this->date[i];
        }
    }

    first_date_year = stoi(curr_word);

    //add days
    int curr_month_index = first_date_month - 1;
    second_date_year = first_date_year;
    second_date_month = first_date_month;
    second_date_day = first_date_day;

    //add days between to first day
    second_date_day += days_between;

    //check if second day is greater than last months days
    while (second_date_day > month_days[curr_month_index])
    {
        //set second day % last month days

        second_date_day = second_date_day - month_days[curr_month_index];

        //increment the month
        if (curr_month_index == 11)
        {
            second_date_month = 1;
            curr_month_index = 0;
            second_date_year++;
        }
        else
        {
            second_date_month++;
            curr_month_index++;
        }
    }

    std::string second_date = to_string(second_date_month) + '/' + to_string(second_date_day) + '/' + to_string(second_date_year);

    return second_date;
}