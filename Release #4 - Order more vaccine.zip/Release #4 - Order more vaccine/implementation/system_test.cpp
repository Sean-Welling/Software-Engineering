#include <iostream>

#include "../headers/System.h"

int main(){
    std::cout << "Testing system test...\n";

    //process orders : Clay
    process_orders();

    //process shipments : Arthur - couldn't find

    //init campus schedules : Sean
    // std::vector<schedule> campus_schedules = init_campus_schedules();
    // std::cout << "Num schedules = " << campus_schedules.size() << " schedules\n";

    return 0;
}