#include <iostream>

#include "../headers/Supply.h"

int main()
{
    Supply s = Supply();
    s.set_id(1);
    //init supply : Clay
    std::cout << s.init() << "\n";

    std::cout << "ID: " << s.get_id() << "\n";
    std::cout << "Doses: " << s.get_vaccine_count() << "\n";

    s.set_vaccine_count(75);

    //update supply : Arthur - couldn't find

    //update log : Dan
    std::cout << "Updating supply : " << s.update_log();

    std::cout << "Done!\n";

    return 0;
}