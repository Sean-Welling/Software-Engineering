#include <iostream>

#include "../headers/schedule.h"
//#include "schedule.cpp"

const int CURR_YEAR = 2021;

//std::string month_names[] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

int month_days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

std::string campus_names[] = {"Ashtabula", "East Liverpool", "Geauga", "Kent", "Salem", "Stark", "Trumbull", "Tuscarawas"};

//constant data related to dates and time
const std::string month_names[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

const int month_days_non_leap[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

const int month_days_leap[12] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

void campus::set_location(int campus_index)
{
   
    location = campus_names[campus_index];
}

bool Appointment::set_id(int id)
{
    this->id = id;

    if (this->id == id)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

std::vector<std::string> format_row(std::string s)
{
    std::vector<std::string> row;

    std::string curr_word = "";

    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == ',')
        {
            //add col to row
            row.push_back(curr_word);
            //clear word
            curr_word = "";
        }
        else
        {
            curr_word += s[i];
        }
    }

    row.push_back(curr_word);

    return row;
}

std::string Appointment::get_date()
{
    return this->date;
}

int schedule::find_avg_appointments_completed_per_day(std::string start, std::string end, bool all)
{
    //check all flag
    int num_appointments = 0;

    Date start_date = Date(start);
    Date end_date = Date(end);

    if (all)
    {
        num_appointments = this->appointments.size();
    }
    else
    {
        //go through each appointment in this schedule and check date
        for (int i = 0; i < this->appointments.size(); i++)
        {
            Date *temp_date = new Date(this->appointments.at(i)->get_date());
            //check if in range
            int start_check = compare_dates(temp_date, &start_date);
            int end_check = compare_dates(temp_date, &end_date);

            if ((start_check == 0 || start_check == 1) && (end_check == 0 || end_check == -1))
            {
                //add to local appointments
                num_appointments++;

                this->appointments.at(i)->display_details();
            }

            //clear memory
            delete temp_date;
        }
    }

    //get num days : Not accurate right now, doesn't account for different num days in different months and leap years
    int diff_days = 0;
    Date diff = end_date - start_date;
    diff_days += diff.get_day();
    diff_days += diff.get_month() * 30;
    diff_days += diff.get_year() * 360;

    return num_appointments / (diff_days + 1);
}

bool Appointment::init_from_existing()
{
    //make sure id is set
    if (this->id == -1)
    {
        return false;
    }
    else
    {
        //get record
        std::vector<std::string> appointment_record = this->find_record();

        //get patient
        //create new patient
        patient *apmt_patient = new patient();
        //use appointment record to set patient id
        apmt_patient->id = appointment_record[1];
        //find the patient's record
        std::vector<std::string> patient_record = apmt_patient->find_patient_record();
        //set apmt patient
        //init patient
        apmt_patient->init_from_existing();
        if (!this->set_patient(apmt_patient))
        {
            return false;
        }

        //set date
        if (!this->set_date(appointment_record.at(2)))
        {
            return false;
        }

        //set time
        if (!this->set_time(appointment_record.at(3)))
        {
            return false;
        }

        //get campus
        //create new campus
        campus *apmt_campus = new campus();
        //set location of campus
        apmt_campus->set_location(stoi(appointment_record.at(4)));

        //set appointment campus
        if (!this->set_campus(apmt_campus))
        {
            return false;
        }

        return true;
    }
}

std::vector<std::string> Appointment::find_record()
{
    int ID_INDEX = 0;
    //open the patient DB
    ifstream db;
    db.open("../database/appointments.csv");

    std::string curr_line;
    std::vector<std::string> curr_record;

    if (!db.is_open())
    {
        std::cout << "Couldn't open file\n";
        return curr_record;
    }

    int line_num = 0;
    while (getline(db, curr_line))
    {
        if (line_num != 0)
        {
            curr_record = this->get_row_vector(curr_line);

            if (stoi(curr_record.at(ID_INDEX)) == this->id)
            {
                db.close();
                return curr_record;
            }
        }
        line_num++;
    }
    db.close();
    return curr_record;
}

std::vector<std::string> patient::find_patient_record()
{
    int ID_INDEX = 0;
    //open the patient DB
    ifstream db;
    db.open("../database/patient.csv");

    std::string curr_line;
    std::vector<std::string> curr_record;

    if (!db.is_open())
    {
        std::cout << "Couldn't open file\n";
        return curr_record;
    }

    int line_num = 0;
    while (getline(db, curr_line))
    {
        if (line_num != 0)
        {
            curr_record = format_patient_record(curr_line);

            if (curr_record.at(ID_INDEX) == this->id)
            {
                db.close();
                return curr_record;
            }
        }
        line_num++;
    }
    db.close();
    return curr_record;
}

bool patient::init_from_existing()
{
    //make sure id is set
    if (this->id == "not set")
    {
        return false;
    }
    else
    {
        //get record
        std::vector<std::string> record = this->find_patient_record();

        //set id
        this->id = record.at(0);

        //set username
        this->username = record.at(1);

        //set firstname
        this->firstname = record.at(2);

        //set lastname
        this->lastname = record.at(3);

        //set role
        this->role = record.at(4);

        //set address
        this->address = record.at(5);

        //set phone
        this->phone = record.at(6);

        //set age
        this->age = record.at(7);

        //set patient id num
        this->patient_id_num = record.at(8);

        return true;
    }
}

//Other
bool Database::init()
{
    //check if filename is set
    if (this->filename != "")
    {
        std::vector<std::string> header_row = this->get_database_header();

        this->num_cols = header_row.size();
        this->header = header_row;

        //get row strings
        std::vector<std::string> lines = this->get_db_row_strings();
        std::vector<std::vector<std::string>> all_rows;

        if (!lines.empty())
        {
            //format each line
            for (int i = 0; i < lines.size(); i++)
            {
                all_rows.push_back(format_row(lines.at(i)));
            }

            this->num_rows = all_rows.size();
        }
        else
        {
            this->num_rows = 0;
        }
        this->rows = all_rows;
        this->initialized = true;
    }
    else
    {
        //filename not set
        return false;
    }
    return false;
}

int Database::get_col_max_width(int col)
{
    //check if initialized
    int max = -1;
    if (this->initialized)
    {
        //check header
        int header_col_length = this->header.at(col).length();
        if (header_col_length > max)
        {
            max = header_col_length;
        }

        for (int i = 0; i < this->num_rows; i++)
        {
            int curr_row_col_length = this->rows.at(i).at(col).length();
            if (curr_row_col_length > max)
            {
                max = curr_row_col_length;
            }
        }
    }
    return max;
}

bool schedule::set_appointments(std::vector<Appointment *> appointments)
{
    this->appointments = appointments;
    if (this->appointments == appointments)
    {
        return true;
    }
    else
    {
        return false;
    }
}

std::vector<std::string> Database::get_database_header()
{
    std::vector<std::string> header;

    //Check filename is set
    if (this->filename != "")
    {
        //open db
        std::ifstream db;
        db.open("../database/" + this->filename);
        if (!db.is_open())
        {
            std::cout << "Failed to open database/" << this->filename << "\n";
            return header;
        }
        else
        {
            std::string header_line;
            getline(db, header_line);

            header = format_row(header_line);
            return header;
        }
    }
    else
    {
        std::cout << "ERROR: Couldn't get database header because filename isn't set\n\n";
        return header;
    }
}

Database::Database(std::string filename)
{
    this->filename = filename;

    //initialize database values
    this->init();
}

Date::Date()
{
}
Date::Date(int month, int day, int year)
{
    if (this->set_month(month))
    {
        if (this->set_day(day))
        {
            if (!this->set_year(year))
            {
                std::cout << "Couldn't set this date's year\n";
            }
        }
        else
        {
            std::cout << "Couldn't set this date's day\n";
        }
    }
    else
    {
        std::cout << "Couldn't set this date's month\n";
    }
}
Date::Date(std::string month, std::string day, std::string year)
{
    if (this->set_month(stoi(month)))
    {
        if (this->set_day(stoi(day)))
        {
            if (!this->set_year(stoi(year)))
            {
                std::cout << "Couldn't set this date's year\n";
            }
        }
        else
        {
            std::cout << "Couldn't set this date's day\n";
        }
    }
    else
    {
        std::cout << "Couldn't set this date's month\n";
    }
}
Date::Date(std::string full_date)
{
    this->init_from_date_string(full_date);
}

//Setters
bool Date::set_month(int month)
{
    this->month = month;
    if (this->month == month)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool Date::set_day(int day)
{
    this->day = day;
    if (this->day == day)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool Date::set_year(int year)
{
    this->year = year;
    if (this->year == year)
    {
        return true;
    }
    else
    {
        return false;
    }
}

//Getters
int Date::get_month()
{
    return this->month;
}
int Date::get_day()
{
    return this->day;
}
int Date::get_year()
{
    return this->year;
}

//Other

std::string *Date::parse_date_string(std::string date, std::string format)
{
    if (format != "mm/dd/yyyy" && format != "mm-dd-yyyy")
    {
        return NULL;
    }
    else
    {
        //https://stackoverflow.com/questions/7527356/return-string-array-in-c-function
        std::string *parsed_date = new std::string[3];

        if (format == "mm/dd/yyyy")
        {
            std::vector<std::string> parsed = this->split_string(date, '/');

            parsed_date[0] = parsed.at(0);
            parsed_date[1] = parsed.at(1);
            parsed_date[2] = parsed.at(2);
        }
        else if (format == "mm-dd-yyyy")
        {
            std::vector<std::string> parsed = this->split_string(date, '-');

            parsed_date[0] = parsed.at(0);
            parsed_date[1] = parsed.at(1);
            parsed_date[2] = parsed.at(2);
        }
        return parsed_date;
    }
}

std::vector<std::string> Date::split_string(std::string base, char delim)
{
    std::vector<std::string> split_strings;

    //go through each character and check for the delim
    std::string current_word = "";
    for (int i = 0; i < base.length(); i++)
    {
        //check for delim
        if (base[i] == delim)
        {
            //add current_string to array
            split_strings.push_back(current_word);

            //reset the current string
            current_word = "";
        }
        else
        {
            //add current char to current string
            current_word += base[i];
        }
    }

    //add last word
    split_strings.push_back(current_word);

    return split_strings;
}

void Date::print_date(std::string format)
{
    std::string acceptable_formats[] = {"mm/dd/yyyy", "mm/dd/yy", "mm-dd-yyyy", "mm-dd-yy"};
    //check format
    bool good_format = false;
    for (int i = 0; i < sizeof(acceptable_formats) / sizeof(acceptable_formats[0]); i++)
    {
        if (format == acceptable_formats[i])
        {
            good_format = true;
        }
    }

    if (good_format)
    {
        //get delimeter
        char delim = this->get_delim(format);

        std::vector<std::string> split_format = this->split_string(format, delim);

        //print
        int month_iteration = 0;
        int day_iteration = 0;
        int year_iteration = 0;
        if (split_format.at(2) == "yy")
        {
            year_iteration = 2;
        }

        std::string month_string = this->format_element_string(this->month);
        std::string day_string = this->format_element_string(this->day);
        std::string year_string = std::to_string(this->year);

        for (int i = 0; i < format.length(); i++)
        {
            switch (format[i])
            {
            case 'm':
            {
                std::cout << month_string[month_iteration];
                month_iteration++;
                break;
            }
            case 'd':
            {
                std::cout << day_string[day_iteration];
                day_iteration++;
                break;
            }
            case 'y':
            {
                std::cout << year_string[year_iteration];
                year_iteration++;
                break;
            }
            default:
            {
                std::cout << format[i];
                break;
            }
            }
        }
    }
    else
    {
        std::cout << "Can't print date: Incorrect format\n";
    }
}

std::string Date::get_formatted(std::string format)
{
    std::string final_string = "";

    std::string acceptable_formats[] = {"mm/dd/yyyy", "mm/dd/yy", "mm-dd-yyyy", "mm-dd-yy"};
    //check format
    bool good_format = false;
    for (int i = 0; i < sizeof(acceptable_formats) / sizeof(acceptable_formats[0]); i++)
    {
        if (format == acceptable_formats[i])
        {
            good_format = true;
        }
    }

    if (good_format)
    {
        //get delimeter
        char delim = this->get_delim(format);

        std::vector<std::string> split_format = this->split_string(format, delim);

        //print
        int month_iteration = 0;
        int day_iteration = 0;
        int year_iteration = 0;
        if (split_format.at(2) == "yy")
        {
            year_iteration = 2;
        }

        std::string month_string = this->format_element_string(this->month);
        std::string day_string = this->format_element_string(this->day);
        std::string year_string = std::to_string(this->year);

        for (int i = 0; i < format.length(); i++)
        {
            switch (format[i])
            {
            case 'm':
            {
                final_string += month_string[month_iteration];
                month_iteration++;
                break;
            }
            case 'd':
            {
                final_string += day_string[day_iteration];
                day_iteration++;
                break;
            }
            case 'y':
            {
                final_string += year_string[year_iteration];
                year_iteration++;
                break;
            }
            default:
            {
                final_string += format[i];
                break;
            }
            }
        }
    }
    else
    {
        std::cout << "Can't print date: Incorrect format\n";
    }

    return final_string;
}

char Date::get_delim(std::string date)
{
    for (int i = 0; i < date.length(); i++)
    {
        if (date[i] != 'm' && date[i] != 'd' && date[i] != 'y')
        {
            return date[i];
        }
    }
    return 'm';
}

std::string Date::format_element_string(int element)
{
    std::string formatted = "";

    if (element < 10)
    {
        formatted += '0';
        formatted += std::to_string(element);
    }
    else
    {
        formatted = std::to_string(element);
    }

    return formatted;
}

int compare_dates(Date *date1, Date *date2)
{
    //check year
    if (date1->get_year() < date2->get_year())
    {
        return -1;
    }
    else if (date1->get_year() > date2->get_year())
    {
        return 1;
    }
    else
    {
        //check month
        if (date1->get_month() < date2->get_month())
        {
            return -1;
        }
        else if (date1->get_month() > date2->get_month())
        {
            return 1;
        }
        else
        {
            //check day
            if (date1->get_day() < date2->get_day())
            {
                return -1;
            }
            else if (date1->get_day() > date2->get_day())
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
}

Date operator-(Date d1, Date d2)
{
    Date difference = Date();

    //get the later date
    Date later_date;
    Date earlier_date;
    if (compare_dates(&d1, &d2) == -1)
    {
        //d1 is earlier than d2
        later_date = d2;
        earlier_date = d1;
    }
    else
    {
        later_date = d1;
        earlier_date = d2;
    }

    //subtract
    int year_diff = later_date.get_year() - earlier_date.get_year();
    int month_diff = later_date.get_month() - earlier_date.get_month();
    int day_diff = later_date.get_day() - earlier_date.get_day();

    //set members
    difference.set_month(month_diff);
    difference.set_day(day_diff);
    difference.set_year(year_diff);

    return difference;
}

int Date::is_leap_year()
{
    //check if year is set
    if (this->year != 0)
    {
        if (this->year % 4 == 0)
        {
            if (this->year % 100 == 0)
            {
                if (this->year % 400 == 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return 1;
            }
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return -1;
    }
}

const std::string get_curr_date()
{
    time_t now = time(0);
    struct tm tstruct;
    char curr_date[80];
    tstruct = *localtime(&now);
    strftime(curr_date, sizeof(curr_date), "%m/%d/%Y", &tstruct);

    return curr_date;
}

bool Date::init_from_date_string(std::string date_string)
{
    //check format
    if (date_string[2] == '/' && date_string[5] == '/')
    {
        //Parse string for month, day, and year
        std::string *members = this->parse_date_string(date_string, "mm/dd/yyyy");

        //initialize members
        if (this->set_month(stoi(*members)))
        {
            if (this->set_day(stoi(*(members + 1))))
            {
                if (this->set_year(stoi(*(members + 2))))
                {
                    return true;
                }
                else
                {
                    std::cerr << "Couldn't set this date's year\n";
                    return false;
                }
            }
            else
            {
                std::cerr << "Couldn't set this date's day\n";
                return false;
            }
        }
        else
        {
            std::cerr << "Couldn't set this date's month\n";
            return false;
        }
    }
    else
    {
        std::cerr << "Couldn't initialize the new date's members because the input string had an incorrect format.\n";
        return false;
    }
}

Date operator+(Date &d1, int change)
{
    Date final_date = d1;
    /*
        Algorithm

        1. while the total days to add is greater than the days left in current month -> increment month and set days to 0
        2. set days as what's left in total days to add
    */
    int total_days_to_add = change;
    bool go_again;

    do
    {

        go_again = false;
        //calculate days left in curr_month
        int days_left_in_month;
        if (final_date.is_leap_year())
        {
            days_left_in_month = month_days_leap[final_date.get_month() - 1] - final_date.get_day();
        }
        else
        {
            days_left_in_month = month_days_non_leap[final_date.get_month() - 1] - final_date.get_day();
        }

        if (total_days_to_add - days_left_in_month > 0)
        {
            //indicate loop
            go_again = true;

            //increment month -> check if need to increment year
            if (final_date.get_month() == 12)
            {
                final_date.set_month(1);
                //increment year
                final_date.set_year(final_date.get_year() + 1);
            }
            else
            {
                final_date.set_month(final_date.get_month() + 1);
            }

            //set days to 1
            final_date.set_day(1);

            //remove days left in curr month from total days to remove -> need to account for extra day when incrementing month
            total_days_to_add -= (days_left_in_month + 1);
        }
        else
        {
            //add the days to curr day value
            final_date.set_day(final_date.get_day() + total_days_to_add);
        }

    } while (go_again);

    return final_date;
}

Date operator-(Date &d1, int change)
{
    Date final_date = d1;
    /*
        Algorithm

        1. subtract the change from the current day ->
            if(-) : decrement month / decrease change / set days to previous month's total days
            else : set days to curr day - change
    */
    int total_days_to_subtract = change;
    bool go_again;

    do
    {
        go_again = true;

        //check if change overflows month days
        int overflow;
        overflow = final_date.get_day() - change;

        if (overflow < 1)
        {
            //change month
            if (final_date.get_month() == 1)
            {
                final_date.set_month(12);
                //change year
                final_date.set_year(final_date.get_year() - 1);
            }
            else
            {
                final_date.set_month(final_date.get_month() - 1);
            }

            //decrease change
            change -= final_date.get_day();

            //set the new day value
            if (final_date.is_leap_year())
            {
                final_date.set_day(month_days_leap[final_date.get_month() - 1]);
            }
            else
            {
                final_date.set_day(month_days_non_leap[final_date.get_month() - 1]);
            }
        }
        else
        {
            //change the day value
            final_date.set_day(overflow);

            //set flag
            go_again = false;
        }

    } while (go_again);

    return final_date;
}

std::vector<Appointment *> schedule::get_past_apmts()
{
    Database db = Database("appointments.csv");

    std::vector<std::vector<std::string>> db_rows = db.get_rows();

    std::vector<Appointment *> past_apmts;

    Date *curr_date = new Date(get_curr_date());

    for (std::vector<std::string> row : db_rows)
    {
        //check the date
        Date *temp_date = new Date(row.at(2));
        //cmp dates
        if (compare_dates(temp_date, curr_date) == -1)
        {
            //create apmt obj
            Appointment *temp_apmt = new Appointment();
            //set members
            temp_apmt->set_id(stoi(row.at(0)));
            temp_apmt->init_from_existing();
            //past apmt
            past_apmts.push_back(temp_apmt);
        }
    }

    return past_apmts;
}

string campus::get_location()
{
    return location;
}

void Appointment::display_details()
{
    std::cout << "Appointment Details\n";
    std::cout << "=============================\n\n";

    std::cout << "ID : " + to_string(this->id) + "\n";
    std::cout << "Campus : " + this->c->get_location() + "\n";
    std::cout << "Date : " + this->date + "\n";
    std::cout << "Time : " + this->ap_time + "\n";
    std::cout << "Patient : " + this->p->firstname + " " + this->p->lastname + "\n\n";
}

std::vector<std::string> patient::format_patient_record(std::string line)
{
    std::vector<std::string> record;

    std::string curr_column = "";
    char curr_char;
    for (int i = 0; i < line.length(); i++)
    {
        curr_char = line[i];
        if (curr_char == ',')
        {
            record.push_back(curr_column);
            curr_column = "";
        }
        else
        {
            curr_column += curr_char;
        }
    }
    record.push_back(curr_column);

    return record;
}

std::vector<std::string> Appointment::get_row_vector(std::string s)
{
    std::vector<std::string> row;

    std::string curr_word = "";

    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == ',')
        {
            //add col to row
            row.push_back(curr_word);
            //clear word
            curr_word = "";
        }
        else
        {
            curr_word += s[i];
        }
    }

    row.push_back(curr_word);

    return row;
}

bool Appointment::set_campus(campus *c)
{
    this->c = c;

    if (this->c == c)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_patient(patient *p)
{
    this->p = p;

    if (this->p == p)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_time(std::string time)
{
    this->ap_time = time;

    if (this->ap_time == time)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

bool Appointment::set_date(std::string date)
{
    this->date = date;

    if (this->date == date)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

patient::patient()
{
    // std::cout << "Creating patient object...\n";
    //std::vector<std::string> patient_record;
    //patient_record = get_user_info();
    //string id, username, firstname, lastname, role, address, phone, age = patient::get_studentStaff();
    this->id = "not set";
}

std::vector<Appointment *> find_appointments_by_campus(campus *c, bool completed)
{
    int CAMPUS_ID_INDEX = 4;
    std::vector<Appointment *> all_appointments;

    //open appointment db
    Database *db = new Database();

    if (completed)
    {
        db->set_filename("complete_appointments.csv");
    }
    else
    {
        db->set_filename("appointments.csv");
    }

    //get rows
    std::vector<std::vector<std::string>> db_rows = db->get_rows();
    db->print_database();

    for (int i = 0; i < db->get_num_rows(); i++)
    {
        std::vector<std::string> curr_row = db_rows.at(i);
        if (stoi(curr_row.at(CAMPUS_ID_INDEX)) == c->get_location_id())
        {
            //create appointment
            Appointment *temp_apmt = new Appointment();

            //set apmt members
            temp_apmt->set_id(stoi(curr_row.at(0)));
            temp_apmt->init_from_existing();

            //create patient
            patient *p = new patient();
            p->id = curr_row.at(1);
            p->init_from_existing();

            temp_apmt->set_patient(p);

            temp_apmt->display_details();

            all_appointments.push_back(temp_apmt);
        }
    }

    //clear memory
    delete db;

    return all_appointments;
}

Database::Database()
{
    this->filename = "";
    this->initialized = false;
}
int Database::get_num_rows()
{
    return this->num_rows;
}

std::vector<std::string> Database::get_db_row_strings()
{
    std::vector<std::string> lines;

    //Check if filename is set
    if (this->filename != "")
    {
        //create stream
        std::ifstream log;

        //open file
        log.open("../database/" + this->filename);

        if (!log.is_open())
        {
            std::cout << "Failed to open " + this->filename << "\n";
            return lines;
        }

        int row_num = 0;
        int col_num = 0;
        std::string curr_line = "";
        char curr_char;

        while (log.get(curr_char))
        {
            if (curr_char == '\n')
            {
                if (row_num != 0)
                {
                    lines.push_back(curr_line);
                }
                curr_line = "";

                row_num++;
            }
            else
            {
                curr_line += curr_char;
            }
        }

        //close file
        log.close();
    }
    else
    {
        std::cout << "Filename not set\n";
        return lines;
    }

    return lines;
}

//Setters
bool Database::set_filename(std::string filename)
{
    this->filename = filename;
    if (this->filename == filename)
    {
        //initialize
        this->init();
        return true;
    }
    else
    {
        return false;
    }
}

void Database::print_database()
{
    //reload data into obj
    this->init();

    char horizontal_divider = '=';
    int left_padding = 5;

    //check the database has been initialized
    if (this->initialized)
    {
        //get max col widths
        std::vector<int> max_widths;
        int total_width = 0;
        for (int i = 0; i < this->num_cols; i++)
        {
            max_widths.push_back(this->get_col_max_width(i));
            total_width += this->get_col_max_width(i);
        }
        //add dividers to total width
        total_width += (this->num_cols - 1) * 3;

        //print header

        //print padding
        for (int i = 0; i < left_padding; i++)
        {
            std::cout << ' ';
        }
        int extra_space;
        for (int i = 0; i < this->num_cols; i++)
        {
            //print content
            std::cout << this->header.at(i);

            //calculate extra spaces
            extra_space = max_widths.at(i) - this->header.at(i).length();

            //print extra space
            for (int j = 0; j < extra_space; j++)
            {
                std::cout << ' ';
            }
            //print vertical divider
            if (i != num_cols - 1)
            {
                std::cout << " | ";
            }
        }
        std::cout << "\n";

        //print horizontal divider
        for (int i = 0; i < left_padding; i++)
        {
            std::cout << ' ';
        }
        for (int i = 0; i < total_width; i++)
        {
            std::cout << horizontal_divider;
        }
        std::cout << "\n";

        //print each row
        for (int i = 0; i < this->num_rows; i++)
        {
            //print padding
            for (int i = 0; i < left_padding; i++)
            {
                std::cout << ' ';
            }
            //loop through each col
            for (int j = 0; j < this->num_cols; j++)
            {
                //print content
                std::cout << this->rows.at(i).at(j);

                //calculate extra spaces
                extra_space = max_widths.at(j) - this->rows.at(i).at(j).length();

                //print extra space
                for (int e = 0; e < extra_space; e++)
                {
                    std::cout << ' ';
                }
                //print vertical divider
                if (j != num_cols - 1)
                {
                    std::cout << " | ";
                }
            }
            std::cout << "\n";
        }
    }
}

Appointment::Appointment()
{

    //set leap year days
    if (CURR_YEAR % 4 == 0)
    {
        if (CURR_YEAR % 100 == 0)
        {
            if (CURR_YEAR % 400 == 0)
            {
                //leap year
                month_days[1] = 29;
            }
        }
        else
        {
            //leap year
            month_days[1] = 29;
        }
    }

    this->id = -1;
}

int campus::get_location_id()
{
    for (int i = 0; i < sizeof(campus_names) / sizeof(campus_names[0]); i++)
    {
        if (campus_names[i] == this->location)
        {
            return i;
        }
    }
    return -1;
}

std::vector<std::vector<std::string>> Database::get_rows()
{
    return this->rows;
}

int main()
{
    campus *c = new campus();
    c->set_location(0);

    schedule s = schedule();
    s.set_appointments(find_appointments_by_campus(c, true));

    //get past apmts : Arthur
    std::cout << "Past appointments in this schedule : " << s.get_past_apmts().size() << " apmts\n";

    //get_avg_appointments_completed_per_day : Clay
    std::cout << "Avg appointments per day : " << s.find_avg_appointments_completed_per_day("04/15/2021", "05/10/2021", false) << "apmts/day\n"; //might need to get rid of all flag

    //get avg shots per day
    std::cout << s.find_avg_appointments_completed_per_day("05/25/2021", "05/25/2021", false);

    return 0;
}