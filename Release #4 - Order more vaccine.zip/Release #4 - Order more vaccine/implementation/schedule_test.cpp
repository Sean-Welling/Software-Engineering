#include <iostream>

#include "../headers/schedule.h"

int main()
{
    campus *c = new campus();
    c->set_location(0);

    schedule s = schedule();
    s.set_appointments(find_appointments_by_campus(c, true));

    //get past apmts : Arthur
    std::cout << "Past appointments in this schedule : " << s.get_past_apmts().size() << " apmts\n";

    //get_avg_appointments_completed_per_day : Clay
    std::cout << "Avg appointments per day : " << s.find_avg_appointments_completed_per_day("04/15/2021", "05/10/2021", false) << "apmts/day\n"; //might need to get rid of all flag

    //get avg shots per day
    std::cout << s.find_avg_appointments_completed_per_day("05/25/2021", "05/25/2021", false);

    return 0;
}