#include <iostream>

#include "../headers/Date.h"
#include "Date.cpp"

//Test file for testing Date.h

int main(){
    std::cout << "Testing date class...\n\n";

    Date test1 = Date("05/25/2021");
    Date after = test1 - 3;

    std::cout << "After : ";
    std::cout << after.get_formatted("mm/dd/yyyy");
    std::cout << "\n";

    return 0;
}