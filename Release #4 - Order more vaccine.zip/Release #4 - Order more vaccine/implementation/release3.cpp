//includes
#include "../headers/System.h"

int main(int argc, char *argv[])
{
    add_v_space(2);
    add_divider(WIDTH);
    //initialize the system
    system_init();

    add_v_space(3);
    print_padded("RELEASE #3 - Complete Appointment");
    add_divider(WIDTH);

    while (1)
    {
        //show main menu
        int choice = menu();

        switch (choice)
        {
        case 0:
            return 0;
        case 1:
            //run patient registration
            if (!register_patient())
            {
                std::cout << "Error: Couldn't register you.\n";
            }
            break;

        case 2:
            //run appointment modification
            if (!modify_appointment())
            {
                std::cout << "Error: Couldn't modify appointment\n";
            }
            break;

        default:
            break;
        }
    }

    return 0;
}