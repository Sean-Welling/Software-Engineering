#include "../headers/System.h"

bool register_patient()
{
    int error_code = 0;

    //create patient
    patient *pt = new patient();

    //find available appointment times and locations (Schedule)

    //choose appointment time/date and location
    std::string date = "04/14/2021";
    std::string time = "15:00";

    //Creates a campus object for each location. Just sets campus location name
    std::cout << "What campus would you like to get your vaccine at?\n";
    vector<campus *> all_campuses;
    for (int i = 0; i < 8; i++)
    {
        all_campuses.push_back(new campus);
        all_campuses.at(i)->set_location(i);
        std::cout << i << ". " << all_campuses.at(i)->get_location() << "\n";
    }

    int campus_index;

    std::cout << "Choice : ";
    std::cin >> campus_index;

    //create appointment
    Appointment *apmt = new Appointment();

    //set id
    apmt->set_id(apmt->find_available_id());

    //set appointment patient
    if (apmt->set_patient(pt))
    {
        //set date
        if (apmt->set_date(date))
        {
            //set time
            if (apmt->set_time(time))
            {
                //set appointment campus
                if (apmt->set_campus(all_campuses[campus_index]))
                {
                    //check if first appointment
                    std::cout << "Is this your first appointment? (y/n) : ";
                    char ans;
                    int iteration;
                    cin >> ans;
                    while (ans != 'y' && ans != 'n')
                    {
                        std::cout << "Sorry, I don't understand - Is this your first appointment? (y/n) : ";
                        cin >> ans;
                    }

                    if (ans == 'y')
                    {
                        iteration = 1;
                    }
                    else
                    {
                        iteration = 2;
                    }

                    //set the iteration
                    if (apmt->set_iteration(iteration))
                    {
                        if (!apmt->log_appointment("appointments.csv"))
                        {
                            error_code = 5;
                        }
                    }
                    else
                    {
                        error_code = 4;
                    }
                }
            }
            else
            {
                error_code = 3;
            }
        }
        else
        {
            error_code = 2;
        }
    }
    else
    {
        error_code = 1;
    }

    if (error_code == 0)
    {
        print_padded("Patient successfully registered for" + apmt->get_date() + " at " + apmt->get_time() + " at the Campus " + "temp" + "\n");
        return true;
    }
    else
    {
        print_padded("ERROR: Couldn't register patient.\n");
        return false;
    }
}

bool modify_appointment()
{
    int apmt_id;
    std::cout << "enter your appointment id: ";
    std::cin >> apmt_id;

    Appointment *apmt = new Appointment();
    patient *p = new patient();

    apmt->set_id(apmt_id);
    apmt->init_from_existing();

    apmt->modify();

    return true;
}

int system_init()
{
    print_padded("Initializing system...");
    int error_code = 0;
    schedule *curr_schedule = new schedule();

    //get current date

    std::vector<Appointment *> past_apmts;

    //get all past appointments using current date
    //past_apmts = past_apmts->get_past_apmts();

    //for all past apmts -> run complete

    for (int i = 0; i < past_apmts.size(); i++)
    {
        Appointment *temp_apmt = past_apmts.at(i);

        if (!temp_apmt->complete(true))
        {
            error_code = 1;
        }
    }

    add_divider(WIDTH);

    //process shipments

    //process orders
    if (!process_orders())
    {
        error_code = 3;
    }

    return error_code;
}

bool process_orders()
{
    //find all orders that were placed yesterday
    Date curr_date = Date(get_curr_date());

    //check the shipment log to make sure we haven't created a shipment for this order already
    Database shipment_db = Database("shipments.csv");
    std::vector<std::vector<std::string>> shipment_db_rows = shipment_db.get_rows();
    std::vector<int> existing_shipment_order_ids;

    for (std::vector<std::string> row : shipment_db_rows)
    {
        existing_shipment_order_ids.push_back(stoi(row.at(6)));
    }

    //open orders db and get rows
    Database db = Database("orders.csv");
    std::vector<std::vector<std::string>> db_rows = db.get_rows();

    std::vector<Order *> orders_to_be_processed;

    Date *order_request_date = new Date();
    Order *temp_order = new Order();

    //get all orders that were submitted yesterday
    for (std::vector<std::string> row : db_rows)
    {
        //set request date obj
        order_request_date->init_from_date_string(row.at(3));

        Date diff = curr_date - *order_request_date;

        //compare dates
        if (diff.get_day() == 1 && diff.get_month() == 0 && diff.get_year() == 0)
        {
            //check to make sure we don't already have a shipment for this order
            bool shipment_found = false;
            for (int shipment_order_id : existing_shipment_order_ids)
            {
                //compare shipment order id to current order id
                if (shipment_order_id == stoi(row.at(0)))
                {
                    shipment_found = true;
                    break;
                }
            }
            if (!shipment_found)
            {
                //set order members
                temp_order->set_date_requested(row.at(3));
                temp_order->set_doses_needed(stoi(row.at(2)));
                temp_order->set_id(stoi(row.at(0)));
                temp_order->set_requester_id(stoi(row.at(1)));
                temp_order->set_fulfilled(stoi(row.at(4)));

                //add to list of orders to be processed
                orders_to_be_processed.push_back(temp_order);
            }
        }
    }

    //process each order
    for (Order *order : orders_to_be_processed)
    {
        //create shipment
        Shipment shipment = Shipment();

        //get an ID for the new shipment
        shipment.set_id(shipment.find_available_id());

        //set the send date
        shipment.set_send_date(get_curr_date());

        //calculate the number of doses to add to shipment
        /*
            Algorithm for calculating num doses

            1. Calculate a random % of the requested number of vaccines
            2. Add that calculated % of requested doses to shipment
        */

        //  https://www.cplusplus.com/reference/cstdlib/srand/

        //Initialize the randomness
        srand(time(NULL));

        //get random % to send from requested
        double to_remove = rand() % 101;

        shipment.set_total_doses(order->get_doses_needed() * (to_remove / 100));

        //get random num days between 4-10 for estimated arrival date
        int estimated_travel_days = (rand() % 7) + 4;

        //calculate estimated arrival date
        Date estimated_arrival_date = curr_date + estimated_travel_days;
        shipment.set_estimated_arrival_date(estimated_arrival_date.get_formatted("mm/dd/yyyy"));

        //set shipment receiver
        shipment.set_receiver_id(order->get_requester_id());

        shipment.set_order_id(order->get_id());

        //"Send" (send) log shipment
        shipment.log();
    }

    return false;
}

vector<schedule> init_campus_schedules()
{
    std::vector<campus*> all_campuses;
    for (int i = 0; i<8; i++) {

    }
    std::string campus_names[] = { "Ashtabula", "East Liverpool", "Geauga", "Kent", "Salem", "Stark", "Trumbull", "Tuscarawas"};
    campus *all_campuses[8];
    Supply *schedules[8];

    // Generate schedules for each campus

    // Apply schedule information

    // Display schedules
}

bool display_all_appointments()
{
 	//1. Get all appointments to show
    Database db = Database("appointments.csv");

    std::vector<std::vector<std::string>> db_rows = db.get_rows();

    std::vector<Appointment *> all_apmts;

    for (std::vector<std::string> row : db_rows)
    {
            //create apmt obj
            Appointment *temp_apmt = new Appointment();
            //set members
            temp_apmt->set_id(stoi(row.at(0)));
            temp_apmt->init_from_existing();
            //past apmt
            all_apmts.push_back(temp_apmt);
        
    }

	//2. For each appointment, call->show_details() method
    for (int i = 0; i < all_apmts.size();i++)
    {
        Appointment *temp = all_apmts[0];
        //temp.display_details();
    }
}