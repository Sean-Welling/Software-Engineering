//
//  Supply.h
//
//
//  Created by Arthur Wolff on 3/18/21.
// Expanded by Daniel Earley on 2021-04-10
//

#ifndef Supply_h
#define Supply_h

#include <list>
using namespace std;

#include "Database.h"

// ----- Relationships -------
// Vaccine: Aggregation
// Low Demand: Association
// Campus: Association
// Shipment: Association

class Supply
{
public:
    //setters
    bool set_id(int id);

    //getters
    int get_id();

    //Other
    /**
     * Defines this supply's members from the supplies db using this supply's ID
     * Constraint : Supply ID needs to be set
     * @returns true: success | false: failed
     * @author Clay
     * @date 04/25/2021
     */
    bool init();

    void set_vaccine_count(int total_count); //set how many vaccines are available
    int get_vaccine_count(); //Gets the total number of vaccines available 
    bool vaccine(int item) const;
    
    

     /**
     * Update's the supplies db using this supply's members
     * Constraint : Supply ID needs to already be set in supplies.csv 
     * @returns true: success | false: failed
     * @author Daniel edited Clay's init() function
     * @date 04/26/2021
     */
    bool update_log();

private:
    int id = -1;
    int count; //how many vaccines are available of all brands
    
};

#endif