#include <iostream>
#include <cstdlib> //   For srand()
#include <ctime> //     For random time seed

#include "../headers/Appointment.h"
#include "../headers/campus.h"
#include "../headers/LowDemand.h"
#include "../headers/order.h"
#include "../headers/patient.h"
#include "../headers/payment.h"
#include "../headers/schedule.h"
#include "../headers/shipment.h"
#include "../headers/studentStaff.h"
#include "../headers/Supply.h"
#include "../headers/vaccine.h"
#include "../headers/Date.h"
#include "../headers/Database.h"

//system specific functionality
bool register_patient();

bool modify_appointment();

/**
 * Checks for past appointments
 * Removes them from the log
 * Updates campus supplies
 * Processes incoming shipments
 * Processes outgoing orders
 * @returns int error code
 */
int system_init();

/**
 * Simulates a vaccine manufacturer processing orders and sending shipments. 
 * Finds all orders that were requested on the previous day. 
 * Calculates the number of vaccines that should be sent in shipment. 
 * "Sends"(logs) the shipment
 * @returns true: success | false: failed
 * @author Clay
 * @date 04/24/2021
 */
bool process_orders();


/*
* Initializes all campus schedules
* Creates schedules
* Populates schedules 
* Displays each sites schedule of appointments for the day
*/
vector<schedule> init_campus_schedules();

/**
 * Display Appointment details for all appointments
 * Get all appointments
 * Call show_details
 * @author Sean
 */
bool display_all_appointments();
