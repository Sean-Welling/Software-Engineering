#ifndef studentStaff_h
#define studentStaff_h

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

/**************************************************************************
 * Class definition : studentStaff
 * @author Sean Welling
 *************************************************************************/

class studentStaff 
{
public:
    char id_num[10];
    
    studentStaff();

     /**
     * Gets records from the studentStaff database
     * @return single record from the database :: record = [id, username, firstname, lastname, role, address, phone, age]
     */
    std::vector<std::string> get_user_info(); 

};

#endif /* studentStaff_h */