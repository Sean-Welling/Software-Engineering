#include <iostream>
#include <string>

const int WIDTH = 100;

int menu();

void add_divider(int width);

void print_padded(std::string phrase);

int calc_padding(std::string phrase);

void add_v_space(int lines);